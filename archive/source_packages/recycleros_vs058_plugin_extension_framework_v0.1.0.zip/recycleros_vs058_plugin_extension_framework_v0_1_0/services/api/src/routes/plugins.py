from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from src.plugins.manifest_validator import validate_manifest
from src.plugins.dependency_resolver import resolve_dependencies

router = APIRouter()

class PluginInstallRequest(BaseModel):
    organization_id: str
    workspace_id: str
    manifest: dict
    approved_permissions: list[str]
    installed_versions: dict[str, str] = {}

@router.post('/validate')
def validate_plugin(payload: PluginInstallRequest):
    result = validate_manifest(payload.manifest)

    if not result.is_valid:
        return {
            'status': 'invalid',
            'errors': result.errors,
        }

    dependencies = resolve_dependencies(
        payload.manifest,
        payload.installed_versions,
    )

    return {
        'status': 'valid' if dependencies.is_satisfied else 'blocked',
        'validation_errors': [],
        'missing_dependencies': dependencies.missing_dependencies,
        'incompatible_dependencies': dependencies.incompatible_dependencies,
        'event_created': 'plugin.validated',
    }

@router.post('/install')
def install_plugin(payload: PluginInstallRequest):
    validation = validate_manifest(payload.manifest)
    if not validation.is_valid:
        raise HTTPException(status_code=400, detail=validation.errors)

    requested_permissions = set(payload.manifest.get('permissions', []))
    approved_permissions = set(payload.approved_permissions)
    denied = sorted(requested_permissions.difference(approved_permissions))

    if denied:
        raise HTTPException(
            status_code=403,
            detail={
                'message': 'Requested plugin permissions were not approved.',
                'denied_permissions': denied,
            },
        )

    dependencies = resolve_dependencies(
        payload.manifest,
        payload.installed_versions,
    )

    if not dependencies.is_satisfied:
        raise HTTPException(
            status_code=409,
            detail={
                'missing_dependencies': dependencies.missing_dependencies,
                'incompatible_dependencies': dependencies.incompatible_dependencies,
            },
        )

    now = datetime.now(timezone.utc)

    return {
        'installed_plugin_id': 'PLG-INS-DEMO-000001',
        'plugin_id': payload.manifest['plugin_id'],
        'organization_id': payload.organization_id,
        'workspace_id': payload.workspace_id,
        'installed_version': payload.manifest['version'],
        'status': 'installed',
        'installed_at': now.isoformat(),
        'event_created': 'plugin.installed',
    }

@router.post('/installations/{installation_id}/enable')
def enable_plugin(installation_id: str):
    return {
        'installed_plugin_id': installation_id,
        'status': 'enabled',
        'enabled_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'plugin.enabled',
    }

@router.post('/installations/{installation_id}/disable')
def disable_plugin(installation_id: str):
    return {
        'installed_plugin_id': installation_id,
        'status': 'disabled',
        'disabled_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'plugin.disabled',
    }

@router.post('/installations/{installation_id}/rollback')
def rollback_plugin(installation_id: str, target_version: str):
    return {
        'installed_plugin_id': installation_id,
        'target_version': target_version,
        'status': 'rolled_back',
        'completed_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'plugin.rollback_completed',
    }
