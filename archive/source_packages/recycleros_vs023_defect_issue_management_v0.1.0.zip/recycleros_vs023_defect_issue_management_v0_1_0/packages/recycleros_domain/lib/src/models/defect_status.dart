enum DefectStatus {
  open,
  triaged,
  inProgress,
  resolved,
  deferred,
  closed,
}
