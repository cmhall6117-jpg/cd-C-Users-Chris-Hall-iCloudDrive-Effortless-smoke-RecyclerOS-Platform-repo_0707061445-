class DecisionRecommendation {
  final String recommendationId;
  final String recommendationCode;
  final String recommendationType;
  final String relatedObjectType;
  final String relatedObjectId;
  final String recommendation;
  final String reasoning;
  final double confidenceScore;
  final String status;
  final DateTime createdAt;

  const DecisionRecommendation({
    required this.recommendationId,
    required this.recommendationCode,
    required this.recommendationType,
    required this.relatedObjectType,
    required this.relatedObjectId,
    required this.recommendation,
    required this.reasoning,
    required this.confidenceScore,
    required this.status,
    required this.createdAt,
  });
}
