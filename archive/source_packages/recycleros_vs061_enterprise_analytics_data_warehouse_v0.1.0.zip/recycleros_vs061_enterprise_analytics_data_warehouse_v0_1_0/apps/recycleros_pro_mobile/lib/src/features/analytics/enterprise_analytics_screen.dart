import 'package:flutter/material.dart';

class EnterpriseAnalyticsScreen extends StatelessWidget {
  const EnterpriseAnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final metrics = [
      ('Gross Profit Trend', '+12.4% vs prior period'),
      ('Inventory Turnover', '3.2x annualized'),
      ('Lead Conversion', '18.7%'),
      ('Return Ratio', '4.1%'),
      ('Average Days to Sale', '26 days'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Enterprise Analytics')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Historical Performance',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const Text(
            'Compare periods across procurement, inventory, sales, finance, marketing, and risk.',
          ),
          const SizedBox(height: 16),
          for (final metric in metrics)
            Card(
              child: ListTile(
                leading: const Icon(Icons.analytics),
                title: Text(metric.$1),
                subtitle: Text(metric.$2),
              ),
            ),
        ],
      ),
    );
  }
}
