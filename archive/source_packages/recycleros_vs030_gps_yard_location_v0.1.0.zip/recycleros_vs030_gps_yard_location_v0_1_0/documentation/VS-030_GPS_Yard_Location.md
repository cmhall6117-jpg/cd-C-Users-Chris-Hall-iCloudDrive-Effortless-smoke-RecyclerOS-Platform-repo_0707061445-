# VS-030 GPS Yard Location & Map Pins

Capabilities:
- GPS Location Capture
- Yard Location Intelligence
- Vehicle Position Tracking
- Offline Map Pin Support
- Field Operations Intelligence

Events:
- GPS Location Captured
- Yard Pin Created
- Vehicle Location Updated
- Location Accuracy Warning

Objects:
- GPS Location
- Yard Location
- Map Pin
- Vehicle
- Harvest Session
- Storage Location

Acceptance Criteria:
1. User can scaffold GPS capture for a vehicle or harvest session.
2. Yard map pin can link to a vehicle, storage location, or harvest session.
3. GPS accuracy field is stored.
4. Offline GPS/map pin records are stored with sync status.
5. Manual yard/row fallback is supported.
