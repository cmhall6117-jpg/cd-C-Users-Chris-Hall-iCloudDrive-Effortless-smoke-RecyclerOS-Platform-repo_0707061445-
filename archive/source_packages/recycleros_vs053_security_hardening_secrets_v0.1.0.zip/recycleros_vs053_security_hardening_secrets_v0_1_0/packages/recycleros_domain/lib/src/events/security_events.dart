class SecurityEventTypes {
  static const secretReferenceCreated = 'security.secret_reference_created';
  static const secretRotationRecorded = 'security.secret_rotation_recorded';
  static const accessPolicyUpdated = 'security.access_policy_updated';
  static const securityChecklistUpdated = 'security.checklist_updated';
}
