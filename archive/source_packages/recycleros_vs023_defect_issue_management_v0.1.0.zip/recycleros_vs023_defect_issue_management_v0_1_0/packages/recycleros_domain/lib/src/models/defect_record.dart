class DefectRecord {
  final String defectId;
  final String defectCode;
  final String title;
  final String severity;
  final String status;
  final String? sourcePackage;
  final String? relatedFile;
  final String description;
  final DateTime createdAt;
  final DateTime? resolvedAt;

  const DefectRecord({
    required this.defectId,
    required this.defectCode,
    required this.title,
    required this.severity,
    required this.status,
    this.sourcePackage,
    this.relatedFile,
    required this.description,
    required this.createdAt,
    this.resolvedAt,
  });
}
