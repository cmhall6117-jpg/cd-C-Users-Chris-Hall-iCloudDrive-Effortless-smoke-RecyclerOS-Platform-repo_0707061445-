CREATE TABLE IF NOT EXISTS risk_flags (
    id TEXT PRIMARY KEY,
    risk_code TEXT UNIQUE NOT NULL,
    risk_type TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'medium',
    status TEXT NOT NULL DEFAULT 'open',
    related_object_type TEXT,
    related_object_id TEXT,
    description TEXT NOT NULL,
    created_at TEXT NOT NULL,
    resolved_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS approval_holds (
    id TEXT PRIMARY KEY,
    hold_code TEXT UNIQUE NOT NULL,
    related_object_type TEXT NOT NULL,
    related_object_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    placed_at TEXT NOT NULL,
    released_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
