class IntegrationEventTypes {
  static const integrationInstalled = 'integration.installed';
  static const integrationEnabled = 'integration.enabled';
  static const integrationDisabled = 'integration.disabled';
  static const syncStarted = 'integration.sync_started';
  static const syncCompleted = 'integration.sync_completed';
  static const syncFailed = 'integration.sync_failed';
}
