class ScrapMaterialLine {
  final String scrapMaterialLineId;
  final String materialType;
  final double weight;
  final double pricePerUnit;
  final double totalValue;

  const ScrapMaterialLine({
    required this.scrapMaterialLineId,
    required this.materialType,
    required this.weight,
    required this.pricePerUnit,
    required this.totalValue,
  });
}
