# GraphQL scaffold. Replace with Strawberry or Ariadne after dependency selection.

class Query:
    def health(self) -> dict:
        return {'status': 'ok', 'service': 'recycleros-graphql'}

schema = Query()
