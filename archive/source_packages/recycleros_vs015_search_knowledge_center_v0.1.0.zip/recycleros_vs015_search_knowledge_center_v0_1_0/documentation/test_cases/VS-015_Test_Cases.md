# VS-015 Search & Knowledge Center Test Cases

TC-001 Global Search: query returns mixed result types.
TC-002 Search Event: search.performed event is recorded.
TC-003 Knowledge Article: article can be stored and viewed.
TC-004 Offline Knowledge: cached article can be accessed offline.
TC-005 SOP Reference: SOP result can be represented in search results.
