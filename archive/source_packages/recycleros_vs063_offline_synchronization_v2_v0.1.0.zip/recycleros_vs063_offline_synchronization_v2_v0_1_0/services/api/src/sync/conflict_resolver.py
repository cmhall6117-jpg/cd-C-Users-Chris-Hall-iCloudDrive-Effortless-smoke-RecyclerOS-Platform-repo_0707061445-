from dataclasses import dataclass
from datetime import datetime

@dataclass(frozen=True)
class ConflictResolution:
    status: str
    merged_payload: dict | None
    requires_manual_review: bool

def resolve_conflict(local_payload: dict, server_payload: dict, strategy: str) -> ConflictResolution:
    if strategy == 'server_wins':
        return ConflictResolution('resolved', server_payload, False)
    if strategy == 'client_wins':
        return ConflictResolution('resolved', local_payload, False)
    if strategy == 'last_write_wins':
        local_time = local_payload.get('updated_at')
        server_time = server_payload.get('updated_at')
        if not local_time or not server_time:
            return ConflictResolution('pending', None, True)
        winner = local_payload if datetime.fromisoformat(local_time) >= datetime.fromisoformat(server_time) else server_payload
        return ConflictResolution('resolved', winner, False)
    if strategy == 'field_merge':
        merged = dict(server_payload)
        merged.update(local_payload)
        return ConflictResolution('resolved', merged, False)
    return ConflictResolution('pending', None, True)
