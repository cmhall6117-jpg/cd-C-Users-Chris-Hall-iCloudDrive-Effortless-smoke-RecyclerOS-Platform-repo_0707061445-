class CycleCountEventTypes {
  static const cycleCountStarted = 'cycle_count.started';
  static const cycleCountCompleted = 'cycle_count.completed';
  static const inventoryDiscrepancyFound = 'inventory.discrepancy_found';
  static const inventoryAdjusted = 'inventory.adjusted';
}
