from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class IntegrationInstallRequest(BaseModel):
    integration_listing_id: str
    organization_id: str
    workspace_id: str
    credential_reference_id: str | None = None

@router.get('/marketplace')
def list_marketplace():
    return {
        'items': [
            {'integration_code': 'INT-EBAY', 'name': 'eBay', 'category': 'marketplace', 'status': 'available'},
            {'integration_code': 'INT-QBO', 'name': 'QuickBooks Online', 'category': 'accounting', 'status': 'planned'},
            {'integration_code': 'INT-UPS', 'name': 'UPS', 'category': 'shipping', 'status': 'planned'}
        ]
    }

@router.post('/installations')
def install_integration(payload: IntegrationInstallRequest):
    return {
        'installed_integration_id': 'IIN-DEMO-000001',
        'integration_listing_id': payload.integration_listing_id,
        'organization_id': payload.organization_id,
        'workspace_id': payload.workspace_id,
        'credential_reference_id': payload.credential_reference_id,
        'status': 'installed',
        'installed_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'integration.installed'
    }

@router.post('/installations/{installation_id}/sync')
def start_sync(installation_id: str):
    return {
        'integration_sync_job_id': 'ISJ-DEMO-000001',
        'installed_integration_id': installation_id,
        'status': 'started',
        'processed_count': 0,
        'error_count': 0,
        'started_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'integration.sync_started'
    }
