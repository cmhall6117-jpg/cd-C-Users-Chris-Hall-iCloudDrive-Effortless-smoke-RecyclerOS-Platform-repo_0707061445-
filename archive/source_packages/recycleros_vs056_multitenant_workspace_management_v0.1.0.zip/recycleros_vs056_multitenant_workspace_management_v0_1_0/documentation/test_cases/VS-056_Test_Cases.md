# VS-056 Multi-Tenant Organization & Workspace Management Test Cases

TC-001 Create Organization: tenant.organization_created event is recorded.
TC-002 Create Workspace: workspace is linked to one organization.
TC-003 Create Branch: branch is linked to one workspace.
TC-004 Add Membership: user membership stores organization, workspace, and role.
TC-005 Workspace Switch: active workspace changes without a new login.
TC-006 Tenant Context Required: tenant-scoped endpoint rejects missing tenant headers.
TC-007 Cross-Tenant Access: unauthorized tenant access is rejected and audited.
TC-008 Offline Tenant Safety: local records retain organization_id and workspace_id.
