class LoginAttempt {
  final String loginAttemptId;
  final String email;
  final String result;
  final String? failureReason;
  final String? deviceId;
  final DateTime attemptedAt;

  const LoginAttempt({
    required this.loginAttemptId,
    required this.email,
    required this.result,
    this.failureReason,
    this.deviceId,
    required this.attemptedAt,
  });
}
