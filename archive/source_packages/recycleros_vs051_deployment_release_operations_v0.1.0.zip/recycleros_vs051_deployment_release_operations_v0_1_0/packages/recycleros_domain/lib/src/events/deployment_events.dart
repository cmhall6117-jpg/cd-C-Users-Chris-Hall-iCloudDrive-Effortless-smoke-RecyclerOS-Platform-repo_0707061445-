class DeploymentEventTypes {
  static const deploymentStarted = 'deployment.started';
  static const deploymentCompleted = 'deployment.completed';
  static const deploymentFailed = 'deployment.failed';
  static const rollbackPlanned = 'deployment.rollback_planned';
  static const releaseCheckpointPassed = 'release.checkpoint_passed';
}
