class SyncEventTypes {
  static const syncStarted = 'sync.started';
  static const syncCompleted = 'sync.completed';
  static const syncFailed = 'sync.failed';
  static const deviceStatusCaptured = 'device.status_captured';
  static const offlineQueueReviewed = 'offline_queue.reviewed';
}
