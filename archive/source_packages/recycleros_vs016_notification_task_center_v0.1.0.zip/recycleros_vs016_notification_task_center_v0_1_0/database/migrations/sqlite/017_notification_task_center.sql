CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    notification_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info',
    status TEXT NOT NULL DEFAULT 'open',
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TEXT NOT NULL,
    acknowledged_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    task_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    priority TEXT NOT NULL DEFAULT 'normal',
    assigned_to TEXT,
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TEXT NOT NULL,
    due_at TEXT,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
