import 'package:flutter/material.dart';

class PartsResearchScreen extends StatelessWidget {
  const PartsResearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final parts = [
      ('ECM / PCM', 'Programming required • high value'),
      ('LED Headlight', 'Fitment confidence 82%'),
      ('Transmission', 'Interchange research pending'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Parts Research')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Compatibility Intelligence', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Research part value, fitment, VIN features, programming requirements, and interchange confidence.'),
          const SizedBox(height: 16),
          for (final part in parts)
            Card(child: ListTile(leading: const Icon(Icons.manage_search), title: Text(part.$1), subtitle: Text(part.$2))),
        ],
      ),
    );
  }
}
