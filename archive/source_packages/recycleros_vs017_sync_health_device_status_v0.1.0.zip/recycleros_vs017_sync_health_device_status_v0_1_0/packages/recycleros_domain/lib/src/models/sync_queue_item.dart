class SyncQueueItem {
  final String syncQueueItemId;
  final String relatedObjectType;
  final String relatedObjectId;
  final String action;
  final String status;
  final int retryCount;
  final String? lastError;
  final DateTime createdAt;
  final DateTime? lastAttemptAt;

  const SyncQueueItem({
    required this.syncQueueItemId,
    required this.relatedObjectType,
    required this.relatedObjectId,
    required this.action,
    required this.status,
    required this.retryCount,
    this.lastError,
    required this.createdAt,
    this.lastAttemptAt,
  });
}
