class Membership {
  final String membershipId;
  final String userId;
  final String organizationId;
  final String? workspaceId;
  final String roleCode;
  final String status;
  final DateTime createdAt;

  const Membership({
    required this.membershipId,
    required this.userId,
    required this.organizationId,
    this.workspaceId,
    required this.roleCode,
    required this.status,
    required this.createdAt,
  });
}
