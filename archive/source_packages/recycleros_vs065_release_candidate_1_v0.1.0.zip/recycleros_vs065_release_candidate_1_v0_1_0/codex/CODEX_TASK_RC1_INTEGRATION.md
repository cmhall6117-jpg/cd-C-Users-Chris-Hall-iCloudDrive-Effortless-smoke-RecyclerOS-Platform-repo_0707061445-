# CODEX-TASK-RC1 — Assemble and Validate RecyclerOS RC1

## Mission

Create the first integrated, buildable RecyclerOS Pro repository and produce objective release evidence.

## Required Work

1. Merge the Development Foundation and vertical-slice packages into one monorepo.
2. Archive every source package under `archive/source_packages/`.
3. Resolve duplicate Dart models, enums, imports, and routes.
4. Register all required FastAPI routers.
5. Register the Flutter navigation routes.
6. Normalize migration numbering and dependency order.
7. Apply PostgreSQL migrations in a clean database.
8. Initialize SQLite from a clean local database.
9. Run backend import/startup checks.
10. Run Flutter pub get, analyze, and tests.
11. Implement the first complete working path:
    Mission Control → Opportunity Discovery → Vehicle → Procurement → Pick List → Inventory.
12. Create and maintain:
    - documentation/defects/DEFECT_REGISTER.md
    - documentation/assumptions/ASSUMPTIONS.md
    - documentation/build/BUILD_REPORT.md
    - documentation/tests/SMOKE_TEST_REPORT.md
    - documentation/release/RC1_RELEASE_EVIDENCE.md

## Constraints

- Do not silently delete generated artifacts.
- Do not expose secret values.
- Preserve tenant identifiers.
- Prefer small, traceable fixes.
- Record every unresolved blocker.
- Do not mark a gate passed without evidence.

## Completion Response

Return:
- Commit and branch
- Files changed
- Build results
- Migration results
- Test results
- Open defects
- Passed/failed release gates
- Recommended next task
