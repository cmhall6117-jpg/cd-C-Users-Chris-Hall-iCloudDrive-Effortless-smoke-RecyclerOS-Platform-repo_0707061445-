class LaborRoleProfile {
  final String laborRoleId;
  final String roleCode;
  final String title;
  final String skillLevel;
  final String employmentType;
  final double? basePayMin;
  final double? basePayMax;
  final String currency;
  final DateTime createdAt;

  const LaborRoleProfile({
    required this.laborRoleId,
    required this.roleCode,
    required this.title,
    required this.skillLevel,
    required this.employmentType,
    this.basePayMin,
    this.basePayMax,
    required this.currency,
    required this.createdAt,
  });
}
