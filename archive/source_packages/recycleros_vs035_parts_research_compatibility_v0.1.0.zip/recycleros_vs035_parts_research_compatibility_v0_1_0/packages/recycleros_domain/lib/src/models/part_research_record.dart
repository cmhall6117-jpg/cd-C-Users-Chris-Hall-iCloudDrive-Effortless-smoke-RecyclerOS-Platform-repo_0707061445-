class PartResearchRecord {
  final String partResearchRecordId;
  final String researchCode;
  final String partName;
  final String? relatedVehicleId;
  final String? relatedInventoryItemId;
  final double? estimatedResaleValue;
  final bool programmingRequired;
  final double confidenceScore;
  final DateTime createdAt;

  const PartResearchRecord({
    required this.partResearchRecordId,
    required this.researchCode,
    required this.partName,
    this.relatedVehicleId,
    this.relatedInventoryItemId,
    this.estimatedResaleValue,
    required this.programmingRequired,
    required this.confidenceScore,
    required this.createdAt,
  });
}
