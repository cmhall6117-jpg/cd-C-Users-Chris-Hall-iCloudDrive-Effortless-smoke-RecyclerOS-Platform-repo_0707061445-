class BackupEventTypes {
  static const backupStarted = 'backup.started';
  static const backupCompleted = 'backup.completed';
  static const backupFailed = 'backup.failed';
  static const restoreStarted = 'restore.started';
  static const restoreCompleted = 'restore.completed';
  static const retentionPolicyUpdated = 'retention.policy_updated';
}
