class AdminEventTypes {
  static const userCreated = 'user.created';
  static const roleAssigned = 'role.assigned';
  static const permissionChanged = 'permission.changed';
  static const approvalAuthorityGranted = 'approval_authority.granted';
  static const userDeactivated = 'user.deactivated';
}
