from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class ScanRecordCreate(BaseModel):
    scan_type: str
    scanned_value: str
    related_object_type: str | None = None
    related_object_id: str | None = None

@router.post('/scan-records')
def create_scan_record(payload: ScanRecordCreate):
    event_type = 'scanner.barcode_scanned'
    if payload.scan_type.lower() == 'vin':
        event_type = 'scanner.vin_captured'
    return {
        'scan_record_id': 'SCN-DEMO-000001',
        'scan_code': 'SCN-000001',
        'scan_type': payload.scan_type,
        'scanned_value': payload.scanned_value,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'scanned_at': datetime.now(timezone.utc).isoformat(),
        'event_created': event_type
    }
