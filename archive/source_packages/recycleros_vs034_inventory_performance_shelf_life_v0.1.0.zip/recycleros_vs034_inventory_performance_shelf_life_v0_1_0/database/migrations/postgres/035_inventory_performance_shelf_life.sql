CREATE TABLE IF NOT EXISTS inventory_performance_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    inventory_item_id UUID REFERENCES inventory_items(id),
    shelf_life_days INTEGER NOT NULL DEFAULT 0,
    return_count INTEGER NOT NULL DEFAULT 0,
    quantity_on_hand INTEGER NOT NULL DEFAULT 0,
    quantity_sold INTEGER NOT NULL DEFAULT 0,
    sell_through_rate NUMERIC(5,2) NOT NULL DEFAULT 0,
    return_ratio NUMERIC(5,2) NOT NULL DEFAULT 0,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stock_limit_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_code TEXT UNIQUE NOT NULL,
    part_category TEXT NOT NULL,
    max_on_hand_quantity INTEGER NOT NULL DEFAULT 0,
    target_shelf_life_days INTEGER NOT NULL DEFAULT 0,
    max_return_ratio NUMERIC(5,2) NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT true
);
