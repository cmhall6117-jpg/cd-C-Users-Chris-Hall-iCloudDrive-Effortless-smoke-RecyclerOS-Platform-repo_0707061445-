import 'package:flutter/material.dart';

class IntegrationMarketplaceScreen extends StatelessWidget {
  const IntegrationMarketplaceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final integrations = [
      ('eBay', 'Marketplace • available'),
      ('QuickBooks Online', 'Accounting • planned'),
      ('UPS', 'Shipping • planned'),
      ('Copart', 'Auction • planned'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Integration Marketplace')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Connect RecyclerOS', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Install and manage marketplace, accounting, shipping, auction, and enterprise connectors.'),
          const SizedBox(height: 16),
          for (final integration in integrations)
            Card(
              child: ListTile(
                leading: const Icon(Icons.extension),
                title: Text(integration.$1),
                subtitle: Text(integration.$2),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
