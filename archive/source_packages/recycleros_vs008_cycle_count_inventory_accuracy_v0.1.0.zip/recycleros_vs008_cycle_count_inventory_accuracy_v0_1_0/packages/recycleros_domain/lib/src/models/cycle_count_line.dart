class CycleCountLine {
  final String cycleCountLineId;
  final String cycleCountSessionId;
  final String inventoryItemId;
  final int expectedQuantity;
  final int countedQuantity;
  final int variance;
  final String? notes;

  const CycleCountLine({
    required this.cycleCountLineId,
    required this.cycleCountSessionId,
    required this.inventoryItemId,
    required this.expectedQuantity,
    required this.countedQuantity,
    required this.variance,
    this.notes,
  });
}
