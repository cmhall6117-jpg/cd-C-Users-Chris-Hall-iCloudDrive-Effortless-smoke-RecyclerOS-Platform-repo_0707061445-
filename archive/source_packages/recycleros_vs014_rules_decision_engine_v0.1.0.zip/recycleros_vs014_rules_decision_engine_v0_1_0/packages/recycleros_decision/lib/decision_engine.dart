class DecisionEngine {
  Map<String, dynamic> createRecommendation({
    required String recommendationType,
    required String relatedObjectType,
    required String relatedObjectId,
    required String recommendation,
    required String reasoning,
    required double confidenceScore,
  }) {
    return {
      'recommendation_type': recommendationType,
      'related_object_type': relatedObjectType,
      'related_object_id': relatedObjectId,
      'recommendation': recommendation,
      'reasoning': reasoning,
      'confidence_score': confidenceScore,
      'status': 'open',
    };
  }
}
