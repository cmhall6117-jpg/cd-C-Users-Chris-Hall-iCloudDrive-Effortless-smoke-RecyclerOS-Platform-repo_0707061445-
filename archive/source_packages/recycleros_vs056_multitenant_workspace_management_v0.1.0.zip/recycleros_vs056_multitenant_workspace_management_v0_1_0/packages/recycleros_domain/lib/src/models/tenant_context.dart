class TenantContext {
  final String organizationId;
  final String workspaceId;
  final String? branchId;
  final String userId;
  final String roleCode;

  const TenantContext({
    required this.organizationId,
    required this.workspaceId,
    this.branchId,
    required this.userId,
    required this.roleCode,
  });
}
