class ReportingEventTypes {
  static const businessReviewCreated = 'reporting.business_review_created';
  static const reportSectionAdded = 'reporting.section_added';
  static const reportExportRequested = 'reporting.export_requested';
  static const reportApproved = 'reporting.report_approved';
}
