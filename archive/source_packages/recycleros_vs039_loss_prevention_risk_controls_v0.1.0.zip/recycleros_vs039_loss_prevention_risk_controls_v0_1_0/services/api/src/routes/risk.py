from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class RiskFlagCreate(BaseModel):
    risk_type: str
    severity: str = 'medium'
    related_object_type: str | None = None
    related_object_id: str | None = None
    description: str

@router.post('/flags')
def create_risk_flag(payload: RiskFlagCreate):
    return {
        'risk_flag_id': 'RSK-DEMO-000001',
        'risk_code': 'RSK-000001',
        'risk_type': payload.risk_type,
        'severity': payload.severity,
        'status': 'open',
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'description': payload.description,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'risk.flag_created'
    }
