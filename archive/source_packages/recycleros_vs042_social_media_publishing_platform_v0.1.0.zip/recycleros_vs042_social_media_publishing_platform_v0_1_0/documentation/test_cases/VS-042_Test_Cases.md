# VS-042 Social Media Publishing Platform Test Cases

TC-001 Create Social Post: social.post_drafted event is recorded.
TC-002 Related Object Link: post can link to campaign, listing, inventory item, or content draft.
TC-003 Schedule Post: social.post_scheduled event is recorded.
TC-004 Channel Profile: channel profile can be represented.
TC-005 Offline Draft: post drafts save locally with sync_status pending.
