class RiskFlag {
  final String riskFlagId;
  final String riskCode;
  final String riskType;
  final String severity;
  final String status;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final String description;
  final DateTime createdAt;

  const RiskFlag({
    required this.riskFlagId,
    required this.riskCode,
    required this.riskType,
    required this.severity,
    required this.status,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.description,
    required this.createdAt,
  });
}
