class AuditRecord {
  final String auditRecordId;
  final String eventCode;
  final String eventType;
  final String objectType;
  final String objectId;
  final String performedBy;
  final DateTime occurredAt;
  final String payloadSummary;

  const AuditRecord({
    required this.auditRecordId,
    required this.eventCode,
    required this.eventType,
    required this.objectType,
    required this.objectId,
    required this.performedBy,
    required this.occurredAt,
    required this.payloadSummary,
  });
}
