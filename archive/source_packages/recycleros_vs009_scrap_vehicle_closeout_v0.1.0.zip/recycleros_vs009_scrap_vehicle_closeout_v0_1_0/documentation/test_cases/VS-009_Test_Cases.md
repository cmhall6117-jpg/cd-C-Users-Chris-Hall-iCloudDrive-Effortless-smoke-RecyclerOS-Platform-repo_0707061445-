# VS-009 Scrap & Vehicle Closeout Test Cases

TC-001 Mark Scrap Candidate: vehicle may be marked scrap candidate.
TC-002 Record Scrap Value: actual scrap value minus hauling cost calculates net scrap value.
TC-003 Material Lines: material weight and price calculate line value.
TC-004 Closeout Event: vehicle.scrapped and scrap.value_recorded events are created.
TC-005 Offline Closeout: records save locally with sync_status pending.
