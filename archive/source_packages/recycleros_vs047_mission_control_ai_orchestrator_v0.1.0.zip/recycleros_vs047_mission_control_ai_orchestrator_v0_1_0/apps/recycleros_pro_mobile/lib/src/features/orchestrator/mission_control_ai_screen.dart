import 'package:flutter/material.dart';

class MissionControlAiScreen extends StatelessWidget {
  const MissionControlAiScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final actions = [
      ('Urgent', 'Review high-value refund approval hold', 'Priority 96'),
      ('Important', 'Procure Ford ECM opportunity before auction closes', 'Priority 88'),
      ('Important', 'Discount aging LED headlight inventory', 'Priority 74'),
      ('Info', 'Weekly business review draft ready', 'Priority 61'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Mission Control AI')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('AI Command Center', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Prioritized actions across procurement, inventory, sales, risk, and reporting.'),
          const SizedBox(height: 16),
          for (final action in actions)
            Card(
              child: ListTile(
                leading: const Icon(Icons.auto_awesome),
                title: Text('${action.$1}: ${action.$2}'),
                subtitle: Text(action.$3),
              ),
            ),
        ],
      ),
    );
  }
}
