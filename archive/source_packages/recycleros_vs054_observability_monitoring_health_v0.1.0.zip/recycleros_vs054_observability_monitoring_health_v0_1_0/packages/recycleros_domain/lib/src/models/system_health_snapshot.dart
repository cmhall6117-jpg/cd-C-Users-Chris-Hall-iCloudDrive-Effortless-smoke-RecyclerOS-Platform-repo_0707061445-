class SystemHealthSnapshot {
  final String systemHealthSnapshotId;
  final String serviceName;
  final String status;
  final double? responseTimeMs;
  final DateTime capturedAt;

  const SystemHealthSnapshot({
    required this.systemHealthSnapshotId,
    required this.serviceName,
    required this.status,
    this.responseTimeMs,
    required this.capturedAt,
  });
}
