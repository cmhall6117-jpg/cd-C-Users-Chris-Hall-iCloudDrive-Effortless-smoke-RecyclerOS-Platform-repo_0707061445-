import 'package:go_router/go_router.dart';

// Central route registry scaffold.
// Uncomment imports and routes after all screens are merged.

final appRoutes = <RouteBase>[
  // GoRoute(path: '/', builder: (_, __) => const MissionControlDashboardScreen()),
  // GoRoute(path: '/opportunities', builder: (_, __) => const OpportunityDiscoveryScreen()),
  // GoRoute(path: '/vehicles/:vehicleCode', builder: (_, state) => const VehicleTwinScreen()),
  // GoRoute(path: '/procurement/:opportunityId', builder: (_, state) => const ProcurementWorkspaceScreen()),
  // GoRoute(path: '/pick-list', builder: (_, __) => const PickListScreen()),
  // GoRoute(path: '/focus-point/:vehicleId', builder: (_, state) => const FocusPointScreen()),
  // GoRoute(path: '/inventory/intake', builder: (_, __) => const InventoryIntakeScreen()),
  // GoRoute(path: '/sales/orders', builder: (_, __) => const SalesOrderScreen()),
  // GoRoute(path: '/cycle-count', builder: (_, __) => const CycleCountScreen()),
  // GoRoute(path: '/scrap/closeout/:vehicleId', builder: (_, state) => const ScrapCloseoutScreen()),
  // GoRoute(path: '/compliance/disposal', builder: (_, __) => const ComplianceRecordScreen()),
  // GoRoute(path: '/promotions', builder: (_, __) => const PromotionCampaignScreen()),
  // GoRoute(path: '/customers/:customerId', builder: (_, state) => const CustomerProfileScreen()),
  // GoRoute(path: '/finance', builder: (_, __) => const FinanceDashboardScreen()),
  // GoRoute(path: '/decisions', builder: (_, __) => const DecisionRecommendationsScreen()),
  // GoRoute(path: '/search', builder: (_, __) => const SearchKnowledgeScreen()),
  // GoRoute(path: '/notifications', builder: (_, __) => const NotificationTaskCenterScreen()),
  // GoRoute(path: '/sync-health', builder: (_, __) => const SyncHealthScreen()),
  // GoRoute(path: '/admin/users', builder: (_, __) => const AdminUsersRolesScreen()),
  // GoRoute(path: '/audit/events', builder: (_, __) => const AuditEventViewerScreen()),
];
