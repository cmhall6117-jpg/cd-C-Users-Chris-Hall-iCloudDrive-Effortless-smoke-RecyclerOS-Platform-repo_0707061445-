class ApiPlatformEventTypes {
  static const applicationCreated = 'api_platform.application_created';
  static const clientCreated = 'api_platform.client_created';
  static const clientRevoked = 'api_platform.client_revoked';
  static const webhookCreated = 'api_platform.webhook_created';
  static const rateLimitExceeded = 'api_platform.rate_limit_exceeded';
}
