class TrustedDevice {
  final String trustedDeviceId;
  final String userId;
  final String deviceId;
  final String displayName;
  final String status;
  final DateTime registeredAt;
  final DateTime? lastSeenAt;

  const TrustedDevice({
    required this.trustedDeviceId,
    required this.userId,
    required this.deviceId,
    required this.displayName,
    required this.status,
    required this.registeredAt,
    this.lastSeenAt,
  });
}
