# Risks and Limitations

1. Packages have not been compiled locally.
2. Flutter imports and package references may require workspace wiring.
3. Database migrations require sequencing and validation.
4. SQLite ALTER TABLE statements require guarded migration execution.
5. API routes need registration in main app router.
6. Authentication and production security are not yet implemented.
7. Business logic is scaffolded, not fully implemented.
