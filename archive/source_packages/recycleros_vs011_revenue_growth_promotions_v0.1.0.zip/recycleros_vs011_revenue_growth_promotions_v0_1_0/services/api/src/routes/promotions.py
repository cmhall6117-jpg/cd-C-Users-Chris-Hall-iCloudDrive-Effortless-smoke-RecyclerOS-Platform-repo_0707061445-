from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class PromotionCampaignCreate(BaseModel):
    title: str
    channel: str = 'manual'
    target_discount_percent: float | None = None
    projected_revenue_impact: float | None = None
    inventory_item_ids: list[str] = []

@router.post('/campaigns')
def create_campaign(payload: PromotionCampaignCreate):
    return {
        'promotion_campaign_id': 'PRM-DEMO-000001',
        'campaign_code': 'PRM-000001',
        'title': payload.title,
        'channel': payload.channel,
        'status': 'draft',
        'target_discount_percent': payload.target_discount_percent,
        'projected_revenue_impact': payload.projected_revenue_impact,
        'inventory_item_ids': payload.inventory_item_ids,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'promotion.campaign_created'
    }

@router.get('/recommendations')
def promotion_recommendations():
    return {
        'items': [
            {
                'recommendation_id': 'REC-DEMO-000001',
                'reason': 'Inventory shelf life exceeds target and on-hand stock is above procurement limit.',
                'suggested_action': 'Create 10 percent discount campaign',
                'confidence_score': 74
            }
        ]
    }
