from fastapi import FastAPI
from routes.health import router as health_router
from routes.opportunities import router as opportunities_router

app = FastAPI(title="RecyclerOS Platform API", version="0.1.0")
app.include_router(health_router, prefix="/v1/health", tags=["health"])
app.include_router(opportunities_router, prefix="/v1/opportunities", tags=["opportunities"])
