CREATE TABLE IF NOT EXISTS admin_dashboard_snapshots (
    id TEXT PRIMARY KEY,
    organization_count INTEGER NOT NULL DEFAULT 0,
    workspace_count INTEGER NOT NULL DEFAULT 0,
    active_user_count INTEGER NOT NULL DEFAULT 0,
    active_license_count INTEGER NOT NULL DEFAULT 0,
    installed_integration_count INTEGER NOT NULL DEFAULT 0,
    open_security_issue_count INTEGER NOT NULL DEFAULT 0,
    platform_health_status TEXT NOT NULL,
    generated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS admin_action_records (
    id TEXT PRIMARY KEY,
    action_code TEXT UNIQUE NOT NULL,
    actor_user_id TEXT NOT NULL,
    scope_type TEXT NOT NULL,
    organization_id TEXT,
    workspace_id TEXT,
    action_type TEXT NOT NULL,
    target_object_type TEXT NOT NULL,
    target_object_id TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS admin_saved_views (
    id TEXT PRIMARY KEY,
    owner_user_id TEXT NOT NULL,
    organization_id TEXT,
    workspace_id TEXT,
    view_code TEXT NOT NULL,
    name TEXT NOT NULL,
    configuration_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
