from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class ShippingEstimateCreate(BaseModel):
    carrier: str
    service_level: str
    estimated_cost: float
    related_object_type: str | None = None
    related_object_id: str | None = None

@router.post('/estimates')
def create_shipping_estimate(payload: ShippingEstimateCreate):
    return {
        'shipping_estimate_id': 'SHP-EST-DEMO-000001',
        'estimate_code': 'SHP-EST-000001',
        'carrier': payload.carrier,
        'service_level': payload.service_level,
        'estimated_cost': payload.estimated_cost,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'shipping.estimate_created'
    }
