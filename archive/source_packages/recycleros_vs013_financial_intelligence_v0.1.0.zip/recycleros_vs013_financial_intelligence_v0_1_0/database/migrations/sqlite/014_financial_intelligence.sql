CREATE TABLE IF NOT EXISTS ledger_accounts (
    id TEXT PRIMARY KEY,
    account_code TEXT UNIQUE NOT NULL,
    account_name TEXT NOT NULL,
    account_type TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS financial_transactions (
    id TEXT PRIMARY KEY,
    transaction_code TEXT UNIQUE NOT NULL,
    account_type TEXT NOT NULL,
    category TEXT NOT NULL,
    amount REAL NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    related_object_type TEXT,
    related_object_id TEXT,
    transaction_date TEXT NOT NULL,
    description TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS vehicle_profit_snapshots (
    id TEXT PRIMARY KEY,
    vehicle_id TEXT NOT NULL,
    parts_revenue REAL NOT NULL DEFAULT 0,
    scrap_revenue REAL NOT NULL DEFAULT 0,
    total_costs REAL NOT NULL DEFAULT 0,
    gross_profit REAL NOT NULL DEFAULT 0,
    net_profit REAL NOT NULL DEFAULT 0,
    generated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
