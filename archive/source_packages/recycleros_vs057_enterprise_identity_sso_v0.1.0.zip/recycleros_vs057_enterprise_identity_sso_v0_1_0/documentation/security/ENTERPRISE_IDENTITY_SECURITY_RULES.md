# Enterprise Identity Security Rules

1. Use OAuth 2.0 Authorization Code with PKCE for mobile and public clients.
2. Validate issuer, audience, signature, nonce, and token expiration.
3. Store provider client secrets through secret references only.
4. Hash refresh tokens and API tokens before storage.
5. Rotate refresh tokens after use.
6. Revoke all active sessions when a trusted device is revoked for security reasons.
7. Require MFA according to organization policy.
8. Bind sessions to organization, workspace, and device context.
9. Log login attempts, failures, MFA checks, session creation, and revocation.
10. Offline access must expire according to cached authentication policy.
