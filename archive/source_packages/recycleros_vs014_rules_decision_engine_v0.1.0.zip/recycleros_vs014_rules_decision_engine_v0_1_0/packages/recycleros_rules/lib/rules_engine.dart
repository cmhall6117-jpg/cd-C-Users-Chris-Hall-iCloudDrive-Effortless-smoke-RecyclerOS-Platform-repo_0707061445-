class RulesEngine {
  bool evaluate({
    required String conditionExpression,
    required Map<String, dynamic> context,
  }) {
    // Scaffold only.
    // Future implementation will parse configured rule expressions safely.
    if (conditionExpression == 'always_true') return true;
    return false;
  }
}
