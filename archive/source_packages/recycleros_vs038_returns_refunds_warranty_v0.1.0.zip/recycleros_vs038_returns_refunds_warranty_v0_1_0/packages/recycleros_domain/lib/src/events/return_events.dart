class ReturnEventTypes {
  static const returnAuthorized = 'return.authorized';
  static const returnReceived = 'return.received';
  static const refundIssued = 'refund.issued';
  static const warrantyClaimRecorded = 'warranty.claim_recorded';
  static const inventoryReturnImpactRecorded = 'inventory.return_impact_recorded';
}
