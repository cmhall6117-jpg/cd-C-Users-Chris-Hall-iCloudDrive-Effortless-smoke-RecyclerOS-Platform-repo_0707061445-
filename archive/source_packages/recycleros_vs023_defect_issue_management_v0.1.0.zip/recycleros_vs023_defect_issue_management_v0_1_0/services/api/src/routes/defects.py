from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class DefectCreate(BaseModel):
    title: str
    severity: str = 'medium'
    source_package: str | None = None
    related_file: str | None = None
    description: str

@router.post('/defects')
def create_defect(payload: DefectCreate):
    return {
        'defect_id': 'DEF-DEMO-000001',
        'defect_code': 'DEF-000001',
        'title': payload.title,
        'severity': payload.severity,
        'status': 'open',
        'source_package': payload.source_package,
        'related_file': payload.related_file,
        'description': payload.description,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'defect.created'
    }

@router.get('/defects')
def list_defects():
    return {
        'items': [
            {'defect_code': 'DEF-000001', 'title': 'Flutter import cleanup required', 'severity': 'high', 'status': 'open'},
            {'defect_code': 'DEF-000002', 'title': 'SQLite migration guard needed', 'severity': 'medium', 'status': 'triaged'}
        ]
    }
