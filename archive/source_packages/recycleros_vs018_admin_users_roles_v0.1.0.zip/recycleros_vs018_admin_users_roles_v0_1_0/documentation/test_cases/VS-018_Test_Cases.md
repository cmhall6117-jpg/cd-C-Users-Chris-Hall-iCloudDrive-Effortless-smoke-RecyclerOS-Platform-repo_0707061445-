# VS-018 Administration, Users & Role Permissions Test Cases

TC-001 Create User: user.created event is recorded.
TC-002 Assign Role: role assignment links user to role.
TC-003 Permission Check: role permissions define accessible capabilities and actions.
TC-004 Approval Authority: role can authorize procurement/finance/compliance/recommendation approvals.
TC-005 Deactivate User: user status changes without deleting audit history.
TC-006 Offline Permissions: app uses last known permissions while offline.
