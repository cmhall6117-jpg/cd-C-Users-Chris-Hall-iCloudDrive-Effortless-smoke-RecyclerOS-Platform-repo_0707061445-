ALTER TABLE sync_queue
ADD COLUMN IF NOT EXISTS related_object_type TEXT,
ADD COLUMN IF NOT EXISTS related_object_id TEXT,
ADD COLUMN IF NOT EXISTS last_error TEXT,
ADD COLUMN IF NOT EXISTS last_attempt_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS device_status_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_id TEXT NOT NULL,
    app_version TEXT NOT NULL,
    connection_status TEXT NOT NULL,
    battery_percent NUMERIC(5,2),
    pending_sync_count INTEGER NOT NULL DEFAULT 0,
    captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_device_status_device ON device_status_snapshots(device_id);
