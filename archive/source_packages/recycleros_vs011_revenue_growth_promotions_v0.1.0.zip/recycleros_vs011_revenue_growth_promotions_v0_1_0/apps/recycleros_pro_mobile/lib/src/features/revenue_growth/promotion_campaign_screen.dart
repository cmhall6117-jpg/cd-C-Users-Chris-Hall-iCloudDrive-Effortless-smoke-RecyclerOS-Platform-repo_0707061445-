import 'package:flutter/material.dart';

class PromotionCampaignScreen extends StatefulWidget {
  const PromotionCampaignScreen({super.key});

  @override
  State<PromotionCampaignScreen> createState() => _PromotionCampaignScreenState();
}

class _PromotionCampaignScreenState extends State<PromotionCampaignScreen> {
  final titleController = TextEditingController();
  final discountController = TextEditingController(text: '10');
  String channel = 'marketplace';

  @override
  void dispose() {
    titleController.dispose();
    discountController.dispose();
    super.dispose();
  }

  void saveCampaign() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Promotion campaign saved as draft. Sync pending.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final channels = ['facebook', 'instagram', 'ebay', 'marketplace', 'email', 'sms', 'manual'];

    return Scaffold(
      appBar: AppBar(title: const Text('Revenue Growth')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: saveCampaign,
        icon: const Icon(Icons.campaign),
        label: const Text('Save Campaign'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Promotion Campaign', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Card(
            child: ListTile(
              leading: Icon(Icons.lightbulb),
              title: Text('Recommendation'),
              subtitle: Text('Discount aging inventory only after checking margin, shelf life, and on-hand stock ratio.'),
            ),
          ),
          const SizedBox(height: 12),
          TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Campaign Title', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: channel,
            decoration: const InputDecoration(labelText: 'Promotion Channel', border: OutlineInputBorder()),
            items: channels.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (value) => setState(() => channel = value ?? channel),
          ),
          const SizedBox(height: 12),
          TextField(controller: discountController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Target Discount %', border: OutlineInputBorder())),
        ],
      ),
    );
  }
}
