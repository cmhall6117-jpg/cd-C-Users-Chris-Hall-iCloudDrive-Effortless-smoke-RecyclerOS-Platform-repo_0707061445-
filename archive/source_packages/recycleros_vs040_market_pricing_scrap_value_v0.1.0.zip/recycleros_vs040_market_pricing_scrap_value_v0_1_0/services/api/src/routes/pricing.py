from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class ScrapMetalValueCreate(BaseModel):
    material_type: str
    local_market: str
    unit: str = 'lb'
    price_per_unit: float

@router.post('/scrap-metal-values')
def create_scrap_metal_value(payload: ScrapMetalValueCreate):
    return {
        'scrap_metal_value_id': 'SMV-DEMO-000001',
        'material_type': payload.material_type,
        'local_market': payload.local_market,
        'unit': payload.unit,
        'price_per_unit': payload.price_per_unit,
        'captured_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'pricing.scrap_metal_value_recorded'
    }

@router.get('/recommendations/{inventory_item_id}')
def pricing_recommendation(inventory_item_id: str):
    return {
        'inventory_item_id': inventory_item_id,
        'recommended_action': 'hold',
        'reason': 'Current average market price is acceptable and shelf life is below discount threshold.',
        'confidence_score': 72,
        'event_created': 'pricing.recommendation_created'
    }
