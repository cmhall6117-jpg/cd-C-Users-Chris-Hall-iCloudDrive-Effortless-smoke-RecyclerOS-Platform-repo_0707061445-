# Manual Merge Checklist

- [ ] Create backup folder.
- [ ] Archive all source ZIPs.
- [ ] Merge feature folders.
- [ ] Preserve SQL migrations.
- [ ] Consolidate duplicate Dart models.
- [ ] Consolidate FastAPI routes.
- [ ] Register Flutter routes.
- [ ] Record issues in defect register.
