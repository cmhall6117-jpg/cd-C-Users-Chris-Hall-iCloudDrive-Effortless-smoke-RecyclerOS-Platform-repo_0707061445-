CREATE TABLE IF NOT EXISTS secret_references (
    id TEXT PRIMARY KEY,
    secret_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    environment_code TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT 'environment',
    status TEXT NOT NULL DEFAULT 'active',
    rotated_at TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS access_policies (
    id TEXT PRIMARY KEY,
    policy_code TEXT UNIQUE NOT NULL,
    capability TEXT NOT NULL,
    action TEXT NOT NULL,
    minimum_role_code TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
