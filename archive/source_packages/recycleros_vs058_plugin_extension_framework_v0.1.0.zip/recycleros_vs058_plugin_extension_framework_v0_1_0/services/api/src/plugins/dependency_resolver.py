from dataclasses import dataclass

@dataclass(frozen=True)
class DependencyResolution:
    is_satisfied: bool
    missing_dependencies: list[str]
    incompatible_dependencies: list[str]

def resolve_dependencies(
    manifest: dict,
    installed_versions: dict[str, str],
) -> DependencyResolution:
    missing: list[str] = []
    incompatible: list[str] = []

    for dependency in manifest.get('dependencies', []):
        plugin_id = dependency.get('plugin_id')
        constraint = dependency.get('version_constraint', '')
        installed_version = installed_versions.get(plugin_id)

        if installed_version is None:
            missing.append(plugin_id)
            continue

        # Scaffold comparison only. Replace with semantic-version library.
        if constraint.startswith('==') and installed_version != constraint[2:]:
            incompatible.append(plugin_id)

    return DependencyResolution(
        is_satisfied=not missing and not incompatible,
        missing_dependencies=missing,
        incompatible_dependencies=incompatible,
    )
