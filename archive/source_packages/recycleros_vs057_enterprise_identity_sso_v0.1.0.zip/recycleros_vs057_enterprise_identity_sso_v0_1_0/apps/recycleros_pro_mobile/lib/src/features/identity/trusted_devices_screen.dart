import 'package:flutter/material.dart';

class TrustedDevicesScreen extends StatelessWidget {
  const TrustedDevicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final devices = [
      ('iPhone 15', 'trusted • last seen today'),
      ('Warehouse Tablet', 'trusted • last seen yesterday'),
      ('Unknown Browser', 'revoked'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Trusted Devices')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Device Trust',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          for (final device in devices)
            Card(
              child: ListTile(
                leading: const Icon(Icons.devices),
                title: Text(device.$1),
                subtitle: Text(device.$2),
              ),
            ),
        ],
      ),
    );
  }
}
