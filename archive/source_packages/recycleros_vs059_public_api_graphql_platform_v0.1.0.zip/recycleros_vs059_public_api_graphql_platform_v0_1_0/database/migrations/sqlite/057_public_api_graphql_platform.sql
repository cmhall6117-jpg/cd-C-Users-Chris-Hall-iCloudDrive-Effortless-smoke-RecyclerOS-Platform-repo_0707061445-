CREATE TABLE IF NOT EXISTS developer_applications (
    id TEXT PRIMARY KEY,
    application_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    owner_account_id TEXT NOT NULL,
    environment_code TEXT NOT NULL DEFAULT 'sandbox',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS api_clients (
    id TEXT PRIMARY KEY,
    client_code TEXT UNIQUE NOT NULL,
    developer_application_id TEXT NOT NULL,
    client_identifier TEXT UNIQUE NOT NULL,
    client_secret_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS webhook_subscriptions (
    id TEXT PRIMARY KEY,
    webhook_code TEXT UNIQUE NOT NULL,
    developer_application_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    callback_url TEXT NOT NULL,
    signing_secret_hash TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
