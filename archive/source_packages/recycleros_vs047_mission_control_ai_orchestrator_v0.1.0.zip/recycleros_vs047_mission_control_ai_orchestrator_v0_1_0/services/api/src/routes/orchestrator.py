from datetime import datetime, timezone
from fastapi import APIRouter

router = APIRouter()

@router.get('/snapshot')
def orchestrator_snapshot():
    return {
        'snapshot_id': 'ORCH-DEMO-000001',
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'items': [
            {
                'action_code': 'ORCH-ACT-000001',
                'title': 'Review high-value refund approval hold',
                'category': 'risk',
                'priority': 'urgent',
                'priority_score': 96,
                'confidence_score': 91
            },
            {
                'action_code': 'ORCH-ACT-000002',
                'title': 'Procure Ford ECM opportunity before auction closes',
                'category': 'procurement',
                'priority': 'important',
                'priority_score': 88,
                'confidence_score': 82
            }
        ],
        'event_created': 'orchestrator.snapshot_generated'
    }
