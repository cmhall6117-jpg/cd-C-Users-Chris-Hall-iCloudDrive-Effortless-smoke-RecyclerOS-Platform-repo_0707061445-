CREATE TABLE IF NOT EXISTS kpi_snapshots (
    id TEXT PRIMARY KEY,
    snapshot_code TEXT UNIQUE NOT NULL,
    generated_at TEXT NOT NULL,
    open_opportunities INTEGER NOT NULL DEFAULT 0,
    active_pick_list_items INTEGER NOT NULL DEFAULT 0,
    inventory_available_count INTEGER NOT NULL DEFAULT 0,
    pending_sync_count INTEGER NOT NULL DEFAULT 0,
    sales_today REAL NOT NULL DEFAULT 0,
    projected_opportunity_value REAL NOT NULL DEFAULT 0,
    inventory_accuracy_percent REAL NOT NULL DEFAULT 0,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
