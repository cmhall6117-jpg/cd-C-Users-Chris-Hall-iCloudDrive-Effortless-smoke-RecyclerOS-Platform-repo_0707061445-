import 'package:flutter/material.dart';

class DefectRegisterScreen extends StatelessWidget {
  const DefectRegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final defects = [
      ('DEF-000001', 'Flutter import cleanup required', 'High', 'open'),
      ('DEF-000002', 'SQLite migration guard needed', 'Medium', 'triaged'),
      ('DEF-000003', 'FastAPI router merge pending', 'High', 'open'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Defect Register')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Issues & Technical Debt', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Track integration blockers, compile errors, migration issues, and deferred technical debt.'),
          const SizedBox(height: 16),
          for (final defect in defects)
            Card(
              child: ListTile(
                leading: const Icon(Icons.bug_report),
                title: Text('${defect.$1}: ${defect.$2}'),
                subtitle: Text('Severity: ${defect.$3} • Status: ${defect.$4}'),
              ),
            ),
        ],
      ),
    );
  }
}
