class SecretReference {
  final String secretReferenceId;
  final String secretCode;
  final String name;
  final String environmentCode;
  final String provider;
  final String status;
  final DateTime? rotatedAt;
  final DateTime createdAt;

  const SecretReference({
    required this.secretReferenceId,
    required this.secretCode,
    required this.name,
    required this.environmentCode,
    required this.provider,
    required this.status,
    this.rotatedAt,
    required this.createdAt,
  });
}
