# VS-023 Defect Register & Issue Management Test Cases

TC-001 Create Defect: defect.created event is recorded.
TC-002 List Defects: defect list returns severity and status.
TC-003 Technical Debt: technical debt record can be created.
TC-004 Status Change: defect can move through open, triaged, in_progress, resolved, deferred, closed.
TC-005 Release Binder Link: defects can be included in RB-003 release readiness review.
