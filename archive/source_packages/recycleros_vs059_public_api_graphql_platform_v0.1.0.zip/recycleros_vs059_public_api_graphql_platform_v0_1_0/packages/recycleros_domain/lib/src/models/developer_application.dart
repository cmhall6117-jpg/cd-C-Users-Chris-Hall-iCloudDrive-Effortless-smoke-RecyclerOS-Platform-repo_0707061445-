class DeveloperApplication {
  final String developerApplicationId;
  final String applicationCode;
  final String name;
  final String ownerAccountId;
  final String environmentCode;
  final String status;
  final DateTime createdAt;

  const DeveloperApplication({
    required this.developerApplicationId,
    required this.applicationCode,
    required this.name,
    required this.ownerAccountId,
    required this.environmentCode,
    required this.status,
    required this.createdAt,
  });
}
