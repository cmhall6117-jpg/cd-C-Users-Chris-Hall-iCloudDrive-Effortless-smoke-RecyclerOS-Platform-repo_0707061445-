class FinanceEventTypes {
  static const financialTransactionCreated = 'financial.transaction_created';
  static const revenueRecognized = 'revenue.recognized';
  static const expenseRecorded = 'expense.recorded';
  static const inventoryValueUpdated = 'inventory.value_updated';
  static const vehicleProfitSnapshotGenerated = 'vehicle.profit_snapshot_generated';
}
