class SocialChannelProfile {
  final String socialChannelProfileId;
  final String profileCode;
  final String channel;
  final String displayName;
  final String status;
  final DateTime createdAt;

  const SocialChannelProfile({
    required this.socialChannelProfileId,
    required this.profileCode,
    required this.channel,
    required this.displayName,
    required this.status,
    required this.createdAt,
  });
}
