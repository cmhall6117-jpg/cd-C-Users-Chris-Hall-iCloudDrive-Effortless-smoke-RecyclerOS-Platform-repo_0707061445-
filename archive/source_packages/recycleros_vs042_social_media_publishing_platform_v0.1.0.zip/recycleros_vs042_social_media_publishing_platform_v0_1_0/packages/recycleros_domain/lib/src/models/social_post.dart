class SocialPost {
  final String socialPostId;
  final String postCode;
  final String channel;
  final String body;
  final String status;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime createdAt;
  final DateTime? scheduledAt;
  final DateTime? postedAt;

  const SocialPost({
    required this.socialPostId,
    required this.postCode,
    required this.channel,
    required this.body,
    required this.status,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.createdAt,
    this.scheduledAt,
    this.postedAt,
  });
}
