# Release Gate Matrix

| Gate | Requirement | Evidence | Status |
|---|---|---|---|
| G-01 | Repository assembled | Commit and tree | Blocked |
| G-02 | Backend starts | CI log | Blocked |
| G-03 | Flutter compiles | CI log | Blocked |
| G-04 | PostgreSQL migrations pass | Migration log | Blocked |
| G-05 | SQLite initializes | Test log | Blocked |
| G-06 | Core working path passes | Smoke-test report | Blocked |
| G-07 | Tenant isolation passes | Security test report | Blocked |
| G-08 | Critical defects closed | Defect register | Blocked |
| G-09 | Backup/restore validated | Recovery report | Blocked |
| G-10 | Product Owner approval | Signed acceptance | Blocked |
