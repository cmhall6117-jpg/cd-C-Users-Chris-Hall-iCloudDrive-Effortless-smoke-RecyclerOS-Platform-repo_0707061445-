class PackagingProfile {
  final String packagingProfileId;
  final String profileCode;
  final String name;
  final double lengthInches;
  final double widthInches;
  final double heightInches;
  final double weightPounds;
  final DateTime createdAt;

  const PackagingProfile({
    required this.packagingProfileId,
    required this.profileCode,
    required this.name,
    required this.lengthInches,
    required this.widthInches,
    required this.heightInches,
    required this.weightPounds,
    required this.createdAt,
  });
}
