from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class PipelineRunCreate(BaseModel):
    branch_name: str
    commit_sha: str
    summary: str = ''

@router.post('/pipeline-runs')
def create_pipeline_run(payload: PipelineRunCreate):
    return {
        'pipeline_run_id': 'CIR-DEMO-000001',
        'run_code': 'CI-000001',
        'branch_name': payload.branch_name,
        'commit_sha': payload.commit_sha,
        'status': 'started',
        'summary': payload.summary,
        'started_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'devops.pipeline_run_started'
    }
