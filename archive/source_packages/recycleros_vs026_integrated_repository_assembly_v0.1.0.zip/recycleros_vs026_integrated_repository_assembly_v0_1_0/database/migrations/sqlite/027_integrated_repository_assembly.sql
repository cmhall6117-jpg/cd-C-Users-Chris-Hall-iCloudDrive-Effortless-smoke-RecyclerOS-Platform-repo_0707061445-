CREATE TABLE IF NOT EXISTS repository_assembly_runs (
    id TEXT PRIMARY KEY,
    assembly_run_code TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'planned',
    target_build TEXT NOT NULL,
    started_at TEXT,
    completed_at TEXT,
    notes TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
