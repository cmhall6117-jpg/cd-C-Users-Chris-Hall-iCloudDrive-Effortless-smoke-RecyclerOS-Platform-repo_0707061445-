class DashboardEventTypes {
  static const dashboardViewed = 'dashboard.viewed';
  static const kpiSnapshotGenerated = 'kpi.snapshot_generated';
  static const syncHealthChecked = 'sync.health_checked';
}
