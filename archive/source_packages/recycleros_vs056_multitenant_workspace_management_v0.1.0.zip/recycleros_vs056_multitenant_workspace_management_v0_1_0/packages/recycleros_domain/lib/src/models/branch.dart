class Branch {
  final String branchId;
  final String branchCode;
  final String workspaceId;
  final String name;
  final String? addressLine;
  final String? city;
  final String? stateCode;
  final String status;
  final DateTime createdAt;

  const Branch({
    required this.branchId,
    required this.branchCode,
    required this.workspaceId,
    required this.name,
    this.addressLine,
    this.city,
    this.stateCode,
    required this.status,
    required this.createdAt,
  });
}
