import 'package:flutter/material.dart';

class InventoryPerformanceScreen extends StatelessWidget {
  const InventoryPerformanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final alerts = [
      ('ECM / PCM', 'Shelf life 92 days • recommend 10% special sale'),
      ('LED Headlight LH', 'On-hand above stock limit • avoid procurement'),
      ('Transmission', 'High return ratio • inspect listing/condition'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Inventory Performance')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Shelf-Life & Stock Intelligence', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Use shelf life, return ratio, and on-hand stock to guide special sales and procurement limits.'),
          const SizedBox(height: 16),
          for (final alert in alerts)
            Card(child: ListTile(leading: const Icon(Icons.trending_down), title: Text(alert.$1), subtitle: Text(alert.$2))),
        ],
      ),
    );
  }
}
