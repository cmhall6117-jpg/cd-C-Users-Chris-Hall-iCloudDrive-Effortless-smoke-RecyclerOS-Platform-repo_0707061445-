from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class MediaAssetCreate(BaseModel):
    media_type: str
    file_name: str
    related_object_type: str | None = None
    related_object_id: str | None = None

@router.post('/assets')
def create_media_asset(payload: MediaAssetCreate):
    return {
        'media_asset_id': 'MED-DEMO-000001',
        'media_code': 'MED-000001',
        'media_type': payload.media_type,
        'file_name': payload.file_name,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'captured_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'media.captured'
    }
