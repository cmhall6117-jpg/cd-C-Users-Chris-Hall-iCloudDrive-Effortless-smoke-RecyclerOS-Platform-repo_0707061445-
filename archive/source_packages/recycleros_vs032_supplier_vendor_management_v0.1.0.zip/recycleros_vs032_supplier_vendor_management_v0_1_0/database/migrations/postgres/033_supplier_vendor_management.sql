CREATE TABLE IF NOT EXISTS vendors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    vendor_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    phone TEXT,
    email TEXT,
    website_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vendor_performance_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id UUID REFERENCES vendors(id),
    reliability_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    cost_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    service_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    notes TEXT,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
