CREATE TABLE IF NOT EXISTS customer_leads (
    id TEXT PRIMARY KEY,
    lead_code TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'new',
    source_channel TEXT NOT NULL,
    customer_id TEXT,
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS outreach_activities (
    id TEXT PRIMARY KEY,
    lead_id TEXT NOT NULL,
    channel TEXT NOT NULL,
    message_summary TEXT NOT NULL,
    occurred_at TEXT NOT NULL,
    follow_up_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
