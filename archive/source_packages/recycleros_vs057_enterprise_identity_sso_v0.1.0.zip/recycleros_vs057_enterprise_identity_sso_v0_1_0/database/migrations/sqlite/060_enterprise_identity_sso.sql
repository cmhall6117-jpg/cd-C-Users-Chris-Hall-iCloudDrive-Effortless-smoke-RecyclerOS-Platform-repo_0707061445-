CREATE TABLE IF NOT EXISTS identity_providers (
    id TEXT PRIMARY KEY,
    provider_code TEXT UNIQUE NOT NULL,
    organization_id TEXT NOT NULL,
    provider_type TEXT NOT NULL,
    display_name TEXT NOT NULL,
    issuer_url TEXT NOT NULL,
    client_id_reference TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS user_identities (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    identity_provider_id TEXT NOT NULL,
    provider_subject TEXT NOT NULL,
    email TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    linked_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS enterprise_login_sessions (
    id TEXT PRIMARY KEY,
    session_code TEXT UNIQUE NOT NULL,
    user_id TEXT,
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    revoked_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS trusted_devices (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    display_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'trusted',
    registered_at TEXT NOT NULL,
    last_seen_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS authentication_policies (
    id TEXT PRIMARY KEY,
    organization_id TEXT NOT NULL,
    policy_code TEXT NOT NULL,
    require_mfa INTEGER NOT NULL DEFAULT 1,
    require_trusted_device INTEGER NOT NULL DEFAULT 0,
    max_session_hours INTEGER NOT NULL DEFAULT 8,
    max_concurrent_sessions INTEGER NOT NULL DEFAULT 5,
    allow_local_login INTEGER NOT NULL DEFAULT 1,
    is_active INTEGER NOT NULL DEFAULT 1,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
