class SalesForecastSnapshot {
  final String salesForecastSnapshotId;
  final String snapshotCode;
  final double projectedRevenue;
  final double weightedRevenue;
  final int openLeadCount;
  final int openListingCount;
  final DateTime generatedAt;

  const SalesForecastSnapshot({
    required this.salesForecastSnapshotId,
    required this.snapshotCode,
    required this.projectedRevenue,
    required this.weightedRevenue,
    required this.openLeadCount,
    required this.openListingCount,
    required this.generatedAt,
  });
}
