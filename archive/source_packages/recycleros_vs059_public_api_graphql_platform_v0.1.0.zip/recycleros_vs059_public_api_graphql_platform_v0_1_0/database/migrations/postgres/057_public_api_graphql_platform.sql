CREATE TABLE IF NOT EXISTS developer_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    application_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    owner_account_id TEXT NOT NULL,
    environment_code TEXT NOT NULL DEFAULT 'sandbox',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS api_clients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_code TEXT UNIQUE NOT NULL,
    developer_application_id UUID REFERENCES developer_applications(id),
    client_identifier TEXT UNIQUE NOT NULL,
    client_secret_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS webhook_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_code TEXT UNIQUE NOT NULL,
    developer_application_id UUID REFERENCES developer_applications(id),
    event_type TEXT NOT NULL,
    callback_url TEXT NOT NULL,
    signing_secret_hash TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
