class BackupJob {
  final String backupJobId;
  final String backupCode;
  final String backupType;
  final String status;
  final int recordCount;
  final String? fileReference;
  final DateTime createdAt;
  final DateTime? completedAt;

  const BackupJob({
    required this.backupJobId,
    required this.backupCode,
    required this.backupType,
    required this.status,
    required this.recordCount,
    this.fileReference,
    required this.createdAt,
    this.completedAt,
  });
}
