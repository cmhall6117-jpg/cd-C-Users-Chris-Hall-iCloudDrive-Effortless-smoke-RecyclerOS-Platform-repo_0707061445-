# AI Automation Governance

1. Every automation belongs to one organization and workspace.
2. Sensitive actions require explicit approval.
3. Test runs must not change production data.
4. Model credentials are referenced through secrets management only.
5. Automation definitions and versions are immutable once published.
6. Execution logs must retain inputs, outputs, errors, and approvals.
7. Disabled automations must not execute.
8. Plugin-provided actions must honor plugin permission scopes.
9. AI output must be treated as a recommendation unless the action is explicitly authorized.
10. Financial, legal, compliance, deletion, refund, and publishing actions require human review by default.
