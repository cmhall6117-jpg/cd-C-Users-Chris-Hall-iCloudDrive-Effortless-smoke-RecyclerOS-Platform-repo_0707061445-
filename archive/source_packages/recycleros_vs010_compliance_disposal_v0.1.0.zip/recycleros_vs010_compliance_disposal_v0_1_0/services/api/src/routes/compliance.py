from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class DisposalRecordCreate(BaseModel):
    material_type: str
    vehicle_id: str | None = None
    quantity: float | None = None
    unit: str | None = None
    disposal_vendor: str
    jurisdiction: str = 'local'

@router.post('/disposal-records')
def create_disposal_record(payload: DisposalRecordCreate):
    return {
        'disposal_record_id': 'DSP-DEMO-000001',
        'disposal_code': 'DSP-000001',
        'material_type': payload.material_type,
        'vehicle_id': payload.vehicle_id,
        'quantity': payload.quantity,
        'unit': payload.unit,
        'disposal_vendor': payload.disposal_vendor,
        'jurisdiction': payload.jurisdiction,
        'disposed_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'disposal.record_created',
        'disclaimer': 'Decision-support record only. Verify applicable regulations with qualified sources.'
    }
