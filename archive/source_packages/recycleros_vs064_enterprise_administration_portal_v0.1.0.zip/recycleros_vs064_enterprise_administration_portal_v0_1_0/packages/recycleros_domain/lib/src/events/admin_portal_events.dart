class AdminPortalEventTypes {
  static const dashboardSnapshotGenerated = 'admin.dashboard_snapshot_generated';
  static const organizationUpdated = 'admin.organization_updated';
  static const membershipUpdated = 'admin.membership_updated';
  static const roleAssignmentUpdated = 'admin.role_assignment_updated';
  static const licenseUpdated = 'admin.license_updated';
  static const integrationUpdated = 'admin.integration_updated';
  static const securityPolicyUpdated = 'admin.security_policy_updated';
  static const deploymentReviewed = 'admin.deployment_reviewed';
}
