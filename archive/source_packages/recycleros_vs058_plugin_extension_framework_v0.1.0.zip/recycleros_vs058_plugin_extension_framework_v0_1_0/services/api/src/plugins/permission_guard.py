from fastapi import HTTPException

def require_plugin_permissions(
    requested_permissions: set[str],
    approved_permissions: set[str],
) -> None:
    missing = requested_permissions.difference(approved_permissions)

    if missing:
        raise HTTPException(
            status_code=403,
            detail={
                'message': 'Plugin permission denied.',
                'missing_permissions': sorted(missing),
            },
        )
