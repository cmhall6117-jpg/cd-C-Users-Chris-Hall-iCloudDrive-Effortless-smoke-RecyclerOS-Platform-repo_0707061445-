class WorkflowEventTypes {
  static const playbookCreated = 'workflow.playbook_created';
  static const workflowRunStarted = 'workflow.run_started';
  static const workflowStepCompleted = 'workflow.step_completed';
  static const workflowRunCompleted = 'workflow.run_completed';
  static const workflowApprovalRequired = 'workflow.approval_required';
}
