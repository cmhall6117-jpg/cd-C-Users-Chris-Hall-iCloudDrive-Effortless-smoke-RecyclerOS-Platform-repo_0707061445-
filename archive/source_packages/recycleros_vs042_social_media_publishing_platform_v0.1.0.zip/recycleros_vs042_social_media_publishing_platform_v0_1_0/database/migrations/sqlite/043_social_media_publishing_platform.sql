CREATE TABLE IF NOT EXISTS social_channel_profiles (
    id TEXT PRIMARY KEY,
    profile_code TEXT UNIQUE NOT NULL,
    channel TEXT NOT NULL,
    display_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS social_posts (
    id TEXT PRIMARY KEY,
    post_code TEXT UNIQUE NOT NULL,
    channel TEXT NOT NULL,
    body TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TEXT NOT NULL,
    scheduled_at TEXT,
    posted_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
