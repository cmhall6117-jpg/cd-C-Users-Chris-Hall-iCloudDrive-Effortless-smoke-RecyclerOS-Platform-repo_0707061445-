import 'package:flutter/material.dart';

class AutomationStudioScreen extends StatelessWidget {
  const AutomationStudioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final automations = [
      ('Aging Inventory Sale', 'active • approval before posting'),
      ('Auction Opportunity Alert', 'active • notify only'),
      ('High-Value Refund Review', 'draft • risk approval required'),
      ('Weekly Executive Summary', 'active • scheduled'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('AI Automation Studio')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Automations & Agents',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const Text(
            'Build trigger-condition-action workflows with AI steps and approval gates.',
          ),
          const SizedBox(height: 16),
          for (final automation in automations)
            Card(
              child: ListTile(
                leading: const Icon(Icons.auto_fix_high),
                title: Text(automation.$1),
                subtitle: Text(automation.$2),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
