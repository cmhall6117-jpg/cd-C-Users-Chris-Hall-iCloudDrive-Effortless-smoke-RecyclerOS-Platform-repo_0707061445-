class AutomationStep {
  final String automationStepId;
  final String automationDefinitionId;
  final int stepOrder;
  final String stepType;
  final String name;
  final String configurationJson;
  final bool requiresApproval;

  const AutomationStep({
    required this.automationStepId,
    required this.automationDefinitionId,
    required this.stepOrder,
    required this.stepType,
    required this.name,
    required this.configurationJson,
    required this.requiresApproval,
  });
}
