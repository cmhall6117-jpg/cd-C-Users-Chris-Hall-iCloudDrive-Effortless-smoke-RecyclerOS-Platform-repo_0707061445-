CREATE TABLE IF NOT EXISTS return_authorizations (
    id TEXT PRIMARY KEY,
    return_code TEXT UNIQUE NOT NULL,
    sales_order_id TEXT NOT NULL,
    inventory_item_id TEXT NOT NULL,
    reason_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'authorized',
    refund_amount REAL,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS warranty_claims (
    id TEXT PRIMARY KEY,
    claim_code TEXT UNIQUE NOT NULL,
    return_authorization_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    notes TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
