from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class ListingCreate(BaseModel):
    inventory_item_id: str
    channel: str = 'manual'
    title: str
    description: str = ''
    price: float

@router.post('/listings')
def create_listing(payload: ListingCreate):
    return {
        'listing_id': 'LST-DEMO-000001',
        'listing_code': 'LST-000001',
        'inventory_item_id': payload.inventory_item_id,
        'channel': payload.channel,
        'title': payload.title,
        'description': payload.description,
        'price': payload.price,
        'status': 'draft',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'listing.created'
    }

@router.post('/listings/{listing_id}/publish')
def publish_listing(listing_id: str):
    return {
        'listing_id': listing_id,
        'status': 'published',
        'published_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'listing.published'
    }
