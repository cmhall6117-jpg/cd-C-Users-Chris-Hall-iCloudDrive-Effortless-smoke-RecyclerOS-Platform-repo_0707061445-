CREATE TABLE IF NOT EXISTS compliance_records (
    id TEXT PRIMARY KEY,
    compliance_code TEXT UNIQUE NOT NULL,
    record_type TEXT NOT NULL,
    vehicle_id TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    jurisdiction TEXT NOT NULL DEFAULT 'local',
    notes TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS disposal_records (
    id TEXT PRIMARY KEY,
    disposal_code TEXT UNIQUE NOT NULL,
    material_type TEXT NOT NULL,
    vehicle_id TEXT,
    quantity REAL,
    unit TEXT,
    disposal_vendor TEXT NOT NULL,
    jurisdiction TEXT NOT NULL DEFAULT 'local',
    disposed_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
