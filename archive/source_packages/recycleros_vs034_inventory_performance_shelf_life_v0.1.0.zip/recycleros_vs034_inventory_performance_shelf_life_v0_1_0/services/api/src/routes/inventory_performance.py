from datetime import datetime, timezone
from fastapi import APIRouter

router = APIRouter()

@router.get('/recommendations')
def inventory_performance_recommendations():
    return {
        'items': [{
            'inventory_item_id': 'INV-DEMO-000001',
            'part_name': 'ECM / PCM',
            'reason': 'Shelf life exceeds target and sell-through is below threshold.',
            'suggested_action': 'Recommend 10 percent special sale',
            'event_created': 'inventory_performance.special_sale_recommended'
        }],
        'generated_at': datetime.now(timezone.utc).isoformat()
    }

@router.get('/procurement-check/{part_category}')
def procurement_limit_check(part_category: str):
    return {
        'part_category': part_category,
        'current_on_hand': 12,
        'max_on_hand_quantity': 8,
        'recommendation': 'Do not procure additional items until stock falls below target.',
        'event_created': 'inventory_performance.procurement_limit_warning'
    }
