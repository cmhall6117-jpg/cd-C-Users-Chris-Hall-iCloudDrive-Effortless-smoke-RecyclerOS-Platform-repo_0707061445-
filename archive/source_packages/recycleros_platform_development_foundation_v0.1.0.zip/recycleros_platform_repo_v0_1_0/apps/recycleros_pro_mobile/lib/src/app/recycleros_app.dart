import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/mission_control/mission_control_screen.dart';
import '../features/opportunity_discovery/opportunity_discovery_screen.dart';

class RecyclerOSApp extends StatelessWidget {
  const RecyclerOSApp({super.key});

  @override
  Widget build(BuildContext context) {
    final router = GoRouter(routes: [
      GoRoute(path: '/', builder: (_, __) => const MissionControlScreen()),
      GoRoute(path: '/opportunities', builder: (_, __) => const OpportunityDiscoveryScreen()),
    ]);

    return MaterialApp.router(
      title: 'RecyclerOS Pro',
      theme: ThemeData(useMaterial3: true),
      routerConfig: router,
    );
  }
}
