import 'package:flutter/material.dart';

class CycleCountScreen extends StatefulWidget {
  const CycleCountScreen({super.key});

  @override
  State<CycleCountScreen> createState() => _CycleCountScreenState();
}

class _CycleCountScreenState extends State<CycleCountScreen> {
  final countedController = TextEditingController(text: '1');

  @override
  void dispose() {
    countedController.dispose();
    super.dispose();
  }

  void completeCount() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Cycle count saved locally. Sync pending.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = [
      ('INV-000001', 'ECM / PCM', 'Expected: 1'),
      ('INV-000002', 'LED Headlight LH', 'Expected: 1'),
      ('INV-000003', 'Transmission', 'Expected: 1'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Cycle Count')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: completeCount,
        icon: const Icon(Icons.check),
        label: const Text('Complete Count'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Cycle Count Audit', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Location: Rack A / Shelf 1'),
          const SizedBox(height: 16),
          for (final item in items)
            Card(
              child: ListTile(
                leading: const Icon(Icons.fact_check),
                title: Text(item.$2),
                subtitle: Text('${item.$1} • ${item.$3}'),
                trailing: SizedBox(
                  width: 64,
                  child: TextField(
                    controller: countedController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Count'),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 16),
          const Card(
            child: ListTile(
              leading: Icon(Icons.analytics),
              title: Text('Inventory Accuracy Index'),
              subtitle: Text('Calculated after count completion.'),
            ),
          )
        ],
      ),
    );
  }
}
