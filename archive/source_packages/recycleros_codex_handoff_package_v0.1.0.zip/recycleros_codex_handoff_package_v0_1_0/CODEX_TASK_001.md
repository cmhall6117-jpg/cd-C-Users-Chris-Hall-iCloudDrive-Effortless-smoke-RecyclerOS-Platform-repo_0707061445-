# CODEX-TASK-001 — Create First Integrated RecyclerOS Repository

## Mission
Create the first integrated local RecyclerOS repository using the generated scaffold packages.

## Start With These Packages Only
1. DF-001 Development Foundation
2. VS-001 Opportunity Discovery
3. VS-002 Vehicle Digital Twin
4. VS-003 Procurement Workspace
5. VS-004 Pick List & Focus Point
6. VS-005 Inventory Intake
7. VS-021 Integration Readiness & Smoke Test Harness
8. VS-022 Local Integration Bundle

## Primary Goal
Create the first MVP shell path:

Mission Control → Opportunity Discovery → Create Opportunity → API Response → Business Event

## Tasks
- Merge package contents into one monorepo.
- Preserve documentation and SQL migrations.
- Register FastAPI routers.
- Register Flutter routes.
- Resolve duplicate Dart models/enums.
- Run flutter pub get.
- Run flutter analyze.
- Run backend import/startup check.
- Validate first six PostgreSQL migrations.
- Create documentation/defects/DEFECT_REGISTER.md.
- Create documentation/assumptions/ASSUMPTIONS.md.

## Constraints
- Do not merge all 26 packages yet.
- Do not delete generated docs.
- Do not silently drop migrations.
- Do not rewrite architecture.
- Record every unresolved issue.

## Deliverables
1. Integrated repository structure.
2. Updated README.md.
3. Working or partially working Flutter shell.
4. Working or partially working FastAPI app.
5. Defect register.
6. Assumptions log.
7. Next recommended Codex task.
