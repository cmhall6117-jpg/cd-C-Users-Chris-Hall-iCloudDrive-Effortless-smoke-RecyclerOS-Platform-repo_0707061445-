CREATE TABLE IF NOT EXISTS cycle_count_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cycle_count_code TEXT UNIQUE NOT NULL,
    storage_location_id UUID REFERENCES storage_locations(id),
    status TEXT NOT NULL DEFAULT 'active',
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    performed_by TEXT
);

CREATE TABLE IF NOT EXISTS cycle_count_lines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cycle_count_session_id UUID REFERENCES cycle_count_sessions(id),
    inventory_item_id UUID REFERENCES inventory_items(id),
    expected_quantity INTEGER NOT NULL DEFAULT 0,
    counted_quantity INTEGER NOT NULL DEFAULT 0,
    variance INTEGER NOT NULL DEFAULT 0,
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_cycle_count_sessions_status ON cycle_count_sessions(status);
CREATE INDEX IF NOT EXISTS idx_cycle_count_lines_inventory_item ON cycle_count_lines(inventory_item_id);
