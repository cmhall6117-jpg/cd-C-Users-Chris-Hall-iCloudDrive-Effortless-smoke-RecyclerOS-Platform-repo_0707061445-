# VS-062 AI Automation Studio Test Cases

TC-001 Create Automation: automation_studio.automation_created event is recorded.
TC-002 Tenant Scope: automation stores organization and workspace IDs.
TC-003 Test Run: test mode completes steps without modifying production data.
TC-004 Approval Gate: sensitive action pauses the run.
TC-005 Run Completion: automation_studio.run_completed event is recorded.
TC-006 Version History: published automation versions are preserved.
TC-007 Agent Profile: reusable AI agent stores purpose and model reference.
TC-008 Secrets Safety: model credentials are referenced, not stored.
TC-009 Plugin Action: plugin-provided action respects approved plugin permissions.
TC-010 Offline Metadata: automation metadata saves locally with sync_status pending.
