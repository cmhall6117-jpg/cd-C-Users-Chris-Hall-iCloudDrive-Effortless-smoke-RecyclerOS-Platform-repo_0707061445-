CREATE TABLE IF NOT EXISTS backup_jobs (
    id TEXT PRIMARY KEY,
    backup_code TEXT UNIQUE NOT NULL,
    backup_type TEXT NOT NULL DEFAULT 'manual',
    status TEXT NOT NULL DEFAULT 'created',
    record_count INTEGER NOT NULL DEFAULT 0,
    file_reference TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS restore_jobs (
    id TEXT PRIMARY KEY,
    restore_code TEXT UNIQUE NOT NULL,
    backup_job_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS data_retention_policies (
    id TEXT PRIMARY KEY,
    policy_code TEXT UNIQUE NOT NULL,
    object_type TEXT NOT NULL,
    retention_days INTEGER NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
