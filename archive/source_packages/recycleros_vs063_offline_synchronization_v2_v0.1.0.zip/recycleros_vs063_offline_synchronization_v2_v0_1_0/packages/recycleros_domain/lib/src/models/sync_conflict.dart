class SyncConflict {
  final String syncConflictId;
  final String organizationId;
  final String workspaceId;
  final String entityType;
  final String entityId;
  final String localPayloadJson;
  final String serverPayloadJson;
  final String mergeStrategy;
  final String status;
  final DateTime detectedAt;

  const SyncConflict({
    required this.syncConflictId,
    required this.organizationId,
    required this.workspaceId,
    required this.entityType,
    required this.entityId,
    required this.localPayloadJson,
    required this.serverPayloadJson,
    required this.mergeStrategy,
    required this.status,
    required this.detectedAt,
  });
}
