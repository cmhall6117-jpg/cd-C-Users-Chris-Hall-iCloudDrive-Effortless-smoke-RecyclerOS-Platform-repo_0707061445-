# VS-057 Enterprise Identity & Single Sign-On Test Cases

TC-001 Create Identity Provider: identity.provider_linked event is recorded.
TC-002 Organization Scope: provider belongs to one organization.
TC-003 PKCE: code verifier and code challenge can be generated.
TC-004 Enterprise Login: login session stores organization, workspace, and device.
TC-005 MFA Required: organization policy can require MFA.
TC-006 Verify MFA: identity.mfa_verified event is recorded.
TC-007 Revoke Session: identity.session_revoked event is recorded.
TC-008 Trusted Device: device can be registered and revoked.
TC-009 Offline Session: cached session cannot exceed policy expiration.
TC-010 Secret Safety: client secret values are represented by references only.
