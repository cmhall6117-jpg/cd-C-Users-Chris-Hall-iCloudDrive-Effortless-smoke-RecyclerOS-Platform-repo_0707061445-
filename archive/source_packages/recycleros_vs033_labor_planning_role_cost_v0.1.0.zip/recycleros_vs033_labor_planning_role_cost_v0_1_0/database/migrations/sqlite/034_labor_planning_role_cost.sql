CREATE TABLE IF NOT EXISTS labor_role_profiles (
    id TEXT PRIMARY KEY,
    role_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    skill_level TEXT NOT NULL,
    employment_type TEXT NOT NULL,
    base_pay_min REAL,
    base_pay_max REAL,
    currency TEXT NOT NULL DEFAULT 'USD',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS labor_entries (
    id TEXT PRIMARY KEY,
    labor_entry_code TEXT UNIQUE NOT NULL,
    user_id TEXT,
    role_code TEXT NOT NULL,
    hours REAL NOT NULL,
    hourly_rate REAL NOT NULL,
    total_cost REAL NOT NULL,
    related_object_type TEXT,
    related_object_id TEXT,
    worked_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
