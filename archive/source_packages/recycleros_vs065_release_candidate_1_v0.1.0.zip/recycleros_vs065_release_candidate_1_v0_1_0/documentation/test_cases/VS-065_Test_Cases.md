# VS-065 Release Candidate 1 Test Cases

TC-001 Release Scope Exists.
TC-002 Go/No-Go Checklist Exists.
TC-003 Release Gate Matrix Exists.
TC-004 Known Defect Register Exists.
TC-005 Migration Manifest Exists.
TC-006 Codex RC1 Integration Task Exists.
TC-007 Core Working Path Is Defined.
TC-008 Tenant-Isolation Gate Is Defined.
TC-009 Security and Backup Gates Are Defined.
TC-010 Product Owner Acceptance Gate Is Defined.
TC-011 No Gate Is Marked Passed Without Evidence.
TC-012 RC1 Status Register Is Machine Readable.
