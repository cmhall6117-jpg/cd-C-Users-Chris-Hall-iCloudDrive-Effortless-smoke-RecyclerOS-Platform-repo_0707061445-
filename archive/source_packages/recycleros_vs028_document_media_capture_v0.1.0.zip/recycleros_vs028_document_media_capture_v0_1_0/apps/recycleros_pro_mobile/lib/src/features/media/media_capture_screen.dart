import 'package:flutter/material.dart';

class MediaCaptureScreen extends StatelessWidget {
  const MediaCaptureScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final attachments = [
      ('Vehicle Photo', 'VEH-000001 front damage'),
      ('Inventory Photo', 'INV-000001 ECM label'),
      ('Compliance Receipt', 'DSP-000001 disposal receipt'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Document & Media Capture')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: null,
        icon: const Icon(Icons.camera_alt),
        label: const Text('Capture'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Attachments', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Camera, gallery, and file upload wiring pending.'),
          const SizedBox(height: 16),
          for (final item in attachments)
            Card(child: ListTile(leading: const Icon(Icons.attach_file), title: Text(item.$1), subtitle: Text(item.$2))),
        ],
      ),
    );
  }
}
