class AdminDashboardSnapshot {
  final String adminDashboardSnapshotId;
  final int organizationCount;
  final int workspaceCount;
  final int activeUserCount;
  final int activeLicenseCount;
  final int installedIntegrationCount;
  final int openSecurityIssueCount;
  final String platformHealthStatus;
  final DateTime generatedAt;

  const AdminDashboardSnapshot({
    required this.adminDashboardSnapshotId,
    required this.organizationCount,
    required this.workspaceCount,
    required this.activeUserCount,
    required this.activeLicenseCount,
    required this.installedIntegrationCount,
    required this.openSecurityIssueCount,
    required this.platformHealthStatus,
    required this.generatedAt,
  });
}
