class PluginEventTypes {
  static const pluginDiscovered = 'plugin.discovered';
  static const pluginValidated = 'plugin.validated';
  static const pluginInstalled = 'plugin.installed';
  static const pluginEnabled = 'plugin.enabled';
  static const pluginDisabled = 'plugin.disabled';
  static const pluginUpgradeStarted = 'plugin.upgrade_started';
  static const pluginUpgradeCompleted = 'plugin.upgrade_completed';
  static const pluginRollbackCompleted = 'plugin.rollback_completed';
  static const pluginUninstalled = 'plugin.uninstalled';
  static const pluginPermissionDenied = 'plugin.permission_denied';
}
