from datetime import datetime, timezone
from fastapi import APIRouter
from schemas.vehicle import VehicleCreate

router = APIRouter()

@router.post("")
def create_vehicle(payload: VehicleCreate):
    now = datetime.now(timezone.utc)
    return {
        "vehicle_id": "VEH-DEMO-000001",
        "vehicle_code": "VEH-000001",
        "vin": payload.vin,
        "year": payload.year,
        "make": payload.make,
        "model": payload.model,
        "lifecycle_status": "discovered",
        "created_at": now.isoformat(),
        "event_created": {
            "event_type": "vehicle.evaluated",
            "event_code": "EVT-DEMO-000002"
        }
    }

@router.get("/{vehicle_code}")
def get_vehicle(vehicle_code: str):
    return {
        "vehicle_id": "VEH-DEMO-000001",
        "vehicle_code": vehicle_code,
        "vin": "DEMO-VIN-PENDING",
        "year": 2019,
        "make": "Ford",
        "model": "F-150",
        "lifecycle_status": "activeHarvest",
        "timeline": [
            {"event_type": "opportunity.discovered", "title": "Opportunity Discovered"},
            {"event_type": "vehicle.evaluated", "title": "Vehicle Evaluated"},
            {"event_type": "vehicle.received", "title": "Vehicle Received"}
        ]
    }
