class MfaEnrollment {
  final String mfaEnrollmentId;
  final String userId;
  final String method;
  final String status;
  final DateTime enrolledAt;
  final DateTime? verifiedAt;

  const MfaEnrollment({
    required this.mfaEnrollmentId,
    required this.userId,
    required this.method,
    required this.status,
    required this.enrolledAt,
    this.verifiedAt,
  });
}
