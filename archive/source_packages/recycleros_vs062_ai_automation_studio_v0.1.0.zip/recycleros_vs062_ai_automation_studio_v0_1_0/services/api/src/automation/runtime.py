from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass
class RuntimeResult:
    status: str
    completed_steps: int
    paused_for_approval: bool
    error_summary: str | None = None

SENSITIVE_ACTIONS = {
    'publish_listing',
    'issue_refund',
    'send_payment',
    'delete_record',
    'change_price_over_threshold',
}

def execute_steps(steps: list[dict], is_test_run: bool) -> RuntimeResult:
    completed = 0

    for step in sorted(steps, key=lambda item: item.get('step_order', 0)):
        action_type = step.get('action_type', '')
        requires_approval = bool(step.get('requires_approval', False))

        if requires_approval or action_type in SENSITIVE_ACTIONS:
            return RuntimeResult(
                status='paused',
                completed_steps=completed,
                paused_for_approval=True,
            )

        if is_test_run:
            completed += 1
            continue

        # Scaffold only. Real action dispatching will be registered through
        # the workflow engine and plugin extension framework.
        completed += 1

    return RuntimeResult(
        status='completed',
        completed_steps=completed,
        paused_for_approval=False,
    )

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
