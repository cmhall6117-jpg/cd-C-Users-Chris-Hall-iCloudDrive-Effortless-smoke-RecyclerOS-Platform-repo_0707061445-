class ImportEventTypes {
  static const importJobCreated = 'import.job_created';
  static const importValidationCompleted = 'import.validation_completed';
  static const importCommitted = 'import.committed';
  static const importFailed = 'import.failed';
}
