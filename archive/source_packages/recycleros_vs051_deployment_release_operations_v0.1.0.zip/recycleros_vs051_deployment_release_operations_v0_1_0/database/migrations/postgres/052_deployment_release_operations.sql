CREATE TABLE IF NOT EXISTS deployment_environments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    environment_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    environment_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS deployment_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deployment_code TEXT UNIQUE NOT NULL,
    release_version TEXT NOT NULL,
    environment_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'started',
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    rollback_notes TEXT
);
