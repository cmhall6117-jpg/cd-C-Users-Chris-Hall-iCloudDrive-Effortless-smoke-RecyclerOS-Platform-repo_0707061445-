class WorkflowStep {
  final String workflowStepId;
  final String workflowPlaybookId;
  final int stepOrder;
  final String title;
  final String actionType;
  final String capability;
  final bool requiresApproval;

  const WorkflowStep({
    required this.workflowStepId,
    required this.workflowPlaybookId,
    required this.stepOrder,
    required this.title,
    required this.actionType,
    required this.capability,
    required this.requiresApproval,
  });
}
