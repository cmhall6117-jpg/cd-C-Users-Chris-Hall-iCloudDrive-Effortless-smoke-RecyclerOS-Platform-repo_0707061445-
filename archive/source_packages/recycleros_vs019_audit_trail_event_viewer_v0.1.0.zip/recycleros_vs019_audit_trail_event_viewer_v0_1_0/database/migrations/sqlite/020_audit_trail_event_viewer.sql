CREATE TABLE IF NOT EXISTS audit_records (
    id TEXT PRIMARY KEY,
    event_id TEXT,
    event_code TEXT NOT NULL,
    event_type TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    performed_by TEXT NOT NULL,
    occurred_at TEXT NOT NULL,
    payload_summary TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE INDEX IF NOT EXISTS idx_audit_records_object ON audit_records(object_type, object_id);
CREATE INDEX IF NOT EXISTS idx_audit_records_event_type ON audit_records(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_records_performed_by ON audit_records(performed_by);
