from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class WorkflowPlaybookCreate(BaseModel):
    name: str
    category: str
    description: str = ''

@router.post('/playbooks')
def create_playbook(payload: WorkflowPlaybookCreate):
    return {
        'workflow_playbook_id': 'WFP-DEMO-000001',
        'playbook_code': 'WFP-000001',
        'name': payload.name,
        'category': payload.category,
        'status': 'draft',
        'description': payload.description,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'workflow.playbook_created'
    }

@router.post('/playbooks/{playbook_id}/runs')
def start_workflow_run(playbook_id: str):
    return {
        'workflow_run_id': 'WFR-DEMO-000001',
        'workflow_playbook_id': playbook_id,
        'status': 'active',
        'started_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'workflow.run_started'
    }
