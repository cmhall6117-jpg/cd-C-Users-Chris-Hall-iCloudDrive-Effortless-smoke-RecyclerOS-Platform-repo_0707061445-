class FinancialTransaction {
  final String financialTransactionId;
  final String transactionCode;
  final String accountType;
  final String category;
  final double amount;
  final String currency;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime transactionDate;
  final String description;

  const FinancialTransaction({
    required this.financialTransactionId,
    required this.transactionCode,
    required this.accountType,
    required this.category,
    required this.amount,
    required this.currency,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.transactionDate,
    required this.description,
  });
}
