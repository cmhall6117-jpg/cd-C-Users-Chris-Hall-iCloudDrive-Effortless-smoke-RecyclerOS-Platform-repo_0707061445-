class LicenseRecord {
  final String licenseRecordId;
  final String licenseCode;
  final String accountId;
  final String subscriptionPlanId;
  final String status;
  final DateTime startedAt;
  final DateTime? expiresAt;

  const LicenseRecord({
    required this.licenseRecordId,
    required this.licenseCode,
    required this.accountId,
    required this.subscriptionPlanId,
    required this.status,
    required this.startedAt,
    this.expiresAt,
  });
}
