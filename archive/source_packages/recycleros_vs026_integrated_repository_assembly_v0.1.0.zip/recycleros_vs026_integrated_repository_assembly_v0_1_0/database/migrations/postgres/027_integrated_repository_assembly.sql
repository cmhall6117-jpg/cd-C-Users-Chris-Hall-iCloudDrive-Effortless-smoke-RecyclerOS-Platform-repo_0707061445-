CREATE TABLE IF NOT EXISTS repository_assembly_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    assembly_run_code TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'planned',
    target_build TEXT NOT NULL,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    notes TEXT
);
