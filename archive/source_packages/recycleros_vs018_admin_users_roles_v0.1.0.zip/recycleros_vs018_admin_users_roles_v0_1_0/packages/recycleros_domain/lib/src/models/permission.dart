class Permission {
  final String permissionId;
  final String permissionCode;
  final String capability;
  final String action;

  const Permission({
    required this.permissionId,
    required this.permissionCode,
    required this.capability,
    required this.action,
  });
}
