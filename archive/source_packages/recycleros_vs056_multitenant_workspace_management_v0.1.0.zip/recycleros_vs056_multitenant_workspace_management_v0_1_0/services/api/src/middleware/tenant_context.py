from dataclasses import dataclass
from fastapi import Header, HTTPException

@dataclass(frozen=True)
class TenantContext:
    organization_id: str
    workspace_id: str
    branch_id: str | None = None

def require_tenant_context(
    x_organization_id: str = Header(...),
    x_workspace_id: str = Header(...),
    x_branch_id: str | None = Header(default=None),
) -> TenantContext:
    if not x_organization_id or not x_workspace_id:
        raise HTTPException(status_code=400, detail='Tenant context is required.')
    return TenantContext(
        organization_id=x_organization_id,
        workspace_id=x_workspace_id,
        branch_id=x_branch_id,
    )
