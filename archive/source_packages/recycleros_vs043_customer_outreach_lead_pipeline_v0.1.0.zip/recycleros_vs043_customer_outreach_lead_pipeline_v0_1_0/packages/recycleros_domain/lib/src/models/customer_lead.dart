class CustomerLead {
  final String leadId;
  final String leadCode;
  final String status;
  final String sourceChannel;
  final String? customerId;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime createdAt;

  const CustomerLead({
    required this.leadId,
    required this.leadCode,
    required this.status,
    required this.sourceChannel,
    this.customerId,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.createdAt,
  });
}
