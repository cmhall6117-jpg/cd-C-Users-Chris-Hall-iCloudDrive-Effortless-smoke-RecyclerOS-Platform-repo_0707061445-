class ObservabilityEventTypes {
  static const healthSnapshotCaptured = 'observability.health_snapshot_captured';
  static const errorLogged = 'observability.error_logged';
  static const performanceMetricRecorded = 'observability.performance_metric_recorded';
  static const uptimeStatusChanged = 'observability.uptime_status_changed';
}
