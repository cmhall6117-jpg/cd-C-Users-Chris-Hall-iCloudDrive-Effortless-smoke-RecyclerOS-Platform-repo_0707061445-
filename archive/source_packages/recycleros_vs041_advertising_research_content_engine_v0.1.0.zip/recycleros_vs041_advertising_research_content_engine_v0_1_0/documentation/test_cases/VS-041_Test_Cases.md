# VS-041 Advertising Research & Content Engine Test Cases

TC-001 Research Record: advertising.research_created event is recorded.
TC-002 Content Draft: advertising.content_drafted event is recorded.
TC-003 Campaign Link: content draft can link to promotion campaign.
TC-004 Channel Storage: channel and audience are stored.
TC-005 Offline Draft: content drafts save locally with sync_status pending.
