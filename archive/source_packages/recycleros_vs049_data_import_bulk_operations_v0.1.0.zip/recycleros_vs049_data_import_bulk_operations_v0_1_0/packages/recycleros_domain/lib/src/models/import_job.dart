class ImportJob {
  final String importJobId;
  final String importCode;
  final String importType;
  final String sourceFileName;
  final String status;
  final int totalRows;
  final int validRows;
  final int errorRows;
  final DateTime createdAt;

  const ImportJob({
    required this.importJobId,
    required this.importCode,
    required this.importType,
    required this.sourceFileName,
    required this.status,
    required this.totalRows,
    required this.validRows,
    required this.errorRows,
    required this.createdAt,
  });
}
