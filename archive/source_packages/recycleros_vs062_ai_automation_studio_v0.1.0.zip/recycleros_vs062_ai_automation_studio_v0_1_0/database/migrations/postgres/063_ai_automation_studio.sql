CREATE TABLE IF NOT EXISTS automation_definitions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    automation_code TEXT UNIQUE NOT NULL,
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS automation_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    automation_definition_id UUID NOT NULL REFERENCES automation_definitions(id),
    step_order INTEGER NOT NULL,
    step_type TEXT NOT NULL,
    name TEXT NOT NULL,
    configuration_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    requires_approval BOOLEAN NOT NULL DEFAULT false,
    UNIQUE(automation_definition_id, step_order)
);

CREATE TABLE IF NOT EXISTS automation_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_code TEXT UNIQUE NOT NULL,
    automation_definition_id UUID NOT NULL REFERENCES automation_definitions(id),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    status TEXT NOT NULL DEFAULT 'started',
    is_test_run BOOLEAN NOT NULL DEFAULT true,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    error_summary TEXT
);

CREATE TABLE IF NOT EXISTS automation_run_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    automation_run_id UUID NOT NULL REFERENCES automation_runs(id),
    automation_step_id UUID REFERENCES automation_steps(id),
    status TEXT NOT NULL DEFAULT 'pending',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    output_json JSONB,
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS automation_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    automation_run_id UUID NOT NULL REFERENCES automation_runs(id),
    automation_run_step_id UUID REFERENCES automation_run_steps(id),
    status TEXT NOT NULL DEFAULT 'pending',
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reviewed_by UUID REFERENCES user_accounts(id),
    reviewed_at TIMESTAMPTZ,
    review_notes TEXT
);

CREATE TABLE IF NOT EXISTS ai_agent_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_code TEXT UNIQUE NOT NULL,
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    purpose TEXT NOT NULL,
    model_reference TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS automation_version_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    automation_definition_id UUID NOT NULL REFERENCES automation_definitions(id),
    version INTEGER NOT NULL,
    definition_json JSONB NOT NULL,
    created_by UUID REFERENCES user_accounts(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(automation_definition_id, version)
);

CREATE INDEX IF NOT EXISTS idx_automation_definitions_tenant
ON automation_definitions(organization_id, workspace_id, status);

CREATE INDEX IF NOT EXISTS idx_automation_runs_tenant_status
ON automation_runs(organization_id, workspace_id, status);
