# RecyclerOS Analytics Star Schema

## Shared Dimensions
- dim_date
- dim_organization
- dim_workspace
- dim_branch
- dim_vehicle
- dim_inventory_item
- dim_customer
- dim_vendor
- dim_user
- dim_channel

## Fact Tables
- fact_vehicle_acquisition
- fact_parts_harvest
- fact_inventory_movement
- fact_sales
- fact_returns
- fact_labor_cost
- fact_shipping_cost
- fact_marketing_performance
- fact_lead_conversion
- fact_risk_event
- fact_financial_performance

Every fact table must include:
- organization_id
- workspace_id
- date_id
- source_object_type
- source_object_id
- loaded_at
