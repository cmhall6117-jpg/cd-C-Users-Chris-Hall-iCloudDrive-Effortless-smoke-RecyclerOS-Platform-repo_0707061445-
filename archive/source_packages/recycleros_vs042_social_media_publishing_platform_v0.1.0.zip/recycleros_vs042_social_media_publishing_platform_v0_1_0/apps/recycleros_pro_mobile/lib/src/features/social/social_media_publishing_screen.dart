import 'package:flutter/material.dart';

class SocialMediaPublishingScreen extends StatelessWidget {
  const SocialMediaPublishingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final posts = [
      ('Facebook', 'Draft: Truck ECM special sale'),
      ('Instagram', 'Scheduled: Parts recovery reel'),
      ('Marketplace', 'Approved: LED headlight promo'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Social Publishing')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Promotion Publishing', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Schedule, approve, and track promotional posts across channels.'),
          const SizedBox(height: 16),
          for (final post in posts)
            Card(child: ListTile(leading: const Icon(Icons.public), title: Text(post.$1), subtitle: Text(post.$2))),
        ],
      ),
    );
  }
}
