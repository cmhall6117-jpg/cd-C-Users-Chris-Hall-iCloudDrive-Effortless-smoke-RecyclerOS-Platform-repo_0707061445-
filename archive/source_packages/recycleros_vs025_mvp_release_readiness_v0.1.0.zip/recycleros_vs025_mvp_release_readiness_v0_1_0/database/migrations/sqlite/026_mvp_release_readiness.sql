CREATE TABLE IF NOT EXISTS mvp_release_readiness_reviews (
    id TEXT PRIMARY KEY,
    review_code TEXT UNIQUE NOT NULL,
    release_binder_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    design_completion_percent REAL,
    scaffold_completion_percent REAL,
    working_product_completion_percent REAL,
    reviewed_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
