# VS-031 Auction Research & Source Tracking

Capabilities:
- Auction Research Engine
- Source Tracking
- Dealer / Non-Dealer Auction Distinction
- Procurement Watchlist
- Acquisition Intelligence

Events:
- Auction Source Created
- Auction Vehicle Watched
- Auction Fee Recorded
- Source Reliability Updated

Objects:
- Auction Source
- Auction Listing
- Watchlist Item
- Opportunity
- Vehicle
- Business Event

Acceptance Criteria:
1. User can create an auction source record.
2. Source can be marked dealer-only, non-dealer public, salvage, private, or unknown.
3. User can create watchlist item for auction listing.
4. Auction listing can link to opportunity and vehicle.
5. Auction fees and source notes can be stored.
6. Offline source/watchlist records can sync later.
