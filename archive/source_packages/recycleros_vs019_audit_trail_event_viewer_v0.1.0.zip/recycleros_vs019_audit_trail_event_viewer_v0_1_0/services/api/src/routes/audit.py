from datetime import datetime, timezone
from fastapi import APIRouter

router = APIRouter()

@router.get('/events')
def list_events(object_type: str | None = None, object_id: str | None = None):
    return {
        'items': [{
            'event_code': 'EVT-000001',
            'event_type': 'opportunity.discovered',
            'object_type': object_type or 'Opportunity',
            'object_id': object_id or 'OPP-000001',
            'performed_by': 'system',
            'occurred_at': datetime.now(timezone.utc).isoformat(),
            'payload_summary': 'Opportunity created from manual entry.'
        }],
        'event_created': 'audit.viewed'
    }

@router.get('/objects/{object_type}/{object_id}/timeline')
def object_timeline(object_type: str, object_id: str):
    return {
        'object_type': object_type,
        'object_id': object_id,
        'timeline': [
            {'event_code': 'EVT-000001', 'event_type': 'created', 'occurred_at': datetime.now(timezone.utc).isoformat()},
            {'event_code': 'EVT-000002', 'event_type': 'updated', 'occurred_at': datetime.now(timezone.utc).isoformat()}
        ],
        'event_created': 'object_timeline.viewed'
    }
