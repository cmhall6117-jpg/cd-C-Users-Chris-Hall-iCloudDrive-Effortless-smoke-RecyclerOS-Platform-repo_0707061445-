from datetime import datetime
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class OpportunityCreate(BaseModel):
    title: str
    procurement_intent: str = "undecided"
    source_type: str = "manual"

@router.post("")
def create_opportunity(payload: OpportunityCreate):
    return {
        "opportunity_id": "OPP-DEMO-000001",
        "title": payload.title,
        "procurement_intent": payload.procurement_intent,
        "source_type": payload.source_type,
        "created_at": datetime.utcnow().isoformat() + "Z",
        "event_created": "EVT-001 Opportunity Discovered",
    }

@router.get("")
def list_opportunities():
    return {"items": [], "message": "Opportunity listing scaffold ready."}
