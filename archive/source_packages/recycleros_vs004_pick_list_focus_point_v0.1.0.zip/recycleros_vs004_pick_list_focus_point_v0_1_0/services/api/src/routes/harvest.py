from datetime import datetime, timezone
from fastapi import APIRouter

router = APIRouter()

@router.post('/focus-point/start')
def start_focus_point(vehicle_id: str):
    now = datetime.now(timezone.utc)
    return {'harvest_session_id': 'HVS-DEMO-000001', 'vehicle_id': vehicle_id, 'started_at': now.isoformat(), 'event_created': 'focus_point.started', 'timer_status': 'active'}

@router.post('/focus-point/complete')
def complete_focus_point(harvest_session_id: str):
    now = datetime.now(timezone.utc)
    return {'harvest_session_id': harvest_session_id, 'ended_at': now.isoformat(), 'event_created': 'focus_point.completed', 'timer_status': 'stopped'}
