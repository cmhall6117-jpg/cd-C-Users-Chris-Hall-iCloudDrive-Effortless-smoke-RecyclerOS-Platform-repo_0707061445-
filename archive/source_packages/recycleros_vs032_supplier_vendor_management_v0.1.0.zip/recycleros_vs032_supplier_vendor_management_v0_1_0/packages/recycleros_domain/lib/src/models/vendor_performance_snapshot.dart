class VendorPerformanceSnapshot {
  final String snapshotId;
  final String vendorId;
  final double reliabilityScore;
  final double costScore;
  final double serviceScore;
  final String notes;
  final DateTime generatedAt;

  const VendorPerformanceSnapshot({
    required this.snapshotId,
    required this.vendorId,
    required this.reliabilityScore,
    required this.costScore,
    required this.serviceScore,
    required this.notes,
    required this.generatedAt,
  });
}
