class LaborEntry {
  final String laborEntryId;
  final String laborEntryCode;
  final String? userId;
  final String roleCode;
  final double hours;
  final double hourlyRate;
  final double totalCost;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime workedAt;

  const LaborEntry({
    required this.laborEntryId,
    required this.laborEntryCode,
    this.userId,
    required this.roleCode,
    required this.hours,
    required this.hourlyRate,
    required this.totalCost,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.workedAt,
  });
}
