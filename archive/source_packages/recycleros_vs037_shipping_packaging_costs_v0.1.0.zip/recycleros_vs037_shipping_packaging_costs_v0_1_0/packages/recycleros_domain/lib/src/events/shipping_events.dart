class ShippingEventTypes {
  static const packagingProfileCreated = 'shipping.packaging_profile_created';
  static const shippingEstimateCreated = 'shipping.estimate_created';
  static const shipmentTrackingUpdated = 'shipping.tracking_updated';
  static const shippingCostVarianceRecorded = 'shipping.cost_variance_recorded';
}
