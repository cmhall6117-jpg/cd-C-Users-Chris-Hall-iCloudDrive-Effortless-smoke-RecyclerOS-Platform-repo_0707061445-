CREATE TABLE IF NOT EXISTS kpi_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_code TEXT UNIQUE NOT NULL,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    open_opportunities INTEGER NOT NULL DEFAULT 0,
    active_pick_list_items INTEGER NOT NULL DEFAULT 0,
    inventory_available_count INTEGER NOT NULL DEFAULT 0,
    pending_sync_count INTEGER NOT NULL DEFAULT 0,
    sales_today NUMERIC(12,2) NOT NULL DEFAULT 0,
    projected_opportunity_value NUMERIC(12,2) NOT NULL DEFAULT 0,
    inventory_accuracy_percent NUMERIC(5,2) NOT NULL DEFAULT 0
);
