class MarketplaceListing {
  final String listingId;
  final String listingCode;
  final String inventoryItemId;
  final String channel;
  final String title;
  final String description;
  final double price;
  final String status;
  final DateTime createdAt;
  final DateTime? publishedAt;

  const MarketplaceListing({
    required this.listingId,
    required this.listingCode,
    required this.inventoryItemId,
    required this.channel,
    required this.title,
    required this.description,
    required this.price,
    required this.status,
    required this.createdAt,
    this.publishedAt,
  });
}
