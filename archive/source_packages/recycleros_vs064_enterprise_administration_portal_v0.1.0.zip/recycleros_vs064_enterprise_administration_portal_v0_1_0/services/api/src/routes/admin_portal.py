from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class MembershipUpdateRequest(BaseModel):
    user_id: str
    organization_id: str
    workspace_id: str | None = None
    role_code: str
    status: str = 'active'

class LicenseStatusUpdateRequest(BaseModel):
    license_record_id: str
    status: str

@router.get('/dashboard')
def admin_dashboard():
    return {
        'organization_count': 3,
        'workspace_count': 7,
        'active_user_count': 24,
        'active_license_count': 18,
        'installed_integration_count': 6,
        'open_security_issue_count': 2,
        'platform_health_status': 'degraded',
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'admin.dashboard_snapshot_generated'
    }

@router.post('/memberships/update')
def update_membership(payload: MembershipUpdateRequest):
    return {
        'user_id': payload.user_id,
        'organization_id': payload.organization_id,
        'workspace_id': payload.workspace_id,
        'role_code': payload.role_code,
        'status': payload.status,
        'updated_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'admin.membership_updated'
    }

@router.post('/licenses/update-status')
def update_license_status(payload: LicenseStatusUpdateRequest):
    return {
        'license_record_id': payload.license_record_id,
        'status': payload.status,
        'updated_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'admin.license_updated'
    }
