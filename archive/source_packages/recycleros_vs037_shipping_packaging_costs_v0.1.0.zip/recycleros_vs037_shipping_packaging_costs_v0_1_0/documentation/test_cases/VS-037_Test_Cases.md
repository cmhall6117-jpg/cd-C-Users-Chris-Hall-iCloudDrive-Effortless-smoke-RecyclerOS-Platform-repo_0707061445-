# VS-037 Shipping, Packaging & Cost Estimation Test Cases

TC-001 Packaging Profile: stores dimensions and weight.
TC-002 Shipping Estimate: shipping.estimate_created event is recorded.
TC-003 Related Object Link: estimate links to listing, inventory item, or order.
TC-004 Carrier Service: estimate stores carrier and service level.
TC-005 Offline Estimate: estimate saves locally with sync_status pending.
