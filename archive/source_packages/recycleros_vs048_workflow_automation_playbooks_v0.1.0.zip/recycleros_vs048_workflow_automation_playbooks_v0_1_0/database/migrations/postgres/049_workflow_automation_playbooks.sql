CREATE TABLE IF NOT EXISTS workflow_playbooks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    playbook_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS workflow_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_playbook_id UUID REFERENCES workflow_playbooks(id),
    step_order INTEGER NOT NULL,
    title TEXT NOT NULL,
    action_type TEXT NOT NULL,
    capability TEXT NOT NULL,
    requires_approval BOOLEAN NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS workflow_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_playbook_id UUID REFERENCES workflow_playbooks(id),
    status TEXT NOT NULL DEFAULT 'active',
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);
