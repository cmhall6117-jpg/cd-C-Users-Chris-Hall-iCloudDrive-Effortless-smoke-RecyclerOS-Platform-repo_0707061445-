import 'package:flutter/material.dart';

class EnterpriseLoginScreen extends StatelessWidget {
  const EnterpriseLoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final providers = [
      ('Microsoft Entra ID', 'Enterprise SSO'),
      ('Google Workspace', 'Workspace SSO'),
      ('Local RecyclerOS', 'Email and password'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Enterprise Sign In')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Choose Identity Provider',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const Text(
            'Provider availability depends on the selected organization and authentication policy.',
          ),
          const SizedBox(height: 16),
          for (final provider in providers)
            Card(
              child: ListTile(
                leading: const Icon(Icons.login),
                title: Text(provider.$1),
                subtitle: Text(provider.$2),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
