class DefectEventTypes {
  static const defectCreated = 'defect.created';
  static const defectTriaged = 'defect.triaged';
  static const defectResolved = 'defect.resolved';
  static const technicalDebtRecorded = 'technical_debt.recorded';
}
