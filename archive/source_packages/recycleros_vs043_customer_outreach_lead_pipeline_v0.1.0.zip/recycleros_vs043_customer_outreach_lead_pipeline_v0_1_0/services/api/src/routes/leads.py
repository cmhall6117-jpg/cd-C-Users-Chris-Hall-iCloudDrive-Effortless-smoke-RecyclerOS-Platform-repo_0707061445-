from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class CustomerLeadCreate(BaseModel):
    source_channel: str
    customer_id: str | None = None
    related_object_type: str | None = None
    related_object_id: str | None = None

@router.post('/leads')
def create_lead(payload: CustomerLeadCreate):
    return {
        'lead_id': 'LED-DEMO-000001',
        'lead_code': 'LEAD-000001',
        'status': 'new',
        'source_channel': payload.source_channel,
        'customer_id': payload.customer_id,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'lead.created'
    }
