CREATE TABLE IF NOT EXISTS pipeline_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_code TEXT UNIQUE NOT NULL,
    branch_name TEXT NOT NULL,
    commit_sha TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'started',
    summary TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS release_gate_checks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    gate_code TEXT UNIQUE NOT NULL,
    pipeline_run_id UUID REFERENCES pipeline_runs(id),
    gate_name TEXT NOT NULL,
    status TEXT NOT NULL,
    message TEXT,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
