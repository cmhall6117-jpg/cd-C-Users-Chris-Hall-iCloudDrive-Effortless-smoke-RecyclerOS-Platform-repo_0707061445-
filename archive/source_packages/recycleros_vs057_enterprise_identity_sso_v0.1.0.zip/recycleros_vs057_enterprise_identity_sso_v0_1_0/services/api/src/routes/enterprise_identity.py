from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

class IdentityProviderCreate(BaseModel):
    organization_id: str
    provider_type: str
    display_name: str
    issuer_url: str
    client_id_reference: str

class EnterpriseLoginRequest(BaseModel):
    organization_id: str
    workspace_id: str
    provider_code: str
    authorization_code: str
    device_id: str

class MfaVerifyRequest(BaseModel):
    login_session_id: str
    method: str
    verification_code: str

@router.post('/providers')
def create_identity_provider(payload: IdentityProviderCreate):
    return {
        'identity_provider_id': 'IDP-DEMO-000001',
        'provider_code': 'IDP-000001',
        'organization_id': payload.organization_id,
        'provider_type': payload.provider_type,
        'display_name': payload.display_name,
        'issuer_url': payload.issuer_url,
        'client_id_reference': payload.client_id_reference,
        'status': 'active',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'identity.provider_linked'
    }

@router.post('/login')
def enterprise_login(payload: EnterpriseLoginRequest):
    if not payload.authorization_code:
        raise HTTPException(status_code=401, detail='Authorization code is required.')

    now = datetime.now(timezone.utc)
    return {
        'login_session_id': 'SES-ENT-DEMO-000001',
        'session_code': 'SES-ENT-000001',
        'organization_id': payload.organization_id,
        'workspace_id': payload.workspace_id,
        'provider_code': payload.provider_code,
        'device_id': payload.device_id,
        'status': 'mfa_required',
        'created_at': now.isoformat(),
        'expires_at': (now + timedelta(hours=8)).isoformat(),
        'events_created': [
            'identity.login_started',
            'identity.session_created'
        ]
    }

@router.post('/mfa/verify')
def verify_mfa(payload: MfaVerifyRequest):
    if len(payload.verification_code) < 6:
        raise HTTPException(status_code=400, detail='Invalid verification code.')

    return {
        'login_session_id': payload.login_session_id,
        'method': payload.method,
        'status': 'verified',
        'verified_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'identity.mfa_verified'
    }

@router.post('/sessions/{session_id}/revoke')
def revoke_session(session_id: str):
    return {
        'login_session_id': session_id,
        'status': 'revoked',
        'revoked_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'identity.session_revoked'
    }
