class AIEventTypes {
 static const recommendationCreated='ai.recommendation_created';
 static const recommendationApproved='ai.recommendation_approved';
 static const recommendationRejected='ai.recommendation_rejected';
}
