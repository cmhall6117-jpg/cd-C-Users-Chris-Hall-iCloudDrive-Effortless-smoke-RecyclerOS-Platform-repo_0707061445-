class AuctionSource {
  final String auctionSourceId;
  final String sourceCode;
  final String name;
  final String accessType;
  final String? websiteUrl;
  final String? location;
  final double? buyerFeePercent;
  final String reliabilityStatus;
  final DateTime createdAt;

  const AuctionSource({
    required this.auctionSourceId,
    required this.sourceCode,
    required this.name,
    required this.accessType,
    this.websiteUrl,
    this.location,
    this.buyerFeePercent,
    required this.reliabilityStatus,
    required this.createdAt,
  });
}
