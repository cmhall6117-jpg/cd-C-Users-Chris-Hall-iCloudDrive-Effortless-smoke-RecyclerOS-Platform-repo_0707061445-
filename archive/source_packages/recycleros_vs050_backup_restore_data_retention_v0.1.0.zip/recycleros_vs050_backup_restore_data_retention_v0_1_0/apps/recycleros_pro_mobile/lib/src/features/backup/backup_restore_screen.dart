import 'package:flutter/material.dart';

class BackupRestoreScreen extends StatelessWidget {
  const BackupRestoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final jobs = [
      ('BKP-000001', 'Full local export', 'completed'),
      ('BKP-000002', 'SQLite checkpoint', 'scheduled'),
      ('RST-000001', 'Restore dry-run', 'draft'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Backup & Restore')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Data Protection', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Track backup jobs, restore jobs, export checkpoints, and retention policies.'),
          const SizedBox(height: 16),
          for (final job in jobs)
            Card(child: ListTile(leading: const Icon(Icons.backup), title: Text('${job.$1} • ${job.$2}'), subtitle: Text('Status: ${job.$3}'))),
        ],
      ),
    );
  }
}
