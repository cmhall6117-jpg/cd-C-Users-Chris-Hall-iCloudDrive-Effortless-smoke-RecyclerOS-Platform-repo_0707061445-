CREATE TABLE IF NOT EXISTS deployment_environments (
    id TEXT PRIMARY KEY,
    environment_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    environment_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS deployment_runs (
    id TEXT PRIMARY KEY,
    deployment_code TEXT UNIQUE NOT NULL,
    release_version TEXT NOT NULL,
    environment_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'started',
    started_at TEXT NOT NULL,
    completed_at TEXT,
    rollback_notes TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
