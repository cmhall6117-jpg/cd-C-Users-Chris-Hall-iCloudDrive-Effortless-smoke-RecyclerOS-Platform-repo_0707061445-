CREATE TABLE IF NOT EXISTS organizations (
    id TEXT PRIMARY KEY,
    organization_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS workspaces (
    id TEXT PRIMARY KEY,
    workspace_code TEXT UNIQUE NOT NULL,
    organization_id TEXT NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS branches (
    id TEXT PRIMARY KEY,
    branch_code TEXT UNIQUE NOT NULL,
    workspace_id TEXT NOT NULL,
    name TEXT NOT NULL,
    address_line TEXT,
    city TEXT,
    state_code TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS memberships (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    organization_id TEXT NOT NULL,
    workspace_id TEXT,
    role_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS workspace_settings (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL,
    setting_key TEXT NOT NULL,
    setting_value TEXT,
    updated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE INDEX IF NOT EXISTS idx_workspaces_organization
ON workspaces(organization_id);

CREATE INDEX IF NOT EXISTS idx_memberships_user_org_workspace
ON memberships(user_id, organization_id, workspace_id);
