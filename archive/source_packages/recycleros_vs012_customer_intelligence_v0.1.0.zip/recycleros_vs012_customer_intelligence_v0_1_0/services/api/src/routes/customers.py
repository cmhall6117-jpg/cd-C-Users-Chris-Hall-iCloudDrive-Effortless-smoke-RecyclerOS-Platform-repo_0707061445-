from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class CustomerCreate(BaseModel):
    display_name: str
    email: str | None = None
    phone: str | None = None

@router.post('')
def create_customer(payload: CustomerCreate):
    return {
        'customer_id': 'CUS-DEMO-000001',
        'customer_code': 'CUS-000001',
        'display_name': payload.display_name,
        'email': payload.email,
        'phone': payload.phone,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'customer.created'
    }

@router.get('/{customer_id}/matches')
def customer_inventory_matches(customer_id: str):
    return {
        'customer_id': customer_id,
        'items': [
            {'match_id': 'MATCH-DEMO-000001', 'inventory_item_id': 'INV-DEMO-000001', 'reason': 'Customer frequently buys Ford truck electronics.', 'confidence_score': 78}
        ]
    }
