CREATE TABLE IF NOT EXISTS dim_date (
    date_id INTEGER PRIMARY KEY,
    calendar_date DATE UNIQUE NOT NULL,
    calendar_year INTEGER NOT NULL,
    calendar_quarter INTEGER NOT NULL,
    calendar_month INTEGER NOT NULL,
    week_of_year INTEGER NOT NULL,
    day_of_month INTEGER NOT NULL,
    day_of_week INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS analytics_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_code TEXT UNIQUE NOT NULL,
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    metric_code TEXT NOT NULL,
    metric_value NUMERIC(18,4) NOT NULL,
    metric_unit TEXT NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS warehouse_load_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    load_code TEXT UNIQUE NOT NULL,
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    source_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'started',
    extracted_rows INTEGER NOT NULL DEFAULT 0,
    loaded_rows INTEGER NOT NULL DEFAULT 0,
    error_rows INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    error_summary TEXT
);

CREATE TABLE IF NOT EXISTS fact_sales (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    date_id INTEGER NOT NULL REFERENCES dim_date(date_id),
    source_object_type TEXT NOT NULL,
    source_object_id TEXT NOT NULL,
    gross_revenue NUMERIC(14,2) NOT NULL DEFAULT 0,
    discount_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
    shipping_revenue NUMERIC(14,2) NOT NULL DEFAULT 0,
    refund_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
    net_revenue NUMERIC(14,2) NOT NULL DEFAULT 0,
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fact_inventory_movement (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    date_id INTEGER NOT NULL REFERENCES dim_date(date_id),
    source_object_type TEXT NOT NULL,
    source_object_id TEXT NOT NULL,
    movement_type TEXT NOT NULL,
    quantity NUMERIC(14,4) NOT NULL,
    inventory_value NUMERIC(14,2) NOT NULL DEFAULT 0,
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_analytics_snapshots_tenant_period
ON analytics_snapshots(organization_id, workspace_id, period_start, period_end);

CREATE INDEX IF NOT EXISTS idx_fact_sales_tenant_date
ON fact_sales(organization_id, workspace_id, date_id);
