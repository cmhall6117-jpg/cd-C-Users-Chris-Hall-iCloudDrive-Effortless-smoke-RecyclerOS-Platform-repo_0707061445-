from datetime import datetime, timezone, timedelta
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class LoginRequest(BaseModel):
    email: str
    password: str
    device_id: str | None = None

@router.post('/login')
def login(payload: LoginRequest):
    now = datetime.now(timezone.utc)
    # Scaffold only. Replace with secure credential verification.
    return {
        'user_id': 'USR-DEMO-000001',
        'user_code': 'USR-000001',
        'display_name': 'Demo User',
        'auth_session_id': 'SES-DEMO-000001',
        'access_token': 'SCaffoldTokenReplaceWithJWT',
        'token_type': 'bearer',
        'expires_at': (now + timedelta(hours=8)).isoformat(),
        'events_created': ['auth.login_attempted', 'auth.login_succeeded', 'auth.session_created']
    }

@router.post('/logout')
def logout(auth_session_id: str):
    return {
        'auth_session_id': auth_session_id,
        'status': 'logged_out',
        'logged_out_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'auth.logout_completed'
    }
