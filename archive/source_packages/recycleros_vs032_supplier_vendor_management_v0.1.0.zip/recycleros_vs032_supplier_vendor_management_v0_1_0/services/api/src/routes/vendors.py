from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class VendorCreate(BaseModel):
    name: str
    vendor_type: str
    phone: str | None = None
    email: str | None = None
    website_url: str | None = None

@router.post('/vendors')
def create_vendor(payload: VendorCreate):
    return {
        'vendor_id': 'VND-DEMO-000001',
        'vendor_code': 'VND-000001',
        'name': payload.name,
        'vendor_type': payload.vendor_type,
        'status': 'active',
        'phone': payload.phone,
        'email': payload.email,
        'website_url': payload.website_url,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'vendor.created'
    }

@router.get('/vendors')
def list_vendors():
    return {'items': [{'vendor_code': 'VND-000001', 'name': 'Greenville Pull-A-Part', 'vendor_type': 'salvageYard', 'status': 'active'}]}
