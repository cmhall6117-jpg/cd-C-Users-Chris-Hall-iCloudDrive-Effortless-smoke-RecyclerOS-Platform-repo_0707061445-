class ShippingEstimate {
  final String shippingEstimateId;
  final String estimateCode;
  final String carrier;
  final String serviceLevel;
  final double estimatedCost;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime createdAt;

  const ShippingEstimate({
    required this.shippingEstimateId,
    required this.estimateCode,
    required this.carrier,
    required this.serviceLevel,
    required this.estimatedCost,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.createdAt,
  });
}
