# Offline Synchronization v2 Governance

1. Every sync record carries tenant and device context.
2. Sync endpoints validate tenant context.
3. Sensitive conflicts default to manual review.
4. Retry schedules use capped exponential backoff.
5. Dead-letter items remain recoverable and auditable.
6. Checkpoints are persisted before acknowledgement.
7. Sync payloads never contain unencrypted secret values.
