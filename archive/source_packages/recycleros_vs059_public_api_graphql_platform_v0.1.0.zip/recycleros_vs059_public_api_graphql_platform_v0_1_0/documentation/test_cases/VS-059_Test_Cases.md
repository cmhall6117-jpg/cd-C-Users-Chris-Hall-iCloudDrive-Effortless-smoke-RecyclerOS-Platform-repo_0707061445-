# VS-059 Public REST API & GraphQL Platform Test Cases

TC-001 Create Developer Application.
TC-002 REST API uses /public/v1.
TC-003 GraphQL health query works.
TC-004 Webhook subscription stores event and callback URL.
TC-005 API client secret is stored only as a hash.
