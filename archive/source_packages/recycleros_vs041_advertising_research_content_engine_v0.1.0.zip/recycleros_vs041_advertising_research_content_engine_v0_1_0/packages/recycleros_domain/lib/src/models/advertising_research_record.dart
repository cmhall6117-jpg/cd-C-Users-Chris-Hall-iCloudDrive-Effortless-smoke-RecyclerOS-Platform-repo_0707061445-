class AdvertisingResearchRecord {
  final String advertisingResearchId;
  final String researchCode;
  final String channel;
  final String audience;
  final String productCategory;
  final String notes;
  final double confidenceScore;
  final DateTime createdAt;

  const AdvertisingResearchRecord({
    required this.advertisingResearchId,
    required this.researchCode,
    required this.channel,
    required this.audience,
    required this.productCategory,
    required this.notes,
    required this.confidenceScore,
    required this.createdAt,
  });
}
