CREATE TABLE IF NOT EXISTS sales_forecast_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_code TEXT UNIQUE NOT NULL,
    projected_revenue NUMERIC(12,2) NOT NULL DEFAULT 0,
    weighted_revenue NUMERIC(12,2) NOT NULL DEFAULT 0,
    open_lead_count INTEGER NOT NULL DEFAULT 0,
    open_listing_count INTEGER NOT NULL DEFAULT 0,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sales_forecast_lines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_id UUID REFERENCES sales_forecast_snapshots(id),
    related_object_type TEXT NOT NULL,
    related_object_id TEXT NOT NULL,
    projected_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
    probability_percent NUMERIC(5,2) NOT NULL DEFAULT 0,
    weighted_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    expected_close_date DATE
);
