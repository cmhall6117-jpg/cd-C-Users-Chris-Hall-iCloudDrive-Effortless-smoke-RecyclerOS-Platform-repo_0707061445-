CREATE TABLE IF NOT EXISTS auction_sources (
    id TEXT PRIMARY KEY,
    source_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    access_type TEXT NOT NULL DEFAULT 'unknown',
    website_url TEXT,
    location TEXT,
    buyer_fee_percent REAL,
    reliability_status TEXT NOT NULL DEFAULT 'unknown',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS auction_watchlist_items (
    id TEXT PRIMARY KEY,
    auction_source_id TEXT NOT NULL,
    opportunity_id TEXT,
    vehicle_id TEXT,
    listing_title TEXT NOT NULL,
    listing_url TEXT,
    current_bid REAL,
    recommended_max_bid REAL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
