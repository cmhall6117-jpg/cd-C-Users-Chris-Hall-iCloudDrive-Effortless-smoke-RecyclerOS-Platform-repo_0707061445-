class SearchEventTypes {
  static const searchPerformed = 'search.performed';
  static const knowledgeArticleViewed = 'knowledge.article_viewed';
  static const documentLinked = 'document.linked';
  static const sopViewed = 'sop.viewed';
}
