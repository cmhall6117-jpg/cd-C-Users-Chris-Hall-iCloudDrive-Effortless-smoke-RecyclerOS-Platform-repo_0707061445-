# VS-031 Auction Research & Source Tracking Test Cases

TC-001 Create Auction Source: auction.source_created event is recorded.
TC-002 Access Type: source stores dealer-only or non-dealer public access type.
TC-003 Watchlist Item: listing can be added to watchlist.
TC-004 Opportunity Link: watchlist item can link to opportunity and vehicle.
TC-005 Offline Source: source and watchlist records save locally with sync_status pending.
