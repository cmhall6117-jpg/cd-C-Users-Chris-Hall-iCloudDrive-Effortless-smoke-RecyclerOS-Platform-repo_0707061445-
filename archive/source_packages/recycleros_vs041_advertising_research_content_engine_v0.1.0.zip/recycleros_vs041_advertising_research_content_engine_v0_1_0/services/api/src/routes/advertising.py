from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class PromotionalContentCreate(BaseModel):
    channel: str
    title: str
    body: str
    promotion_campaign_id: str | None = None

@router.post('/content-drafts')
def create_content_draft(payload: PromotionalContentCreate):
    return {
        'content_draft_id': 'ADC-DEMO-000001',
        'content_code': 'ADC-000001',
        'promotion_campaign_id': payload.promotion_campaign_id,
        'channel': payload.channel,
        'title': payload.title,
        'body': payload.body,
        'status': 'draft',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'advertising.content_drafted'
    }
