CREATE TABLE IF NOT EXISTS labor_role_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    skill_level TEXT NOT NULL,
    employment_type TEXT NOT NULL,
    base_pay_min NUMERIC(12,2),
    base_pay_max NUMERIC(12,2),
    currency TEXT NOT NULL DEFAULT 'USD',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS labor_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    labor_entry_code TEXT UNIQUE NOT NULL,
    user_id UUID REFERENCES user_accounts(id),
    role_code TEXT NOT NULL,
    hours NUMERIC(8,2) NOT NULL,
    hourly_rate NUMERIC(12,2) NOT NULL,
    total_cost NUMERIC(12,2) NOT NULL,
    related_object_type TEXT,
    related_object_id TEXT,
    worked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
