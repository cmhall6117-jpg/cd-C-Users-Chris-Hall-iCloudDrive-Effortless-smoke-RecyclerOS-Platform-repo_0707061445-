class CustomerPreference {
  final String customerPreferenceId;
  final String customerId;
  final String preferenceType;
  final String preferenceValue;
  final DateTime createdAt;

  const CustomerPreference({
    required this.customerPreferenceId,
    required this.customerId,
    required this.preferenceType,
    required this.preferenceValue,
    required this.createdAt,
  });
}
