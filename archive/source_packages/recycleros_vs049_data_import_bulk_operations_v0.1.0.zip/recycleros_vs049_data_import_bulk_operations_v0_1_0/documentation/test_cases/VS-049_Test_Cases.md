# VS-049 Data Import, CSV Upload & Bulk Operations Test Cases

TC-001 Create Import Job: import.job_created event is recorded.
TC-002 Validate Import: import.validation_completed event is recorded.
TC-003 Validation Error: row-level validation error can be stored.
TC-004 Commit Import: validated import can be committed.
TC-005 Offline Import Metadata: import job records save locally with sync_status pending.
