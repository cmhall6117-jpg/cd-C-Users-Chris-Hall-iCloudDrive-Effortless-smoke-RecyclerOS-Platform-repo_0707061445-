CREATE TABLE IF NOT EXISTS admin_dashboard_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_count INTEGER NOT NULL DEFAULT 0,
    workspace_count INTEGER NOT NULL DEFAULT 0,
    active_user_count INTEGER NOT NULL DEFAULT 0,
    active_license_count INTEGER NOT NULL DEFAULT 0,
    installed_integration_count INTEGER NOT NULL DEFAULT 0,
    open_security_issue_count INTEGER NOT NULL DEFAULT 0,
    platform_health_status TEXT NOT NULL,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_action_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action_code TEXT UNIQUE NOT NULL,
    actor_user_id UUID NOT NULL REFERENCES user_accounts(id),
    scope_type TEXT NOT NULL,
    organization_id UUID REFERENCES organizations(id),
    workspace_id UUID REFERENCES workspaces(id),
    action_type TEXT NOT NULL,
    target_object_type TEXT NOT NULL,
    target_object_id TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_saved_views (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES user_accounts(id),
    organization_id UUID REFERENCES organizations(id),
    workspace_id UUID REFERENCES workspaces(id),
    view_code TEXT NOT NULL,
    name TEXT NOT NULL,
    configuration_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, view_code)
);

CREATE INDEX IF NOT EXISTS idx_admin_actions_scope
ON admin_action_records(scope_type, organization_id, workspace_id, created_at);
