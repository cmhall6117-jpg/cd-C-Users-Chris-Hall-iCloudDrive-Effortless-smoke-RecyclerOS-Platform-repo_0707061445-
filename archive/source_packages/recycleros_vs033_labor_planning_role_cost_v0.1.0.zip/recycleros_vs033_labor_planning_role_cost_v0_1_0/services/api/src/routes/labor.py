from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class LaborEntryCreate(BaseModel):
    role_code: str
    hours: float
    hourly_rate: float
    related_object_type: str | None = None
    related_object_id: str | None = None

@router.post('/entries')
def create_labor_entry(payload: LaborEntryCreate):
    total_cost = payload.hours * payload.hourly_rate
    return {
        'labor_entry_id': 'LAB-DEMO-000001',
        'labor_entry_code': 'LAB-000001',
        'role_code': payload.role_code,
        'hours': payload.hours,
        'hourly_rate': payload.hourly_rate,
        'total_cost': total_cost,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'worked_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'labor.entry_recorded'
    }
