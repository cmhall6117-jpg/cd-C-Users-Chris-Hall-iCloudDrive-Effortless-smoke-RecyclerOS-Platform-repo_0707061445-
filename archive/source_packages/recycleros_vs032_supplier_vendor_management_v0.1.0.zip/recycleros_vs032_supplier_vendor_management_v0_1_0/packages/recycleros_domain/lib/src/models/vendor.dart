class Vendor {
  final String vendorId;
  final String vendorCode;
  final String name;
  final String vendorType;
  final String status;
  final String? phone;
  final String? email;
  final String? websiteUrl;
  final DateTime createdAt;

  const Vendor({
    required this.vendorId,
    required this.vendorCode,
    required this.name,
    required this.vendorType,
    required this.status,
    this.phone,
    this.email,
    this.websiteUrl,
    required this.createdAt,
  });
}
