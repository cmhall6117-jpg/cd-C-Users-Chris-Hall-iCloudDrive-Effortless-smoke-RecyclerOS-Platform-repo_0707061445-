class StockLimitPolicy {
  final String stockLimitPolicyId;
  final String policyCode;
  final String partCategory;
  final int maxOnHandQuantity;
  final int targetShelfLifeDays;
  final double maxReturnRatio;
  final bool isActive;

  const StockLimitPolicy({
    required this.stockLimitPolicyId,
    required this.policyCode,
    required this.partCategory,
    required this.maxOnHandQuantity,
    required this.targetShelfLifeDays,
    required this.maxReturnRatio,
    required this.isActive,
  });
}
