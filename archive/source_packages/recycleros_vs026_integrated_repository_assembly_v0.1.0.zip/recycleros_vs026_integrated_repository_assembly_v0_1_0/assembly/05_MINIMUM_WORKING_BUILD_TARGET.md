# Minimum Working Build Target

1. App launches.
2. Mission Control displays.
3. Opportunity Discovery opens.
4. API health endpoint responds.
5. Opportunity create endpoint responds.
6. PostgreSQL starts.
7. SQLite schema exists.
8. Defect register is available.
