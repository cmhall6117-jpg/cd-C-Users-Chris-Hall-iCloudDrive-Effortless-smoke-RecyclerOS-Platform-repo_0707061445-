from fastapi import APIRouter

public_v1_router = APIRouter(prefix='/public/v1')

@public_v1_router.get('/health')
def public_health():
    return {'status': 'ok', 'api_version': 'v1', 'service': 'recycleros-public-api'}

@public_v1_router.get('/inventory/{inventory_item_id}')
def get_inventory_item(inventory_item_id: str):
    return {'inventory_item_id': inventory_item_id, 'status': 'scaffold'}
