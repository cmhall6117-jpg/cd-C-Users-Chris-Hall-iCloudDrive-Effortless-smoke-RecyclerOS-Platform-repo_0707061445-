CREATE TABLE IF NOT EXISTS promotion_campaigns (
    id TEXT PRIMARY KEY,
    campaign_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    channel TEXT NOT NULL DEFAULT 'manual',
    status TEXT NOT NULL DEFAULT 'draft',
    target_discount_percent REAL,
    projected_revenue_impact REAL,
    created_at TEXT NOT NULL,
    launched_at TEXT,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS promotion_campaign_items (
    id TEXT PRIMARY KEY,
    promotion_campaign_id TEXT NOT NULL,
    inventory_item_id TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS promotion_recommendations (
    id TEXT PRIMARY KEY,
    recommendation_code TEXT UNIQUE NOT NULL,
    inventory_item_id TEXT,
    reason TEXT NOT NULL,
    suggested_action TEXT NOT NULL,
    confidence_score REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
