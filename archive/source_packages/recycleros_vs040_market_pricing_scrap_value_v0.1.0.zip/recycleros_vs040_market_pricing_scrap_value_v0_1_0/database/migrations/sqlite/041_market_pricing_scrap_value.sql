CREATE TABLE IF NOT EXISTS market_price_snapshots (
    id TEXT PRIMARY KEY,
    snapshot_code TEXT UNIQUE NOT NULL,
    inventory_item_id TEXT,
    part_name TEXT NOT NULL,
    low_price REAL NOT NULL DEFAULT 0,
    average_price REAL NOT NULL DEFAULT 0,
    high_price REAL NOT NULL DEFAULT 0,
    confidence_score REAL NOT NULL DEFAULT 0,
    source_summary TEXT,
    captured_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS scrap_metal_values (
    id TEXT PRIMARY KEY,
    material_type TEXT NOT NULL,
    local_market TEXT NOT NULL,
    unit TEXT NOT NULL DEFAULT 'lb',
    price_per_unit REAL NOT NULL,
    captured_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
