from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from src.middleware.tenant_context import TenantContext, require_tenant_context

router = APIRouter()

class WarehouseLoadRequest(BaseModel):
    source_name: str

@router.get('/summary')
def analytics_summary(
    context: TenantContext = Depends(require_tenant_context),
):
    return {
        'organization_id': context.organization_id,
        'workspace_id': context.workspace_id,
        'metrics': [
            {'metric_code': 'gross_profit', 'value': 42850.00, 'unit': 'USD'},
            {'metric_code': 'inventory_turnover', 'value': 3.2, 'unit': 'ratio'},
            {'metric_code': 'lead_conversion', 'value': 18.7, 'unit': 'percent'},
        ],
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'analytics.snapshot_generated',
    }

@router.post('/warehouse-loads')
def start_warehouse_load(
    payload: WarehouseLoadRequest,
    context: TenantContext = Depends(require_tenant_context),
):
    return {
        'warehouse_load_job_id': 'WHL-DEMO-000001',
        'load_code': 'WHL-000001',
        'organization_id': context.organization_id,
        'workspace_id': context.workspace_id,
        'source_name': payload.source_name,
        'status': 'started',
        'extracted_rows': 0,
        'loaded_rows': 0,
        'error_rows': 0,
        'started_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'analytics.warehouse_load_started',
    }
