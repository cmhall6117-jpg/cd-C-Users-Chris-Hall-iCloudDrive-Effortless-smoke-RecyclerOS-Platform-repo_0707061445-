class Role {
  final String roleId;
  final String roleCode;
  final String name;
  final String description;
  final bool isSystemRole;

  const Role({
    required this.roleId,
    required this.roleCode,
    required this.name,
    required this.description,
    required this.isSystemRole,
  });
}
