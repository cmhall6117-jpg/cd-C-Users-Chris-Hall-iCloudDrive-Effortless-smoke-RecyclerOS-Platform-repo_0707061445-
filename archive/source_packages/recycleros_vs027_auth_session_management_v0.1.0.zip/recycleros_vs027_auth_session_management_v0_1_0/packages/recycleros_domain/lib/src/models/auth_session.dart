class AuthSession {
  final String authSessionId;
  final String userId;
  final String deviceId;
  final String status;
  final DateTime createdAt;
  final DateTime? expiresAt;
  final DateTime? endedAt;

  const AuthSession({
    required this.authSessionId,
    required this.userId,
    required this.deviceId,
    required this.status,
    required this.createdAt,
    this.expiresAt,
    this.endedAt,
  });
}
