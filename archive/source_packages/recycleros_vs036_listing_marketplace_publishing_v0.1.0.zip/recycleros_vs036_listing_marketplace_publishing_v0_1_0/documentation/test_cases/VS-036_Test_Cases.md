# VS-036 Listing & Marketplace Publishing Test Cases

TC-001 Create Listing: listing.created event is recorded.
TC-002 Inventory Link: listing links to inventory item.
TC-003 Publish Listing: listing.published event is recorded.
TC-004 Media Link: listing can reference media assets.
TC-005 Offline Draft: listing draft saves locally with sync_status pending.
