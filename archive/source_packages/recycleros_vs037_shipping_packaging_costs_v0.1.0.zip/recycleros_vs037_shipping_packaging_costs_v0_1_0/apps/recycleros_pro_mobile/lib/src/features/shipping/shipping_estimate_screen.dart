import 'package:flutter/material.dart';

class ShippingEstimateScreen extends StatelessWidget {
  const ShippingEstimateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final estimates = [
      ('ECM / PCM', 'USPS Priority • 14.25 USD'),
      ('LED Headlight', 'UPS Ground • 28.80 USD'),
      ('Transmission', 'Freight estimate required'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Shipping Estimates')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Packaging & Shipping', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Estimate shipping using package dimensions, weight, carrier, and service level.'),
          const SizedBox(height: 16),
          for (final estimate in estimates)
            Card(child: ListTile(leading: const Icon(Icons.local_shipping), title: Text(estimate.$1), subtitle: Text(estimate.$2))),
        ],
      ),
    );
  }
}
