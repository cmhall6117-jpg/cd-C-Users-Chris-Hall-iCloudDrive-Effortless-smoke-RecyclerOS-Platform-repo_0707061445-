class LaborEventTypes {
  static const laborRoleCreated = 'labor.role_created';
  static const laborEntryRecorded = 'labor.entry_recorded';
  static const laborCostAllocated = 'labor.cost_allocated';
  static const rolePayRangeUpdated = 'labor.role_pay_range_updated';
}
