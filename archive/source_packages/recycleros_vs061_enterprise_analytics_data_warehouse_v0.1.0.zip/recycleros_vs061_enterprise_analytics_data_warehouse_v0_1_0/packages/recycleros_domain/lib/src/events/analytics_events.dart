class AnalyticsEventTypes {
  static const snapshotGenerated = 'analytics.snapshot_generated';
  static const warehouseLoadStarted = 'analytics.warehouse_load_started';
  static const warehouseLoadCompleted = 'analytics.warehouse_load_completed';
  static const warehouseLoadFailed = 'analytics.warehouse_load_failed';
  static const trendReportGenerated = 'analytics.trend_report_generated';
}
