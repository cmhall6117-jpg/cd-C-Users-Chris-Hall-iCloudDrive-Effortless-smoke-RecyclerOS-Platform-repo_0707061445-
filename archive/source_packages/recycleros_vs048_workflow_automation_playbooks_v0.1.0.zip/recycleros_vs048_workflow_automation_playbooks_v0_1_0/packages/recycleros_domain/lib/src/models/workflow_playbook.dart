class WorkflowPlaybook {
  final String workflowPlaybookId;
  final String playbookCode;
  final String name;
  final String category;
  final String status;
  final String description;
  final DateTime createdAt;

  const WorkflowPlaybook({
    required this.workflowPlaybookId,
    required this.playbookCode,
    required this.name,
    required this.category,
    required this.status,
    required this.description,
    required this.createdAt,
  });
}
