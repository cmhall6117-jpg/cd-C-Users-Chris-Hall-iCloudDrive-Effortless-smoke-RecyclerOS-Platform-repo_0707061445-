class Workspace {
  final String workspaceId;
  final String workspaceCode;
  final String organizationId;
  final String name;
  final String status;
  final DateTime createdAt;

  const Workspace({
    required this.workspaceId,
    required this.workspaceCode,
    required this.organizationId,
    required this.name,
    required this.status,
    required this.createdAt,
  });
}
