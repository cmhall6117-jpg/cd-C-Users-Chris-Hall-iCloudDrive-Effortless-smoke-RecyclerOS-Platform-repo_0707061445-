class SubscriptionPlan {
  final String subscriptionPlanId;
  final String planCode;
  final String name;
  final double price;
  final String billingInterval;
  final String status;
  final DateTime createdAt;

  const SubscriptionPlan({
    required this.subscriptionPlanId,
    required this.planCode,
    required this.name,
    required this.price,
    required this.billingInterval,
    required this.status,
    required this.createdAt,
  });
}
