class DevOpsEventTypes {
  static const pipelineRunStarted = 'devops.pipeline_run_started';
  static const pipelineRunCompleted = 'devops.pipeline_run_completed';
  static const pipelineRunFailed = 'devops.pipeline_run_failed';
  static const releaseGateChecked = 'devops.release_gate_checked';
}
