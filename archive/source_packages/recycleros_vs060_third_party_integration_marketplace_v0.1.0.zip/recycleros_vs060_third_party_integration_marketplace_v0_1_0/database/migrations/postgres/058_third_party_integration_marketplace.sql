CREATE TABLE IF NOT EXISTS integration_listings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    vendor TEXT NOT NULL,
    category TEXT NOT NULL,
    version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'available',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS installed_integrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_listing_id UUID REFERENCES integration_listings(id),
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'installed',
    credential_reference_id UUID REFERENCES secret_references(id),
    installed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS integration_sync_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    installed_integration_id UUID REFERENCES installed_integrations(id),
    direction TEXT NOT NULL DEFAULT 'bidirectional',
    status TEXT NOT NULL DEFAULT 'started',
    processed_count INTEGER NOT NULL DEFAULT 0,
    error_count INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    error_summary TEXT
);

CREATE INDEX IF NOT EXISTS idx_installed_integrations_workspace
ON installed_integrations(organization_id, workspace_id);
