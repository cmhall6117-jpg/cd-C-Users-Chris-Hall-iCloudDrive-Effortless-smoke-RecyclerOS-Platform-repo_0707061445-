# VS-048 Workflow Automation & Playbooks Test Cases

TC-001 Create Playbook: workflow.playbook_created event is recorded.
TC-002 Playbook Steps: steps store order, action type, capability, and approval requirement.
TC-003 Start Workflow Run: workflow.run_started event is recorded.
TC-004 Approval Gate: approval-required steps do not auto-complete.
TC-005 Offline Workflow: workflow records save locally with sync_status pending.
