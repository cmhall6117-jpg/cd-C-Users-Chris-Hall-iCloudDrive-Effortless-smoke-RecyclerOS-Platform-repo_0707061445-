# VS-028 Document & Media Capture Test Cases

TC-001 Media Screen Loads: attachment list displays.
TC-002 Create Media Asset: media.captured event is recorded.
TC-003 Link Object: media links to related object type and ID.
TC-004 Offline Attachment: media asset saves locally with sync_status pending.
TC-005 Compliance Attachment: disposal/compliance record can reference media asset.
