class VendorEventTypes {
  static const vendorCreated = 'vendor.created';
  static const vendorPerformanceUpdated = 'vendor.performance_updated';
  static const vendorContactAdded = 'vendor.contact_added';
  static const vendorStatusChanged = 'vendor.status_changed';
}
