# Offline Sync Validation Checklist

- [ ] Create opportunity offline.
- [ ] Create inventory item offline.
- [ ] Complete cycle count offline.
- [ ] Create disposal record offline.
- [ ] Create notification/task offline.
- [ ] Confirm sync_status = pending.
- [ ] Reconnect device.
- [ ] Confirm queued records sync.
- [ ] Confirm failed records retain error message.
