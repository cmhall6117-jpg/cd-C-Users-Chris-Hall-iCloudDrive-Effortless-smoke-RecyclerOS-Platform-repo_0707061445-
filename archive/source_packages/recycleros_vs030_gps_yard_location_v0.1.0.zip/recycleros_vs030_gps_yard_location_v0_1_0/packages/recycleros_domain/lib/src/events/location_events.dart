class LocationEventTypes {
  static const gpsLocationCaptured = 'gps.location_captured';
  static const yardPinCreated = 'yard.pin_created';
  static const vehicleLocationUpdated = 'vehicle.location_updated';
  static const locationAccuracyWarning = 'location.accuracy_warning';
}
