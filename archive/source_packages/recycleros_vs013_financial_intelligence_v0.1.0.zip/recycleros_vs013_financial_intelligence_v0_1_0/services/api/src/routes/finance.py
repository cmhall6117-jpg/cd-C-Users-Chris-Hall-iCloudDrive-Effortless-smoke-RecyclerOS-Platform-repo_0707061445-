from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class FinancialTransactionCreate(BaseModel):
    account_type: str
    category: str
    amount: float
    currency: str = 'USD'
    related_object_type: str | None = None
    related_object_id: str | None = None
    description: str = ''

@router.post('/transactions')
def create_financial_transaction(payload: FinancialTransactionCreate):
    return {
        'financial_transaction_id': 'FIN-DEMO-000001',
        'transaction_code': 'FIN-000001',
        'account_type': payload.account_type,
        'category': payload.category,
        'amount': payload.amount,
        'currency': payload.currency,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'transaction_date': datetime.now(timezone.utc).isoformat(),
        'event_created': 'financial.transaction_created'
    }

@router.get('/vehicles/{vehicle_id}/profit-snapshot')
def vehicle_profit_snapshot(vehicle_id: str):
    parts_revenue = 4200
    scrap_revenue = 450
    costs = 2350
    return {
        'snapshot_id': 'VPS-DEMO-000001',
        'vehicle_id': vehicle_id,
        'parts_revenue': parts_revenue,
        'scrap_revenue': scrap_revenue,
        'total_costs': costs,
        'gross_profit': parts_revenue + scrap_revenue - costs,
        'net_profit': parts_revenue + scrap_revenue - costs,
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'vehicle.profit_snapshot_generated'
    }
