class SyncQueueItem {
  final String syncQueueItemId;
  final String organizationId;
  final String workspaceId;
  final String deviceId;
  final String entityType;
  final String entityId;
  final String operation;
  final String payloadJson;
  final int localVersion;
  final String status;
  final int retryCount;
  final DateTime createdAt;
  final DateTime? nextRetryAt;

  const SyncQueueItem({
    required this.syncQueueItemId,
    required this.organizationId,
    required this.workspaceId,
    required this.deviceId,
    required this.entityType,
    required this.entityId,
    required this.operation,
    required this.payloadJson,
    required this.localVersion,
    required this.status,
    required this.retryCount,
    required this.createdAt,
    this.nextRetryAt,
  });
}
