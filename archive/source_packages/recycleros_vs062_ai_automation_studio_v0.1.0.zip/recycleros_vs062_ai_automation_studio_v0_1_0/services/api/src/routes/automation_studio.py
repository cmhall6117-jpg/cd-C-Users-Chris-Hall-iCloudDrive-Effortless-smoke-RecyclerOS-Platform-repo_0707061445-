from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from src.middleware.tenant_context import TenantContext, require_tenant_context
from src.automation.runtime import execute_steps

router = APIRouter()

class AutomationCreate(BaseModel):
    name: str
    description: str = ''
    steps: list[dict] = Field(default_factory=list)

class AutomationRunRequest(BaseModel):
    is_test_run: bool = True
    steps: list[dict] = Field(default_factory=list)

@router.post('/automations')
def create_automation(
    payload: AutomationCreate,
    context: TenantContext = Depends(require_tenant_context),
):
    now = datetime.now(timezone.utc)
    return {
        'automation_definition_id': 'AUT-DEMO-000001',
        'automation_code': 'AUT-000001',
        'organization_id': context.organization_id,
        'workspace_id': context.workspace_id,
        'name': payload.name,
        'description': payload.description,
        'status': 'draft',
        'version': 1,
        'steps': payload.steps,
        'created_at': now.isoformat(),
        'updated_at': now.isoformat(),
        'event_created': 'automation_studio.automation_created',
    }

@router.post('/automations/{automation_id}/runs')
def run_automation(
    automation_id: str,
    payload: AutomationRunRequest,
    context: TenantContext = Depends(require_tenant_context),
):
    result = execute_steps(payload.steps, payload.is_test_run)

    event = {
        'completed': 'automation_studio.run_completed',
        'paused': 'automation_studio.run_paused',
        'failed': 'automation_studio.run_failed',
    }.get(result.status, 'automation_studio.run_started')

    if result.status == 'failed':
        raise HTTPException(status_code=500, detail=result.error_summary)

    return {
        'automation_run_id': 'AUR-DEMO-000001',
        'run_code': 'AUR-000001',
        'automation_definition_id': automation_id,
        'organization_id': context.organization_id,
        'workspace_id': context.workspace_id,
        'status': result.status,
        'is_test_run': payload.is_test_run,
        'completed_steps': result.completed_steps,
        'paused_for_approval': result.paused_for_approval,
        'started_at': datetime.now(timezone.utc).isoformat(),
        'event_created': event,
    }
