class Vehicle {
  final String vehicleId;
  final String? vin;
  final int? year;
  final String? make;
  final String? model;

  const Vehicle({required this.vehicleId, this.vin, this.year, this.make, this.model});
}
