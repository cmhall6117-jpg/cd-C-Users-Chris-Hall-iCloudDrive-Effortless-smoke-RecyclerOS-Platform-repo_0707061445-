import 'package:flutter/material.dart';

class RiskControlsScreen extends StatelessWidget {
  const RiskControlsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final risks = [
      ('RISK-000001', 'High refund rate for customer', 'medium'),
      ('RISK-000002', 'Inventory shrink discrepancy', 'high'),
      ('RISK-000003', 'Approval hold: high-value refund', 'high'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Risk Controls')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Loss Prevention & Risk', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Track suspicious activity, inventory shrink, approval holds, and audit-ready risk events.'),
          const SizedBox(height: 16),
          for (final risk in risks)
            Card(child: ListTile(leading: const Icon(Icons.shield), title: Text('${risk.$1} • ${risk.$2}'), subtitle: Text('Severity: ${risk.$3}'))),
        ],
      ),
    );
  }
}
