class DeploymentEnvironment {
  final String deploymentEnvironmentId;
  final String environmentCode;
  final String name;
  final String environmentType;
  final String status;
  final DateTime createdAt;

  const DeploymentEnvironment({
    required this.deploymentEnvironmentId,
    required this.environmentCode,
    required this.name,
    required this.environmentType,
    required this.status,
    required this.createdAt,
  });
}
