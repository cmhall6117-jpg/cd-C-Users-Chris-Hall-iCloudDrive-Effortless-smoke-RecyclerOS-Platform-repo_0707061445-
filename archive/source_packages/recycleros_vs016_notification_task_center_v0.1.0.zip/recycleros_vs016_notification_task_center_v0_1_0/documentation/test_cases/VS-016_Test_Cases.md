# VS-016 Notification & Task Center Test Cases

TC-001 Create Notification: notification.created event is recorded.
TC-002 List Notifications: open notifications display.
TC-003 Create Task: task can link to related object.
TC-004 Acknowledge Alert: alert status changes from open to acknowledged.
TC-005 Offline Cache: notifications/tasks are visible offline from local cache.
