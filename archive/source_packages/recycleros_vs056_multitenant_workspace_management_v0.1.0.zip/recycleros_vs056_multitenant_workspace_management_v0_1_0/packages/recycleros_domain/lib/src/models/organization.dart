class Organization {
  final String organizationId;
  final String organizationCode;
  final String name;
  final String status;
  final DateTime createdAt;

  const Organization({
    required this.organizationId,
    required this.organizationCode,
    required this.name,
    required this.status,
    required this.createdAt,
  });
}
