import 'package:flutter/material.dart';

class DataImportScreen extends StatelessWidget {
  const DataImportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final jobs = [
      ('IMP-000001', 'Inventory CSV', 'validated • 126 rows'),
      ('IMP-000002', 'Vendor List', 'draft • 12 rows'),
      ('IMP-000003', 'Pricing Upload', 'errors • 4 rows'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Data Import')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('CSV Upload & Bulk Operations', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Stage, validate, and commit bulk records.'),
          const SizedBox(height: 16),
          for (final job in jobs)
            Card(child: ListTile(leading: const Icon(Icons.upload_file), title: Text('${job.$1} • ${job.$2}'), subtitle: Text(job.$3))),
        ],
      ),
    );
  }
}
