CREATE TABLE IF NOT EXISTS compliance_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    compliance_code TEXT UNIQUE NOT NULL,
    record_type TEXT NOT NULL,
    vehicle_id UUID REFERENCES vehicles(id),
    status TEXT NOT NULL DEFAULT 'open',
    jurisdiction TEXT NOT NULL DEFAULT 'local',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS disposal_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    disposal_code TEXT UNIQUE NOT NULL,
    material_type TEXT NOT NULL,
    vehicle_id UUID REFERENCES vehicles(id),
    quantity NUMERIC(12,2),
    unit TEXT,
    disposal_vendor TEXT NOT NULL,
    jurisdiction TEXT NOT NULL DEFAULT 'local',
    disposed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
