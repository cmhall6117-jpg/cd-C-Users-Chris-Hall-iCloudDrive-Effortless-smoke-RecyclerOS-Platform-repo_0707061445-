from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class NotificationCreate(BaseModel):
    title: str
    message: str
    severity: str = 'info'
    related_object_type: str | None = None
    related_object_id: str | None = None

@router.post('/notifications')
def create_notification(payload: NotificationCreate):
    return {
        'notification_id': 'NTF-DEMO-000001',
        'notification_code': 'NTF-000001',
        'title': payload.title,
        'message': payload.message,
        'severity': payload.severity,
        'status': 'open',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'notification.created'
    }

@router.get('/notifications')
def list_notifications():
    return {'items': [{'notification_id': 'NTF-DEMO-000001', 'title': 'Disposal record needed', 'severity': 'high', 'status': 'open'}]}
