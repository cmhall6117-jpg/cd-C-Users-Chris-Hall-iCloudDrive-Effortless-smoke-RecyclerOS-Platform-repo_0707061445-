from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class RecommendationCreate(BaseModel):
    recommendation_type: str
    related_object_type: str
    related_object_id: str
    recommendation: str
    reasoning: str
    confidence_score: float

@router.post('/recommendations')
def create_recommendation(payload: RecommendationCreate):
    return {
        'recommendation_id': 'REC-DEMO-000001',
        'recommendation_code': 'REC-000001',
        'recommendation_type': payload.recommendation_type,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'recommendation': payload.recommendation,
        'reasoning': payload.reasoning,
        'confidence_score': payload.confidence_score,
        'status': 'open',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'recommendation.created'
    }

@router.post('/recommendations/{recommendation_id}/approve')
def approve_recommendation(recommendation_id: str):
    return {
        'recommendation_id': recommendation_id,
        'status': 'approved',
        'event_created': 'recommendation.approved'
    }
