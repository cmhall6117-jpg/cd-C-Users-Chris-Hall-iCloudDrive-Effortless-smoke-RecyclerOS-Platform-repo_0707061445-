class LicensingEventTypes {
  static const subscriptionPlanCreated = 'licensing.subscription_plan_created';
  static const licenseCreated = 'licensing.license_created';
  static const licenseStatusChanged = 'licensing.license_status_changed';
  static const featureEntitlementUpdated = 'licensing.feature_entitlement_updated';
}
