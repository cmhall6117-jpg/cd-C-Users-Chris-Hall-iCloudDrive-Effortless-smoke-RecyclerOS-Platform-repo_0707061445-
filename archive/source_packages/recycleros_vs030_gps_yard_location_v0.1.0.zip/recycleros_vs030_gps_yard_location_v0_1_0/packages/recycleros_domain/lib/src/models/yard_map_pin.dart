class YardMapPin {
  final String yardMapPinId;
  final String pinCode;
  final String pinType;
  final double latitude;
  final double longitude;
  final String? yardName;
  final String? yardRow;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime createdAt;

  const YardMapPin({
    required this.yardMapPinId,
    required this.pinCode,
    required this.pinType,
    required this.latitude,
    required this.longitude,
    this.yardName,
    this.yardRow,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.createdAt,
  });
}
