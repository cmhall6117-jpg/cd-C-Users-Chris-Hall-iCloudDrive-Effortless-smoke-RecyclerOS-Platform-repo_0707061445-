import 'procurement_intent.dart';

class Opportunity {
  final String opportunityId;
  final String title;
  final ProcurementIntent procurementIntent;
  final DateTime createdAt;

  const Opportunity({
    required this.opportunityId,
    required this.title,
    required this.procurementIntent,
    required this.createdAt,
  });
}
