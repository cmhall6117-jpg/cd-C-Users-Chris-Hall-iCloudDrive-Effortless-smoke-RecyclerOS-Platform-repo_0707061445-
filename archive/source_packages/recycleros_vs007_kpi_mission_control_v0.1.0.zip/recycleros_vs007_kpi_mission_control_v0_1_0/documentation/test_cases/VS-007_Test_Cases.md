# VS-007 KPI & Mission Control Test Cases

TC-001 Dashboard Loads: Mission Control displays priority KPI tiles.
TC-002 KPI Snapshot API: /mission-control returns KPI snapshot.
TC-003 Pending Sync Tile: pending sync count displays.
TC-004 Offline KPI: last known KPI snapshot displays offline.
TC-005 KPI Event: KPI snapshot generated event is recorded.
