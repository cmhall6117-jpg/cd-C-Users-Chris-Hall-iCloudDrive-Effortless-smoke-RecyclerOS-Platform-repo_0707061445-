import 'package:flutter/material.dart';

class SyncRecoveryScreen extends StatelessWidget {
  const SyncRecoveryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Pending Queue', '12 items'),
      ('Open Conflicts', '2 items require review'),
      ('Retry Scheduled', '3 items'),
      ('Dead Letter', '1 item'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Sync Recovery')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Offline Synchronization v2', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          for (final item in items)
            Card(child: ListTile(leading: const Icon(Icons.sync_problem), title: Text(item.$1), subtitle: Text(item.$2))),
        ],
      ),
    );
  }
}
