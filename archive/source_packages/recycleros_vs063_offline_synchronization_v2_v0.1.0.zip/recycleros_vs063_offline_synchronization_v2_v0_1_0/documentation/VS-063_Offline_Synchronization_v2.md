# VS-063 Offline Synchronization v2

Capabilities:
- Tenant-Safe Offline Sync
- Resumable Sync Batches
- Conflict Detection
- Merge Strategies
- Retry and Backoff
- Dead-Letter Queue
- Sync Recovery

Acceptance Criteria:
1. Every sync item carries tenant and device context.
2. Batches resume from checkpoints.
3. Conflicts retain local/server payloads.
4. server_wins, client_wins, last_write_wins, field_merge, and manual_review are supported.
5. Failed items retry with backoff.
6. Permanent failures move to dead letter.
7. Tenant boundaries are enforced.
