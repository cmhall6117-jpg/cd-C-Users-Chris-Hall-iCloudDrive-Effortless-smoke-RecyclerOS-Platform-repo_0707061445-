# VS-012 Customer Intelligence Test Cases

TC-001 Create Customer: customer.created event is recorded.
TC-002 Add Preference: customer preference record is stored.
TC-003 Inventory Match: customer match recommendation returns reason and confidence score.
TC-004 Lifetime Value: customer profile supports lifetime value fields.
TC-005 Offline Customer: customer record saves locally with sync_status pending.
