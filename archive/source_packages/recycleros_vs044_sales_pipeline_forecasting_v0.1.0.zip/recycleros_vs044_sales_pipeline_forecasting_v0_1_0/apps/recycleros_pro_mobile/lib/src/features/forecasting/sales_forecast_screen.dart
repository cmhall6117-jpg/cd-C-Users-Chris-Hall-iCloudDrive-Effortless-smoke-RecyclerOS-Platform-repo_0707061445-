import 'package:flutter/material.dart';

class SalesForecastScreen extends StatelessWidget {
  const SalesForecastScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final forecast = [
      ('Open Leads', '7 • Weighted 1,420 USD'),
      ('Open Listings', '18 • Weighted 4,850 USD'),
      ('Committed Quotes', '3 • Weighted 2,200 USD'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Sales Forecast')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Revenue Projection', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Forecast revenue using leads, listings, probabilities, and expected close dates.'),
          const SizedBox(height: 16),
          for (final row in forecast)
            Card(child: ListTile(leading: const Icon(Icons.query_stats), title: Text(row.$1), subtitle: Text(row.$2))),
        ],
      ),
    );
  }
}
