class IntegrationListing {
  final String integrationListingId;
  final String integrationCode;
  final String name;
  final String vendor;
  final String category;
  final String version;
  final String status;
  final DateTime createdAt;

  const IntegrationListing({
    required this.integrationListingId,
    required this.integrationCode,
    required this.name,
    required this.vendor,
    required this.category,
    required this.version,
    required this.status,
    required this.createdAt,
  });
}
