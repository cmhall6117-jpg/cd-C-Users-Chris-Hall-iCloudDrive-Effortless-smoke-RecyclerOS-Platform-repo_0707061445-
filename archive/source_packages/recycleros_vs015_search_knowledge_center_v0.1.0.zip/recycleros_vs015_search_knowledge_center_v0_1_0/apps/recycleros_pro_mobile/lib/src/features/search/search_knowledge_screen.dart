import 'package:flutter/material.dart';

class SearchKnowledgeScreen extends StatelessWidget {
  const SearchKnowledgeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final results = [
      ('Vehicle', '2019 Ford F-150', 'Vehicle Digital Twin'),
      ('Inventory', 'INV-000001 ECM / PCM', 'Available inventory item'),
      ('Customer', 'Demo Repair Shop', 'Customer profile'),
      ('SOP', 'Focus Point Harvest Procedure', 'Operational knowledge article'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Search & Knowledge')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Enterprise Search', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const TextField(
            decoration: InputDecoration(
              labelText: 'Search vehicles, inventory, customers, SOPs...',
              border: OutlineInputBorder(),
              suffixIcon: Icon(Icons.search),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Example Results', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (final result in results)
            Card(
              child: ListTile(
                leading: const Icon(Icons.search),
                title: Text(result.$2),
                subtitle: Text('${result.$1} • ${result.$3}'),
              ),
            ),
        ],
      ),
    );
  }
}
