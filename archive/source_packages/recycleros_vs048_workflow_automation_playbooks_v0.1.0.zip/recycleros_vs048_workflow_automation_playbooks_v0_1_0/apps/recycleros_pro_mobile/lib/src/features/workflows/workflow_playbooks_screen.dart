import 'package:flutter/material.dart';

class WorkflowPlaybooksScreen extends StatelessWidget {
  const WorkflowPlaybooksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final playbooks = [
      ('High-Value Vehicle Harvest', 'Procurement → Pick List → Inventory'),
      ('Aging Inventory Special Sale', 'Pricing → Promotion → Social Post'),
      ('Return Risk Review', 'Return → Risk Flag → Approval Hold'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Workflow Playbooks')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Automation Playbooks', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Run repeatable workflows with approval-aware automation.'),
          const SizedBox(height: 16),
          for (final playbook in playbooks)
            Card(
              child: ListTile(
                leading: const Icon(Icons.account_tree),
                title: Text(playbook.$1),
                subtitle: Text(playbook.$2),
              ),
            ),
        ],
      ),
    );
  }
}
