class Payment {
  final String paymentId;
  final String paymentCode;
  final String salesOrderId;
  final double amount;
  final String method;
  final DateTime receivedAt;

  const Payment({
    required this.paymentId,
    required this.paymentCode,
    required this.salesOrderId,
    required this.amount,
    required this.method,
    required this.receivedAt,
  });
}
