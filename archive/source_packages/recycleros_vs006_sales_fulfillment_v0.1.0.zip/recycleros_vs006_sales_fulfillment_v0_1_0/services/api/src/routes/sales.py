from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class SalesOrderCreate(BaseModel):
    customer_id: str | None = None
    inventory_item_ids: list[str]
    subtotal: float = 0
    tax: float = 0
    shipping: float = 0

@router.post('/orders')
def create_sales_order(payload: SalesOrderCreate):
    now = datetime.now(timezone.utc)
    total = payload.subtotal + payload.tax + payload.shipping
    return {
        'sales_order_id': 'SO-DEMO-000001',
        'sales_order_code': 'SO-000001',
        'customer_id': payload.customer_id,
        'inventory_item_ids': payload.inventory_item_ids,
        'status': 'open',
        'subtotal': payload.subtotal,
        'tax': payload.tax,
        'shipping': payload.shipping,
        'total': total,
        'created_at': now.isoformat(),
        'event_created': 'item.sold'
    }

@router.post('/payments')
def record_payment(sales_order_id: str, amount: float, method: str = 'manual'):
    return {
        'payment_id': 'PAY-DEMO-000001',
        'payment_code': 'PAY-000001',
        'sales_order_id': sales_order_id,
        'amount': amount,
        'method': method,
        'event_created': 'payment.received'
    }
