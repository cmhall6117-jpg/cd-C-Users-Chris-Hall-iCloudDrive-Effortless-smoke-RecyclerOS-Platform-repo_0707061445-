CREATE TABLE IF NOT EXISTS marketplace_listings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    listing_code TEXT UNIQUE NOT NULL,
    inventory_item_id UUID REFERENCES inventory_items(id),
    channel TEXT NOT NULL DEFAULT 'manual',
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC(12,2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    published_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS listing_media_assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    listing_id UUID REFERENCES marketplace_listings(id),
    media_asset_id UUID REFERENCES media_assets(id),
    sort_order INTEGER NOT NULL DEFAULT 0
);
