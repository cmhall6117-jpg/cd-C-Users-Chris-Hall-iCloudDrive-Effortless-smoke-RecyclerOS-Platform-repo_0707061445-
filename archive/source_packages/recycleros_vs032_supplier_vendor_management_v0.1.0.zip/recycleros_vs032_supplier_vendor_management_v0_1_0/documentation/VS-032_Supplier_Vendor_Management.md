# VS-032 Supplier & Vendor Management

Capabilities:
- Supplier Management
- Vendor Performance
- Procurement Support
- Compliance Vendor Tracking
- Disposal Vendor Tracking

Acceptance Criteria:
1. User can create vendor record.
2. Vendor can be typed as salvage yard, auction, disposal, shipping, repair, marketplace, or other.
3. Vendor contacts can be stored.
4. Vendor performance snapshot can store reliability and rating.
5. Vendor record can link to auction source or disposal record.
6. Offline vendor record saves with sync status.
