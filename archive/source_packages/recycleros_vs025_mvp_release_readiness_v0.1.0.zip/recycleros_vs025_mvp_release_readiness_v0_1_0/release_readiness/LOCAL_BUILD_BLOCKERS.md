# Local Build Blockers

1. Generated packages must be merged into one repository.
2. Flutter imports must be resolved.
3. Flutter routes must be registered.
4. FastAPI routers must be registered.
5. API schema imports must be consolidated.
6. PostgreSQL migration order must be validated.
7. SQLite migrations need guarded ALTER TABLE handling.
8. Auth and permission checks are scaffolded but not implemented.
9. Offline sync queue exists structurally but is not operational yet.
10. Business rules and decision engine are scaffolded only.
