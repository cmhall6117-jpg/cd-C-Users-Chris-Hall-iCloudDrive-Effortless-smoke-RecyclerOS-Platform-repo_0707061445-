import 'package:flutter/material.dart';

class MissionControlDashboardScreen extends StatelessWidget {
  const MissionControlDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tiles = [
      ('Open Opportunities', '14', Icons.search),
      ('Pick List Items', '8', Icons.list_alt),
      ('Inventory Available', '126', Icons.inventory),
      ('Pending Sync', '3', Icons.sync),
      ('Sales Today', '1245 USD', Icons.attach_money),
      ('Projected Opportunity', '8750 USD', Icons.trending_up),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Mission Control')),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        childAspectRatio: 1.35,
        children: [
          for (final tile in tiles)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(tile.$3),
                  const Spacer(),
                  Text(tile.$2, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  Text(tile.$1),
                ]),
              ),
            ),
        ],
      ),
    );
  }
}
