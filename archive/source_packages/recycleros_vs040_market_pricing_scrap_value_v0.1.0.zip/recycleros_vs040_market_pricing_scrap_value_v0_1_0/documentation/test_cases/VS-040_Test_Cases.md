# VS-040 Market Pricing & Scrap Value Test Cases

TC-001 Market Snapshot: pricing.market_snapshot_created event is recorded.
TC-002 Scrap Value: local scrap value stores material, unit, market, and price.
TC-003 Recommendation: pricing recommendation returns action, reason, and confidence.
TC-004 Inventory Link: market snapshot can link to inventory item.
TC-005 Offline Pricing: pricing records save locally with sync_status pending.
