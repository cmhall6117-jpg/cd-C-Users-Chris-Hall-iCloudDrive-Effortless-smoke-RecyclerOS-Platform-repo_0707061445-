class AuditEventTypes {
  static const auditViewed = 'audit.viewed';
  static const eventReviewed = 'event.reviewed';
  static const objectTimelineViewed = 'object_timeline.viewed';
  static const auditExportRequested = 'audit.export_requested';
}
