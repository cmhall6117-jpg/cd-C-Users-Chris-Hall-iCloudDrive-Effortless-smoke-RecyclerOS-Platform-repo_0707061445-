class CustomerInventoryMatch {
  final String matchId;
  final String customerId;
  final String inventoryItemId;
  final String reason;
  final double confidenceScore;
  final DateTime createdAt;

  const CustomerInventoryMatch({
    required this.matchId,
    required this.customerId,
    required this.inventoryItemId,
    required this.reason,
    required this.confidenceScore,
    required this.createdAt,
  });
}
