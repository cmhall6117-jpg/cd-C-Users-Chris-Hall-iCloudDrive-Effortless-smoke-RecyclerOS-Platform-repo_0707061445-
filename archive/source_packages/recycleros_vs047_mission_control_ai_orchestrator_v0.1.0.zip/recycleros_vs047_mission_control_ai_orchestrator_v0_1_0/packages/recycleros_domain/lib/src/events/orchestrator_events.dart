class OrchestratorEventTypes {
  static const snapshotGenerated = 'orchestrator.snapshot_generated';
  static const actionCreated = 'orchestrator.action_created';
  static const actionPrioritized = 'orchestrator.action_prioritized';
  static const actionCompleted = 'orchestrator.action_completed';
}
