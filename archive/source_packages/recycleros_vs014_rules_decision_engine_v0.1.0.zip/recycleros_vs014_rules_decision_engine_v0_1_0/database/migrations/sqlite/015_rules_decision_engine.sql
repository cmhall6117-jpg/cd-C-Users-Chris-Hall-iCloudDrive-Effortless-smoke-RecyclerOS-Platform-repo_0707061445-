CREATE TABLE IF NOT EXISTS business_rules (
    id TEXT PRIMARY KEY,
    rule_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    condition_expression TEXT NOT NULL,
    action_expression TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS rule_evaluations (
    id TEXT PRIMARY KEY,
    business_rule_id TEXT NOT NULL,
    related_object_type TEXT NOT NULL,
    related_object_id TEXT NOT NULL,
    result INTEGER NOT NULL,
    context TEXT NOT NULL DEFAULT '{}',
    evaluated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS decision_recommendations (
    id TEXT PRIMARY KEY,
    recommendation_code TEXT UNIQUE NOT NULL,
    recommendation_type TEXT NOT NULL,
    related_object_type TEXT NOT NULL,
    related_object_id TEXT NOT NULL,
    recommendation TEXT NOT NULL,
    reasoning TEXT NOT NULL,
    confidence_score REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS recommendation_outcomes (
    id TEXT PRIMARY KEY,
    recommendation_id TEXT NOT NULL,
    outcome_type TEXT NOT NULL,
    outcome_summary TEXT,
    financial_impact REAL,
    recorded_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
