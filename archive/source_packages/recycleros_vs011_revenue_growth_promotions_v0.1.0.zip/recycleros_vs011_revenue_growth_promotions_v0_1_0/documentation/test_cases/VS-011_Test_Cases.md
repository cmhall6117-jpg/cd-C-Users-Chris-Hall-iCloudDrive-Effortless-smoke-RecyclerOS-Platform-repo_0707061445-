# VS-011 Revenue Growth & Promotion Test Cases

TC-001 Create Campaign: promotion campaign draft is created.
TC-002 Link Inventory: selected inventory items link to campaign.
TC-003 Recommendation: recommendation returns reason, action, and confidence score.
TC-004 Human Approval: campaign remains draft until user launches.
TC-005 Offline Draft: campaign saves locally with sync_status pending.
