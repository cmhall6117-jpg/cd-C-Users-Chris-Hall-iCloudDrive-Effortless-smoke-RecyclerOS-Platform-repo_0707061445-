class Customer {
  final String customerId;
  final String customerCode;
  final String displayName;
  final String? email;
  final String? phone;

  const Customer({
    required this.customerId,
    required this.customerCode,
    required this.displayName,
    this.email,
    this.phone,
  });
}
