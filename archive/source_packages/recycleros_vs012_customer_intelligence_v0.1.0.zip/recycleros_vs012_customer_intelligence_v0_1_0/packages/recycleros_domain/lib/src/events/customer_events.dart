class CustomerEventTypes {
  static const customerCreated = 'customer.created';
  static const customerPreferenceUpdated = 'customer.preference_updated';
  static const customerMatchedToInventory = 'customer.matched_to_inventory';
  static const customerOutreachRecommended = 'customer.outreach_recommended';
}
