class PromotionEventTypes {
  static const promotionRecommended = 'promotion.recommended';
  static const promotionCampaignCreated = 'promotion.campaign_created';
  static const promotionCampaignLaunched = 'promotion.campaign_launched';
  static const promotionCampaignCompleted = 'promotion.campaign_completed';
}
