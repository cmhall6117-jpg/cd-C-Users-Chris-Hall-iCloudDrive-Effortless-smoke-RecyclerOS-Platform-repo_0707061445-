# VS-045 Executive Reporting & Business Review Test Cases

TC-001 Create Business Review: reporting.business_review_created event is recorded.
TC-002 Add Section: report section links to review pack.
TC-003 Latest Review: API returns latest review scaffold.
TC-004 Export Request: report export request can be represented.
TC-005 Offline Draft: review drafts save locally with sync_status pending.
