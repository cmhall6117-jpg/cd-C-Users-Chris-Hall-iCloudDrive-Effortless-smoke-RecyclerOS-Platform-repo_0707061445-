-- For SQLite, add columns only if migration manager confirms they do not exist.
-- These statements are scaffold notes and may require guarded migration execution.

CREATE TABLE IF NOT EXISTS device_status_snapshots (
    id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    app_version TEXT NOT NULL,
    connection_status TEXT NOT NULL,
    battery_percent REAL,
    pending_sync_count INTEGER NOT NULL DEFAULT 0,
    captured_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE INDEX IF NOT EXISTS idx_device_status_device ON device_status_snapshots(device_id);
