CREATE TABLE IF NOT EXISTS customer_leads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_code TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'new',
    source_channel TEXT NOT NULL,
    customer_id UUID REFERENCES customers(id),
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS outreach_activities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id UUID REFERENCES customer_leads(id),
    channel TEXT NOT NULL,
    message_summary TEXT NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    follow_up_at TIMESTAMPTZ
);
