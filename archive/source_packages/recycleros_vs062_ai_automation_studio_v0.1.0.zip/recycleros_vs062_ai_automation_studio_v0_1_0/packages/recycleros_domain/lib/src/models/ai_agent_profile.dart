class AiAgentProfile {
  final String aiAgentProfileId;
  final String agentCode;
  final String organizationId;
  final String workspaceId;
  final String name;
  final String purpose;
  final String modelReference;
  final String status;
  final DateTime createdAt;

  const AiAgentProfile({
    required this.aiAgentProfileId,
    required this.agentCode,
    required this.organizationId,
    required this.workspaceId,
    required this.name,
    required this.purpose,
    required this.modelReference,
    required this.status,
    required this.createdAt,
  });
}
