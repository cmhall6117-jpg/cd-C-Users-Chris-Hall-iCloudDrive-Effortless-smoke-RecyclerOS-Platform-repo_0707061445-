class AuctionEventTypes {
  static const auctionSourceCreated = 'auction.source_created';
  static const auctionVehicleWatched = 'auction.vehicle_watched';
  static const auctionFeeRecorded = 'auction.fee_recorded';
  static const sourceReliabilityUpdated = 'auction.source_reliability_updated';
}
