enum LedgerAccountType {
  asset,
  liability,
  equity,
  revenue,
  expense,
  costOfGoodsSold,
}
