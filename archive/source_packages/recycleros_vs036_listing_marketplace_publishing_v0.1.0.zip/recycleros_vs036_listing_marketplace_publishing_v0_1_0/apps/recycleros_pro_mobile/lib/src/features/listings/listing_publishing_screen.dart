import 'package:flutter/material.dart';

class ListingPublishingScreen extends StatelessWidget {
  const ListingPublishingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final listings = [
      ('INV-000001 ECM / PCM', 'eBay', 'Draft • 225 USD'),
      ('INV-000002 LED Headlight', 'Marketplace', 'Ready • 380 USD'),
      ('INV-000003 Transmission', 'Manual', 'Draft • 950 USD'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Listing & Marketplace')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Marketplace Listings', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Create listings from inventory with photos, pricing, descriptions, and channel status.'),
          const SizedBox(height: 16),
          for (final listing in listings)
            Card(child: ListTile(leading: const Icon(Icons.storefront), title: Text(listing.$1), subtitle: Text('${listing.$2} • ${listing.$3}'))),
        ],
      ),
    );
  }
}
