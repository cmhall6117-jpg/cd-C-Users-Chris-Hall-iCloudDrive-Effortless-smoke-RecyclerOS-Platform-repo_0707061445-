class PromotionCampaign {
  final String promotionCampaignId;
  final String campaignCode;
  final String title;
  final String status;
  final double? targetDiscountPercent;
  final double? projectedRevenueImpact;
  final DateTime createdAt;
  final DateTime? launchedAt;
  final DateTime? completedAt;

  const PromotionCampaign({
    required this.promotionCampaignId,
    required this.campaignCode,
    required this.title,
    required this.status,
    this.targetDiscountPercent,
    this.projectedRevenueImpact,
    required this.createdAt,
    this.launchedAt,
    this.completedAt,
  });
}
