CREATE TABLE IF NOT EXISTS qa_test_runs (
    id TEXT PRIMARY KEY,
    test_run_code TEXT UNIQUE NOT NULL,
    test_type TEXT NOT NULL,
    status TEXT NOT NULL,
    summary TEXT,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS qa_test_results (
    id TEXT PRIMARY KEY,
    test_run_id TEXT NOT NULL,
    test_case_code TEXT NOT NULL,
    status TEXT NOT NULL,
    message TEXT,
    executed_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
