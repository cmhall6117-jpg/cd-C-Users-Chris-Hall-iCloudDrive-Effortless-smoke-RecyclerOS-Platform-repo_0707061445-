# Release Readiness Checklist

- [ ] All critical defects closed.
- [ ] Smoke tests passed.
- [ ] API endpoints verified.
- [ ] Flutter routes verified.
- [ ] PostgreSQL migrations validated.
- [ ] SQLite migrations validated.
- [ ] Offline sync queue tested.
- [ ] RB-003 updated.
- [ ] Product Owner acceptance recorded.
