class ComplianceEventTypes {
  static const complianceRecordCreated = 'compliance.record_created';
  static const disposalRecordCreated = 'disposal.record_created';
  static const complianceAlertTriggered = 'compliance.alert_triggered';
  static const complianceOverrideApproved = 'compliance.override_approved';
}
