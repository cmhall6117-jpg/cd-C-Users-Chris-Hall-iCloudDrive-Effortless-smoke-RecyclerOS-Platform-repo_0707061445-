# RC1 Known Defects

No defects are considered closed until supported by build/test evidence.

| Defect ID | Severity | Area | Description | Status | Owner | Target |
|---|---|---|---|---|---|---|
| DEF-RC1-001 | Critical | Integration | Integrated repository not yet assembled and compiled | Open | Codex/Development | Before RC1 approval |
| DEF-RC1-002 | Critical | Database | Full migration chain not yet validated | Open | Development | Before RC1 approval |
| DEF-RC1-003 | High | Flutter | Full route registration not yet validated | Open | Development | Before RC1 approval |
| DEF-RC1-004 | High | API | Full router registration not yet validated | Open | Development | Before RC1 approval |
| DEF-RC1-005 | High | Security | Production authentication implementation not yet validated | Open | Development/Security | Before production |
