class ScanRecord {
  final String scanRecordId;
  final String scanCode;
  final String scanType;
  final String scannedValue;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime scannedAt;

  const ScanRecord({
    required this.scanRecordId,
    required this.scanCode,
    required this.scanType,
    required this.scannedValue,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.scannedAt,
  });
}
