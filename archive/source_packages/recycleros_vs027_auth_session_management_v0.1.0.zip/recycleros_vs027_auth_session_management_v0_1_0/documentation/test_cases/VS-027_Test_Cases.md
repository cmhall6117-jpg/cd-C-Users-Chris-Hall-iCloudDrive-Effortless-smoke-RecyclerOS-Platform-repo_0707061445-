# VS-027 Authentication & Session Management Test Cases

TC-001 Login Screen Loads: login form displays email and password fields.
TC-002 Login API: /auth/login returns session scaffold.
TC-003 Session Created Event: successful login returns auth.session_created event.
TC-004 Logout API: logout marks session logged_out.
TC-005 Login Attempt: login attempt can be recorded.
TC-006 Offline Security: offline mode does not bypass permissions or session validity.
