class CompatibilityRecord {
  final String compatibilityRecordId;
  final String partName;
  final String donorVehicleDescription;
  final String compatibleVehicleRange;
  final String compatibilityNotes;
  final double confidenceScore;

  const CompatibilityRecord({
    required this.compatibilityRecordId,
    required this.partName,
    required this.donorVehicleDescription,
    required this.compatibleVehicleRange,
    required this.compatibilityNotes,
    required this.confidenceScore,
  });
}
