from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class SocialPostCreate(BaseModel):
    channel: str
    body: str
    related_object_type: str | None = None
    related_object_id: str | None = None
    scheduled_at: str | None = None

@router.post('/posts')
def create_social_post(payload: SocialPostCreate):
    return {
        'social_post_id': 'SOC-DEMO-000001',
        'post_code': 'SOC-000001',
        'channel': payload.channel,
        'body': payload.body,
        'status': 'draft',
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'scheduled_at': payload.scheduled_at,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'social.post_drafted'
    }

@router.post('/posts/{post_id}/schedule')
def schedule_social_post(post_id: str):
    return {
        'social_post_id': post_id,
        'status': 'scheduled',
        'event_created': 'social.post_scheduled'
    }
