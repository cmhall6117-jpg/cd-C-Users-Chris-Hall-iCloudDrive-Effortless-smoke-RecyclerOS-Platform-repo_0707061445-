enum SyncStatus {
  pending,
  syncing,
  synced,
  failed,
  ignored,
}
