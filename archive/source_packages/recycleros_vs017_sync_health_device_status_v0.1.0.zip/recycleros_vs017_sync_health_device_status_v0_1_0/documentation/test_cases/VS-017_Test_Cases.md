# VS-017 Sync Health & Device Status Test Cases

TC-001 Sync Summary: sync health summary returns pending, synced, and failed counts.
TC-002 Device Status: device status capture creates device.status_captured event.
TC-003 Failed Sync: failed records retain retry count and error message.
TC-004 Offline Queue: user can review pending sync records.
TC-005 Dashboard Link: Mission Control can display pending sync count.
