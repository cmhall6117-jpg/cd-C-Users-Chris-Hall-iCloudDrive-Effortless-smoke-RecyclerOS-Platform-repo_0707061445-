class TenantEventTypes {
  static const organizationCreated = 'tenant.organization_created';
  static const workspaceCreated = 'tenant.workspace_created';
  static const branchCreated = 'tenant.branch_created';
  static const membershipAdded = 'tenant.membership_added';
  static const membershipRemoved = 'tenant.membership_removed';
  static const workspaceSwitched = 'tenant.workspace_switched';
  static const isolationViolationDetected = 'tenant.isolation_violation_detected';
}
