from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class DeviceStatusCreate(BaseModel):
    device_id: str
    app_version: str
    connection_status: str
    battery_percent: float | None = None
    pending_sync_count: int = 0

@router.post('/device-status')
def capture_device_status(payload: DeviceStatusCreate):
    return {
        'device_status_id': 'DST-DEMO-000001',
        'device_id': payload.device_id,
        'app_version': payload.app_version,
        'connection_status': payload.connection_status,
        'battery_percent': payload.battery_percent,
        'pending_sync_count': payload.pending_sync_count,
        'captured_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'device.status_captured'
    }

@router.get('/summary')
def sync_health_summary():
    return {
        'pending': 3,
        'syncing': 0,
        'synced_today': 42,
        'failed': 1,
        'last_sync_at': datetime.now(timezone.utc).isoformat()
    }
