CREATE TABLE IF NOT EXISTS business_review_packs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    review_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    reporting_period TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS report_sections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_review_pack_id UUID REFERENCES business_review_packs(id),
    section_type TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0
);
