class IdentityEventTypes {
  static const loginStarted = 'identity.login_started';
  static const loginSucceeded = 'identity.login_succeeded';
  static const loginFailed = 'identity.login_failed';
  static const sessionCreated = 'identity.session_created';
  static const sessionRevoked = 'identity.session_revoked';
  static const mfaVerified = 'identity.mfa_verified';
  static const providerLinked = 'identity.provider_linked';
  static const deviceRegistered = 'identity.device_registered';
  static const deviceRevoked = 'identity.device_revoked';
}
