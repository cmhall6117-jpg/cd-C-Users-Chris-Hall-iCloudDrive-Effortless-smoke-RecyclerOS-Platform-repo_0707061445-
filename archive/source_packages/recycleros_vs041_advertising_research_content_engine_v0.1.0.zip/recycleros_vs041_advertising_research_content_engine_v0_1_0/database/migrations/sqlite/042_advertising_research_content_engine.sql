CREATE TABLE IF NOT EXISTS advertising_research_records (
    id TEXT PRIMARY KEY,
    research_code TEXT UNIQUE NOT NULL,
    channel TEXT NOT NULL,
    audience TEXT NOT NULL,
    product_category TEXT NOT NULL,
    notes TEXT,
    confidence_score REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS promotional_content_drafts (
    id TEXT PRIMARY KEY,
    content_code TEXT UNIQUE NOT NULL,
    promotion_campaign_id TEXT,
    channel TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
