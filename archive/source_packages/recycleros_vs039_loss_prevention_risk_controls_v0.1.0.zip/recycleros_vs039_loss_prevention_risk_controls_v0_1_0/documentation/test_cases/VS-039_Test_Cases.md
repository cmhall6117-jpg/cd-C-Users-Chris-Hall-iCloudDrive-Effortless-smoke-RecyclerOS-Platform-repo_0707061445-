# VS-039 Loss Prevention, Fraud & Risk Controls Test Cases

TC-001 Create Risk Flag: risk.flag_created event is recorded.
TC-002 Related Object Link: flag links to order, return, inventory, customer, user, or transaction.
TC-003 Approval Hold: sensitive workflow can be placed on hold.
TC-004 Audit Visibility: risk event is audit-ready.
TC-005 Offline Risk: risk records save locally with sync_status pending.
