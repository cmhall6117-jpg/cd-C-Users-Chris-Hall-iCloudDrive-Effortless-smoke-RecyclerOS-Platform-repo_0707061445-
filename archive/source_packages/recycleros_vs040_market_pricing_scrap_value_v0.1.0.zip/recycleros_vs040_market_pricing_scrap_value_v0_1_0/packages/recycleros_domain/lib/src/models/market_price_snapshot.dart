class MarketPriceSnapshot {
  final String marketPriceSnapshotId;
  final String snapshotCode;
  final String? inventoryItemId;
  final String partName;
  final double lowPrice;
  final double averagePrice;
  final double highPrice;
  final double confidenceScore;
  final String sourceSummary;
  final DateTime capturedAt;

  const MarketPriceSnapshot({
    required this.marketPriceSnapshotId,
    required this.snapshotCode,
    this.inventoryItemId,
    required this.partName,
    required this.lowPrice,
    required this.averagePrice,
    required this.highPrice,
    required this.confidenceScore,
    required this.sourceSummary,
    required this.capturedAt,
  });
}
