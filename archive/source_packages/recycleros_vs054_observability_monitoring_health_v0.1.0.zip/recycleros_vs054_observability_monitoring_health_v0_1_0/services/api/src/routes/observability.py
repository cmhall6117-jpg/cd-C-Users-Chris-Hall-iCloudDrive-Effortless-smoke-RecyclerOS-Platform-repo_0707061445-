from datetime import datetime, timezone
from fastapi import APIRouter

router = APIRouter()

@router.get('/health')
def health():
    return {
        'service': 'recycleros-api',
        'status': 'ok',
        'captured_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'observability.health_snapshot_captured'
    }

@router.get('/metrics')
def metrics():
    return {
        'items': [
            {'metric_name': 'api_response_time_ms', 'value': 42, 'unit': 'ms'},
            {'metric_name': 'pending_sync_count', 'value': 0, 'unit': 'count'}
        ]
    }
