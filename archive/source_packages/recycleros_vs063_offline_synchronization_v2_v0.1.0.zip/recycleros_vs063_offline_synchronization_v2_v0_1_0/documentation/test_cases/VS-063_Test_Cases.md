# VS-063 Offline Synchronization v2 Test Cases

TC-001 Create Sync Batch.
TC-002 Resume from checkpoint.
TC-003 Enforce tenant isolation.
TC-004 Resolve server_wins.
TC-005 Resolve client_wins.
TC-006 Resolve last_write_wins.
TC-007 Resolve field_merge.
TC-008 Pause manual_review conflicts.
TC-009 Apply retry backoff.
TC-010 Move exhausted retries to dead letter.
TC-011 Preserve recovery audit history.
