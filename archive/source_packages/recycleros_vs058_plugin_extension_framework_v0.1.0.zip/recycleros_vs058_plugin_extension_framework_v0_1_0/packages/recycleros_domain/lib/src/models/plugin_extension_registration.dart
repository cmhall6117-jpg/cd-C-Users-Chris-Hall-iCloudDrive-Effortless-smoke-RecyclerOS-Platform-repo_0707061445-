class PluginExtensionRegistration {
  final String registrationId;
  final String installedPluginId;
  final String extensionType;
  final String extensionKey;
  final String configurationJson;
  final String status;

  const PluginExtensionRegistration({
    required this.registrationId,
    required this.installedPluginId,
    required this.extensionType,
    required this.extensionKey,
    required this.configurationJson,
    required this.status,
  });
}
