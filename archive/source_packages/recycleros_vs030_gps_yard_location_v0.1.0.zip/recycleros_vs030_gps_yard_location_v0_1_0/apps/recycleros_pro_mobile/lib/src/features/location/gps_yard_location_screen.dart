import 'package:flutter/material.dart';

class GpsYardLocationScreen extends StatelessWidget {
  const GpsYardLocationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final pins = [
      ('Vehicle Pin', 'VEH-000001 • Row 12'),
      ('Storage Pin', 'Rack A / Shelf 1'),
      ('Harvest Pin', 'HVS-000001'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('GPS Yard Location')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: null,
        icon: const Icon(Icons.gps_fixed),
        label: const Text('Capture GPS'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Yard Location Pins', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('GPS capture and map display wiring pending. Manual yard/row fallback supported.'),
          const SizedBox(height: 16),
          for (final pin in pins)
            Card(child: ListTile(leading: const Icon(Icons.location_pin), title: Text(pin.$1), subtitle: Text(pin.$2))),
        ],
      ),
    );
  }
}
