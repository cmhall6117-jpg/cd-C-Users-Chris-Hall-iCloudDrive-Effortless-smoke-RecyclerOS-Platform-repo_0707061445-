CREATE TABLE IF NOT EXISTS business_review_packs (
    id TEXT PRIMARY KEY,
    review_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    reporting_period TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TEXT NOT NULL,
    approved_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS report_sections (
    id TEXT PRIMARY KEY,
    business_review_pack_id TEXT NOT NULL,
    section_type TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
