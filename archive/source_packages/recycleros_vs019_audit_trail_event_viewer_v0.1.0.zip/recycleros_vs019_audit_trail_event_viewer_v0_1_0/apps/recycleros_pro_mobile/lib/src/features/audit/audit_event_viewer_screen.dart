import 'package:flutter/material.dart';

class AuditEventViewerScreen extends StatelessWidget {
  const AuditEventViewerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final events = [
      ('EVT-000001', 'opportunity.discovered', 'Opportunity', 'OPP-000001'),
      ('EVT-000002', 'vehicle.evaluated', 'Vehicle', 'VEH-000001'),
      ('EVT-000003', 'inventory.created', 'Inventory Item', 'INV-000001'),
      ('EVT-000004', 'recommendation.approved', 'Recommendation', 'REC-000001'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Audit Trail')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Event Viewer', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Audit records are read-only and preserve object history.'),
          const SizedBox(height: 16),
          for (final event in events)
            Card(
              child: ListTile(
                leading: const Icon(Icons.history),
                title: Text('${event.$1} • ${event.$2}'),
                subtitle: Text('${event.$3}: ${event.$4}'),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
