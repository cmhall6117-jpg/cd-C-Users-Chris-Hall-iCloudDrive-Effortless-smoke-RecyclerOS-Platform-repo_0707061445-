import 'package:flutter/material.dart';

class MarketPricingScreen extends StatelessWidget {
  const MarketPricingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prices = [
      ('ECM / PCM', 'Avg: 225 USD • Confidence 76%'),
      ('Aluminum Scrap', '0.62 USD/lb • Local market pending'),
      ('Catalytic Converter', 'Scrap value requires verified quote'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Market Pricing')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Pricing & Scrap Value Intelligence', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Track part market prices, local scrap values, and sell/hold/discount/scrap recommendations.'),
          const SizedBox(height: 16),
          for (final price in prices)
            Card(child: ListTile(leading: const Icon(Icons.price_check), title: Text(price.$1), subtitle: Text(price.$2))),
        ],
      ),
    );
  }
}
