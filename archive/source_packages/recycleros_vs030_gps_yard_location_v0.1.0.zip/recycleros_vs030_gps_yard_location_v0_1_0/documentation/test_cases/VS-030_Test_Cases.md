# VS-030 GPS Yard Location Test Cases

TC-001 GPS Screen Loads: GPS yard location screen displays.
TC-002 Capture GPS: gps.location_captured event is recorded.
TC-003 Yard Pin: yard pin can link to vehicle, harvest session, or storage location.
TC-004 Accuracy Warning: low GPS accuracy can trigger warning event.
TC-005 Offline GPS: GPS and pin records save locally with sync_status pending.
