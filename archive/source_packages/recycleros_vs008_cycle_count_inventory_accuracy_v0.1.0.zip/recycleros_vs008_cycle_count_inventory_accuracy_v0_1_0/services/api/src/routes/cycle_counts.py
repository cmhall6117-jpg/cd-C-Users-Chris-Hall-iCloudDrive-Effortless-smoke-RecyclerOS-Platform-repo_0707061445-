from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class CycleCountLineInput(BaseModel):
    inventory_item_id: str
    expected_quantity: int
    counted_quantity: int
    notes: str | None = None

class CycleCountComplete(BaseModel):
    storage_location_id: str | None = None
    lines: list[CycleCountLineInput]

@router.post('/complete')
def complete_cycle_count(payload: CycleCountComplete):
    variances = []
    for line in payload.lines:
        variance = line.counted_quantity - line.expected_quantity
        if variance != 0:
            variances.append({
                'inventory_item_id': line.inventory_item_id,
                'variance': variance,
                'event_created': 'inventory.discrepancy_found'
            })

    total = len(payload.lines)
    accurate = total - len(variances)
    accuracy = 100 if total == 0 else round((accurate / total) * 100, 2)

    return {
        'cycle_count_session_id': 'CC-DEMO-000001',
        'completed_at': datetime.now(timezone.utc).isoformat(),
        'inventory_accuracy_percent': accuracy,
        'variance_count': len(variances),
        'variances': variances,
        'event_created': 'cycle_count.completed'
    }
