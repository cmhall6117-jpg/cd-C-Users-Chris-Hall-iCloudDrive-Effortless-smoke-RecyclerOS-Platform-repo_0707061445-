class AutomationDefinition {
  final String automationDefinitionId;
  final String automationCode;
  final String organizationId;
  final String workspaceId;
  final String name;
  final String description;
  final String status;
  final int version;
  final DateTime createdAt;
  final DateTime updatedAt;

  const AutomationDefinition({
    required this.automationDefinitionId,
    required this.automationCode,
    required this.organizationId,
    required this.workspaceId,
    required this.name,
    required this.description,
    required this.status,
    required this.version,
    required this.createdAt,
    required this.updatedAt,
  });
}
