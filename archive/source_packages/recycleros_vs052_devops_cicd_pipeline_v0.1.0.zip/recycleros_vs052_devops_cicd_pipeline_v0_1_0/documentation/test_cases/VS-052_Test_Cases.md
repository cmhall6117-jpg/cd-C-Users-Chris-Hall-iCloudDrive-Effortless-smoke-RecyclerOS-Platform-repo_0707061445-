# VS-052 Developer Operations & CI/CD Pipeline Test Cases

TC-001 Backend CI Exists: backend GitHub Actions workflow exists.
TC-002 Flutter CI Exists: Flutter GitHub Actions workflow exists.
TC-003 Pipeline Run: devops.pipeline_run_started event is recorded.
TC-004 Release Gate: release gate check can be stored.
TC-005 Offline Metadata: pipeline metadata saves locally with sync_status pending.
