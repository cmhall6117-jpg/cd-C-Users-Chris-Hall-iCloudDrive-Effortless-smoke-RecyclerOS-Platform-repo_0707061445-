CREATE TABLE IF NOT EXISTS sync_queue_items_v2 (
    id TEXT PRIMARY KEY,
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    local_version INTEGER NOT NULL DEFAULT 1,
    server_version INTEGER,
    status TEXT NOT NULL DEFAULT 'pending',
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS sync_batches_v2 (
    id TEXT PRIMARY KEY,
    batch_code TEXT UNIQUE NOT NULL,
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'started',
    total_items INTEGER NOT NULL DEFAULT 0,
    completed_items INTEGER NOT NULL DEFAULT 0,
    failed_items INTEGER NOT NULL DEFAULT 0,
    checkpoint_token TEXT,
    started_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS sync_conflicts_v2 (
    id TEXT PRIMARY KEY,
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    local_payload_json TEXT NOT NULL,
    server_payload_json TEXT NOT NULL,
    merge_strategy TEXT NOT NULL DEFAULT 'manual_review',
    status TEXT NOT NULL DEFAULT 'open',
    detected_at TEXT NOT NULL,
    resolved_at TEXT,
    resolution_payload_json TEXT
);

CREATE TABLE IF NOT EXISTS sync_dead_letter_items (
    id TEXT PRIMARY KEY,
    sync_queue_item_id TEXT,
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    failure_reason TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    recovered_at TEXT
);
