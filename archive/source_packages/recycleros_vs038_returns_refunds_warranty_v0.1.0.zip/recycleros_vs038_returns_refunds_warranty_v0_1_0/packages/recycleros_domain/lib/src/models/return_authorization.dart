class ReturnAuthorization {
  final String returnAuthorizationId;
  final String returnCode;
  final String salesOrderId;
  final String inventoryItemId;
  final String reasonCode;
  final String status;
  final double? refundAmount;
  final DateTime createdAt;
  final DateTime? completedAt;

  const ReturnAuthorization({
    required this.returnAuthorizationId,
    required this.returnCode,
    required this.salesOrderId,
    required this.inventoryItemId,
    required this.reasonCode,
    required this.status,
    this.refundAmount,
    required this.createdAt,
    this.completedAt,
  });
}
