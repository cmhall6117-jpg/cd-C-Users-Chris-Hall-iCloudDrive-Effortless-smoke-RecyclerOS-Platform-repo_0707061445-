import 'package:flutter/material.dart';

class SalesOrderScreen extends StatelessWidget {
  const SalesOrderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('INV-000001', 'ECM / PCM', '\$225.00'),
      ('INV-000002', 'LED Headlight LH', '\$380.00'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Sales & Fulfillment')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Create Sales Order', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Card(
            child: ListTile(
              leading: Icon(Icons.person),
              title: Text('Customer'),
              subtitle: Text('Walk-in / marketplace buyer'),
            ),
          ),
          const Text('Inventory Items', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (final item in items)
            Card(
              child: ListTile(
                leading: const Icon(Icons.inventory),
                title: Text(item.$2),
                subtitle: Text(item.$1),
                trailing: Text(item.$3),
              ),
            ),
          const SizedBox(height: 16),
          const Card(
            child: ListTile(
              leading: Icon(Icons.receipt_long),
              title: Text('Estimated Total'),
              subtitle: Text('Subtotal, tax, shipping, and fees will calculate here.'),
            ),
          ),
          FilledButton.icon(
            onPressed: null,
            icon: Icon(Icons.check),
            label: Text('Create Order'),
          ),
        ],
      ),
    );
  }
}
