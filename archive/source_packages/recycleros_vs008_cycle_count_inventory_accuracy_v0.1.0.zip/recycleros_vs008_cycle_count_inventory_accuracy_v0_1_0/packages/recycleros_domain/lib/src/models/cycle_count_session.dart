import 'cycle_count_status.dart';

class CycleCountSession {
  final String cycleCountSessionId;
  final String cycleCountCode;
  final String? storageLocationId;
  final CycleCountStatus status;
  final DateTime startedAt;
  final DateTime? completedAt;
  final String? performedBy;

  const CycleCountSession({
    required this.cycleCountSessionId,
    required this.cycleCountCode,
    this.storageLocationId,
    required this.status,
    required this.startedAt,
    this.completedAt,
    this.performedBy,
  });
}
