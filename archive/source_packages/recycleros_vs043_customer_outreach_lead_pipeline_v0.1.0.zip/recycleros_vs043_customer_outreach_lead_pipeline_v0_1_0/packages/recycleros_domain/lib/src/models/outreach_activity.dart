class OutreachActivity {
  final String outreachActivityId;
  final String leadId;
  final String channel;
  final String messageSummary;
  final DateTime occurredAt;
  final DateTime? followUpAt;

  const OutreachActivity({
    required this.outreachActivityId,
    required this.leadId,
    required this.channel,
    required this.messageSummary,
    required this.occurredAt,
    this.followUpAt,
  });
}
