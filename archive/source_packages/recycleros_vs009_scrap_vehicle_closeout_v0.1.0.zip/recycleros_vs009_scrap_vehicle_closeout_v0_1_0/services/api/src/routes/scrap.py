from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class ScrapCloseoutCreate(BaseModel):
    vehicle_id: str
    estimated_scrap_value: float = 0
    actual_scrap_value: float = 0
    hauling_cost: float = 0
    notes: str | None = None

@router.post('/closeout')
def create_scrap_closeout(payload: ScrapCloseoutCreate):
    net_value = payload.actual_scrap_value - payload.hauling_cost
    return {
        'scrap_disposition_id': 'SCR-DEMO-000001',
        'scrap_disposition_code': 'SCR-000001',
        'vehicle_id': payload.vehicle_id,
        'status': 'completed',
        'estimated_scrap_value': payload.estimated_scrap_value,
        'actual_scrap_value': payload.actual_scrap_value,
        'hauling_cost': payload.hauling_cost,
        'net_scrap_value': net_value,
        'completed_at': datetime.now(timezone.utc).isoformat(),
        'events_created': ['scrap.value_recorded', 'vehicle.scrapped']
    }
