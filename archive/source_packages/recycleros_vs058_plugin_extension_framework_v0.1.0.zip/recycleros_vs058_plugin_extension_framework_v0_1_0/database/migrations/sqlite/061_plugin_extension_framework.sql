CREATE TABLE IF NOT EXISTS plugin_registry (
    id TEXT PRIMARY KEY,
    plugin_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    vendor TEXT NOT NULL,
    current_version TEXT NOT NULL,
    api_version TEXT NOT NULL,
    description TEXT,
    license TEXT,
    status TEXT NOT NULL DEFAULT 'available',
    manifest_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS installed_plugins (
    id TEXT PRIMARY KEY,
    plugin_registry_id TEXT NOT NULL,
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    installed_version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'installed',
    installed_at TEXT NOT NULL,
    enabled_at TEXT,
    disabled_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS plugin_permissions (
    id TEXT PRIMARY KEY,
    installed_plugin_id TEXT NOT NULL,
    permission_code TEXT NOT NULL,
    approval_status TEXT NOT NULL DEFAULT 'pending',
    approved_by TEXT,
    approved_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS plugin_dependencies (
    id TEXT PRIMARY KEY,
    plugin_registry_id TEXT NOT NULL,
    required_plugin_id TEXT NOT NULL,
    version_constraint TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unresolved',
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS plugin_extension_registrations (
    id TEXT PRIMARY KEY,
    installed_plugin_id TEXT NOT NULL,
    extension_type TEXT NOT NULL,
    extension_key TEXT NOT NULL,
    configuration_json TEXT,
    status TEXT NOT NULL DEFAULT 'registered',
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS plugin_migration_runs (
    id TEXT PRIMARY KEY,
    installed_plugin_id TEXT NOT NULL,
    migration_name TEXT NOT NULL,
    migration_version TEXT NOT NULL,
    direction TEXT NOT NULL DEFAULT 'up',
    status TEXT NOT NULL DEFAULT 'pending',
    started_at TEXT,
    completed_at TEXT,
    error_message TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
