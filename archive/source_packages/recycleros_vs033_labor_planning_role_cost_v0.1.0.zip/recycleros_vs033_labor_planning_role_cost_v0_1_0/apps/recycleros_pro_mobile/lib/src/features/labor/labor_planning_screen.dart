import 'package:flutter/material.dart';

class LaborPlanningScreen extends StatelessWidget {
  const LaborPlanningScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final roles = [
      ('Picker / Technician', 'Intermediate', '18-24 USD/hr'),
      ('Inventory Specialist', 'Intermediate', '19-26 USD/hr'),
      ('Operations Manager', 'Advanced', '55k-75k USD/yr'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Labor Planning')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Role Cost Intelligence', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Planning support only. Verify pay practices with local labor laws and qualified guidance.'),
          const SizedBox(height: 16),
          for (final role in roles)
            Card(
              child: ListTile(
                leading: const Icon(Icons.engineering),
                title: Text(role.$1),
                subtitle: Text('${role.$2} • ${role.$3}'),
              ),
            ),
        ],
      ),
    );
  }
}
