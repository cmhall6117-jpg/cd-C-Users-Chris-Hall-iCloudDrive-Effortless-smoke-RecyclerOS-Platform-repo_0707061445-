class SalesOrder {
  final String salesOrderId;
  final String salesOrderCode;
  final String? customerId;
  final String status;
  final double subtotal;
  final double tax;
  final double shipping;
  final double total;
  final DateTime createdAt;

  const SalesOrder({
    required this.salesOrderId,
    required this.salesOrderCode,
    this.customerId,
    required this.status,
    required this.subtotal,
    required this.tax,
    required this.shipping,
    required this.total,
    required this.createdAt,
  });
}
