# VS-061 Enterprise Analytics & Data Warehouse

Capabilities:
- Enterprise Analytics
- Dimensional Data Warehouse
- Historical KPI Tracking
- Cross-Module Trend Analysis
- Executive Business Intelligence
- Warehouse Load Jobs
- Tenant-Scoped Analytics

Core Dimensions:
- Date
- Organization
- Workspace
- Branch
- Vehicle
- Inventory Item
- Customer
- Vendor
- User
- Marketplace Channel

Core Facts:
- Vehicle Acquisition
- Parts Harvest
- Inventory Movement
- Sales
- Returns
- Labor Cost
- Shipping Cost
- Marketing Performance
- Lead Conversion
- Risk Events
- Financial Performance

Acceptance Criteria:
1. Analytics snapshots preserve historical values.
2. Fact records carry organization_id, workspace_id, and date_id.
3. Warehouse-load jobs can track source, status, row counts, and errors.
4. Executive trend queries can compare periods.
5. Tenant data remains isolated.
6. Offline analytics metadata saves with sync status.
