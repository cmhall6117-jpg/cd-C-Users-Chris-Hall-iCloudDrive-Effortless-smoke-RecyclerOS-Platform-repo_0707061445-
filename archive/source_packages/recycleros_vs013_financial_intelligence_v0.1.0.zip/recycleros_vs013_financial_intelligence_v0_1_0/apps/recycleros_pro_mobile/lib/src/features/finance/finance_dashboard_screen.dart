import 'package:flutter/material.dart';

class FinanceDashboardScreen extends StatelessWidget {
  const FinanceDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final metrics = [
      ('Revenue Today', '1245 USD'),
      ('Inventory Value', '28750 USD'),
      ('Open Vehicle Profit', '6420 USD'),
      ('Pending Expenses', '315 USD'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Financial Intelligence')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Finance Dashboard', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('GAAP-aligned records. Review accounting treatment with a qualified professional.'),
          const SizedBox(height: 16),
          for (final metric in metrics)
            Card(child: ListTile(leading: const Icon(Icons.account_balance), title: Text(metric.$1), trailing: Text(metric.$2))),
        ],
      ),
    );
  }
}
