from datetime import datetime, timedelta, timezone

def next_retry_time(retry_count: int) -> str:
    delay_minutes = 2 ** min(retry_count, 8)
    return (datetime.now(timezone.utc) + timedelta(minutes=delay_minutes)).isoformat()

def should_dead_letter(retry_count: int, max_retries: int = 8) -> bool:
    return retry_count >= max_retries
