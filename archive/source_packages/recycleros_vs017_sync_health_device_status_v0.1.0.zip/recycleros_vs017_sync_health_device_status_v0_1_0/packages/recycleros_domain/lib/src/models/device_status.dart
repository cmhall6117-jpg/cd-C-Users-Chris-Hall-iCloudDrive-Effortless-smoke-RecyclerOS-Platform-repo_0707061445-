class DeviceStatus {
  final String deviceStatusId;
  final String deviceId;
  final String appVersion;
  final String connectionStatus;
  final double? batteryPercent;
  final int pendingSyncCount;
  final DateTime capturedAt;

  const DeviceStatus({
    required this.deviceStatusId,
    required this.deviceId,
    required this.appVersion,
    required this.connectionStatus,
    this.batteryPercent,
    required this.pendingSyncCount,
    required this.capturedAt,
  });
}
