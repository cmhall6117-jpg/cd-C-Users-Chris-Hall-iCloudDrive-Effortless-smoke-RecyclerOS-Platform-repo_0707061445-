import 'package:flutter/material.dart';

class PluginManagerScreen extends StatelessWidget {
  const PluginManagerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final plugins = [
      ('Inventory Insights', '1.0.0 • enabled'),
      ('Auction Connector', '0.9.0 • approval required'),
      ('QuickBooks Connector', '1.1.0 • disabled'),
      ('AI Pricing Extension', '2.0.0 • update available'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Plugin Manager')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Extensions & Plugins',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const Text(
            'Install, approve, enable, update, roll back, and audit platform extensions.',
          ),
          const SizedBox(height: 16),
          for (final plugin in plugins)
            Card(
              child: ListTile(
                leading: const Icon(Icons.extension),
                title: Text(plugin.$1),
                subtitle: Text(plugin.$2),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
