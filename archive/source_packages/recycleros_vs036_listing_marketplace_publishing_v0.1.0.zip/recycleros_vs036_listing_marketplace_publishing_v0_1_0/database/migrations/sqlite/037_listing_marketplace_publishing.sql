CREATE TABLE IF NOT EXISTS marketplace_listings (
    id TEXT PRIMARY KEY,
    listing_code TEXT UNIQUE NOT NULL,
    inventory_item_id TEXT NOT NULL,
    channel TEXT NOT NULL DEFAULT 'manual',
    title TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TEXT NOT NULL,
    published_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS listing_media_assets (
    id TEXT PRIMARY KEY,
    listing_id TEXT NOT NULL,
    media_asset_id TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
