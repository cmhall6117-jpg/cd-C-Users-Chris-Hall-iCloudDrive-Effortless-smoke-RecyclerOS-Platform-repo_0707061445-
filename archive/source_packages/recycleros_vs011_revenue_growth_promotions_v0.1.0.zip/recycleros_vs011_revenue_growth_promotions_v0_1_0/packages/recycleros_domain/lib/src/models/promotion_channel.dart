enum PromotionChannel {
  facebook,
  instagram,
  ebay,
  marketplace,
  email,
  sms,
  manual,
}
