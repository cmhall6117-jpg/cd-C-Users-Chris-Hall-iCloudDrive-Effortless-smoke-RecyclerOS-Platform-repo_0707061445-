from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from src.middleware.tenant_context import TenantContext, require_tenant_context
from src.sync.conflict_resolver import resolve_conflict
from src.sync.retry_policy import next_retry_time, should_dead_letter

router = APIRouter()

class SyncBatchCreate(BaseModel):
    device_id: str
    item_ids: list[str] = Field(default_factory=list)

class ConflictResolveRequest(BaseModel):
    local_payload: dict
    server_payload: dict
    strategy: str

@router.post('/batches')
def create_sync_batch(payload: SyncBatchCreate, context: TenantContext = Depends(require_tenant_context)):
    return {
        'sync_batch_id': 'SYN-BAT-DEMO-000001',
        'batch_code': 'SYN-BAT-000001',
        'organization_id': context.organization_id,
        'workspace_id': context.workspace_id,
        'device_id': payload.device_id,
        'status': 'started',
        'total_items': len(payload.item_ids),
        'checkpoint_token': None,
        'started_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'sync_v2.batch_started'
    }

@router.post('/conflicts/resolve')
def resolve_sync_conflict(payload: ConflictResolveRequest, context: TenantContext = Depends(require_tenant_context)):
    result = resolve_conflict(payload.local_payload, payload.server_payload, payload.strategy)
    return {
        'organization_id': context.organization_id,
        'workspace_id': context.workspace_id,
        'status': result.status,
        'merged_payload': result.merged_payload,
        'requires_manual_review': result.requires_manual_review,
        'event_created': 'sync_v2.conflict_resolved' if result.status == 'resolved' else 'sync_v2.conflict_detected'
    }

@router.post('/items/{item_id}/retry')
def retry_sync_item(item_id: str, retry_count: int, context: TenantContext = Depends(require_tenant_context)):
    if should_dead_letter(retry_count):
        return {'sync_queue_item_id': item_id, 'status': 'dead_letter', 'event_created': 'sync_v2.dead_letter_created'}
    return {'sync_queue_item_id': item_id, 'status': 'retry_scheduled', 'next_retry_at': next_retry_time(retry_count)}
