CREATE TABLE IF NOT EXISTS secret_references (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    secret_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    environment_code TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT 'environment',
    status TEXT NOT NULL DEFAULT 'active',
    rotated_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS access_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_code TEXT UNIQUE NOT NULL,
    capability TEXT NOT NULL,
    action TEXT NOT NULL,
    minimum_role_code TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
