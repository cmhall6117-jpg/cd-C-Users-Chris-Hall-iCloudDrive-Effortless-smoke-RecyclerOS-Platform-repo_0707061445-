class AutomationRun {
  final String automationRunId;
  final String runCode;
  final String automationDefinitionId;
  final String organizationId;
  final String workspaceId;
  final String status;
  final bool isTestRun;
  final DateTime startedAt;
  final DateTime? completedAt;
  final String? errorSummary;

  const AutomationRun({
    required this.automationRunId,
    required this.runCode,
    required this.automationDefinitionId,
    required this.organizationId,
    required this.workspaceId,
    required this.status,
    required this.isTestRun,
    required this.startedAt,
    this.completedAt,
    this.errorSummary,
  });
}
