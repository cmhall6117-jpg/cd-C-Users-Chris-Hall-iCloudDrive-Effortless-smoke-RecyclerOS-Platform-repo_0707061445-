# First Build Failure Triage

Expected issues:
- Missing imports
- Duplicate classes/enums
- Router registration conflicts
- SQLite duplicate-column migration errors
- Missing package references
- FastAPI schema import paths

Triage order:
1. Backend starts.
2. PostgreSQL migrations apply.
3. Flutter analyze passes.
4. Flutter launches to Mission Control.
5. API smoke test responds.
