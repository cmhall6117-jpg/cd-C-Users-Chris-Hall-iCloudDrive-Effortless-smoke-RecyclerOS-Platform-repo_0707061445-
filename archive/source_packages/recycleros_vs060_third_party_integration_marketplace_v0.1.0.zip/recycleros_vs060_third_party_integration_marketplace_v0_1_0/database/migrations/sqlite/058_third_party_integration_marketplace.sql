CREATE TABLE IF NOT EXISTS integration_listings (
    id TEXT PRIMARY KEY,
    integration_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    vendor TEXT NOT NULL,
    category TEXT NOT NULL,
    version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'available',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS installed_integrations (
    id TEXT PRIMARY KEY,
    integration_listing_id TEXT NOT NULL,
    organization_id TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'installed',
    credential_reference_id TEXT,
    installed_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS integration_sync_jobs (
    id TEXT PRIMARY KEY,
    installed_integration_id TEXT NOT NULL,
    direction TEXT NOT NULL DEFAULT 'bidirectional',
    status TEXT NOT NULL DEFAULT 'started',
    processed_count INTEGER NOT NULL DEFAULT 0,
    error_count INTEGER NOT NULL DEFAULT 0,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    error_summary TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
