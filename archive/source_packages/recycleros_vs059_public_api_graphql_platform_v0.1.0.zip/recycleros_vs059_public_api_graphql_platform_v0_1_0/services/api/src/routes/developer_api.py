from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel, HttpUrl

router = APIRouter()

class DeveloperApplicationCreate(BaseModel):
    name: str
    owner_account_id: str
    environment_code: str = 'sandbox'

class WebhookSubscriptionCreate(BaseModel):
    developer_application_id: str
    event_type: str
    callback_url: HttpUrl

@router.post('/applications')
def create_application(payload: DeveloperApplicationCreate):
    return {
        'developer_application_id': 'APP-DEMO-000001',
        'application_code': 'APP-000001',
        'name': payload.name,
        'owner_account_id': payload.owner_account_id,
        'environment_code': payload.environment_code,
        'status': 'active',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'api_platform.application_created'
    }

@router.post('/webhooks')
def create_webhook(payload: WebhookSubscriptionCreate):
    return {
        'webhook_subscription_id': 'WHK-DEMO-000001',
        'webhook_code': 'WHK-000001',
        'developer_application_id': payload.developer_application_id,
        'event_type': payload.event_type,
        'callback_url': str(payload.callback_url),
        'status': 'active',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'api_platform.webhook_created'
    }
