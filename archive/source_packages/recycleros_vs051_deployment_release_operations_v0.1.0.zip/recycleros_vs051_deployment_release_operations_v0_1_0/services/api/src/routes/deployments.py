from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class DeploymentRunCreate(BaseModel):
    release_version: str
    environment_code: str

@router.post('/runs')
def create_deployment_run(payload: DeploymentRunCreate):
    return {
        'deployment_run_id': 'DEP-DEMO-000001',
        'deployment_code': 'DEP-000001',
        'release_version': payload.release_version,
        'environment_code': payload.environment_code,
        'status': 'started',
        'started_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'deployment.started'
    }
