# VS-013 Financial Intelligence Test Cases

TC-001 Create Financial Transaction: transaction is saved and financial.transaction_created event is recorded.
TC-002 Link Related Object: transaction links to vehicle, inventory item, sales order, payment, or scrap disposition.
TC-003 Vehicle Profit Snapshot: endpoint returns revenue, costs, gross profit, and net profit.
TC-004 Offline Financial Record: financial transaction saves locally with sync_status pending.
TC-005 GAAP Disclaimer: finance dashboard displays review/accounting disclaimer.
