from dataclasses import dataclass
from fastapi import HTTPException

@dataclass(frozen=True)
class AdminContext:
    user_id: str
    scope_type: str
    organization_id: str | None
    workspace_id: str | None
    permissions: set[str]

def require_admin_permission(
    context: AdminContext,
    permission: str,
    target_organization_id: str | None = None,
) -> None:
    if permission not in context.permissions:
        raise HTTPException(status_code=403, detail='Administrative permission denied.')

    if context.scope_type == 'organization_admin':
        if target_organization_id != context.organization_id:
            raise HTTPException(status_code=403, detail='Cross-organization administration denied.')
