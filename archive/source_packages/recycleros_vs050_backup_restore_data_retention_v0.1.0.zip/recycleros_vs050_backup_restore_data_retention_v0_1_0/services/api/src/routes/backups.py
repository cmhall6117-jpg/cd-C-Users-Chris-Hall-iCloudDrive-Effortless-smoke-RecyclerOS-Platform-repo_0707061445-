from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class BackupJobCreate(BaseModel):
    backup_type: str = 'manual'
    record_count: int = 0
    file_reference: str | None = None

@router.post('/jobs')
def create_backup_job(payload: BackupJobCreate):
    return {
        'backup_job_id': 'BKP-DEMO-000001',
        'backup_code': 'BKP-000001',
        'backup_type': payload.backup_type,
        'status': 'created',
        'record_count': payload.record_count,
        'file_reference': payload.file_reference,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'backup.started'
    }
