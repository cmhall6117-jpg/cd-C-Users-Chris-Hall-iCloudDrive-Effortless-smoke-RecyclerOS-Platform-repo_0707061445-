class PartsResearchEventTypes {
  static const partResearchCreated = 'parts_research.created';
  static const compatibilityRecordCreated = 'parts_research.compatibility_created';
  static const highValuePartIdentified = 'parts_research.high_value_identified';
  static const vinFeatureResearchCompleted = 'parts_research.vin_feature_completed';
}
