CREATE TABLE IF NOT EXISTS scrap_dispositions (
    id TEXT PRIMARY KEY,
    scrap_disposition_code TEXT UNIQUE NOT NULL,
    vehicle_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    estimated_scrap_value REAL NOT NULL DEFAULT 0,
    actual_scrap_value REAL NOT NULL DEFAULT 0,
    hauling_cost REAL NOT NULL DEFAULT 0,
    net_scrap_value REAL NOT NULL DEFAULT 0,
    notes TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS scrap_material_lines (
    id TEXT PRIMARY KEY,
    scrap_disposition_id TEXT NOT NULL,
    material_type TEXT NOT NULL,
    weight REAL NOT NULL DEFAULT 0,
    price_per_unit REAL NOT NULL DEFAULT 0,
    total_value REAL NOT NULL DEFAULT 0,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
