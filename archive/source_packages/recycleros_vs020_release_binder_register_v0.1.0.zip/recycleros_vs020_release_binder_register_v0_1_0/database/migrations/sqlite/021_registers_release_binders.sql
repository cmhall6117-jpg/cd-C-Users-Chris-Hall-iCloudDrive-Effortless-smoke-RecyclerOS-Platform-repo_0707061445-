CREATE TABLE IF NOT EXISTS implementation_package_register (
    id TEXT PRIMARY KEY,
    package_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    version TEXT NOT NULL,
    status TEXT NOT NULL,
    recommended_save_location TEXT NOT NULL,
    generated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS release_binders (
    id TEXT PRIMARY KEY,
    release_binder_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    sprint_name TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
