# VS-055 Productization, Licensing & Subscription Test Cases

TC-001 Create Plan: licensing.subscription_plan_created event is recorded.
TC-002 License Record: license links account and subscription plan.
TC-003 Feature Entitlement: plan feature access can be stored.
TC-004 License Status: trial, active, past_due, suspended, cancelled, and expired statuses are supported.
TC-005 Offline Metadata: licensing metadata saves locally with sync_status pending.
