CREATE TABLE IF NOT EXISTS return_authorizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    return_code TEXT UNIQUE NOT NULL,
    sales_order_id UUID REFERENCES sales_orders(id),
    inventory_item_id UUID REFERENCES inventory_items(id),
    reason_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'authorized',
    refund_amount NUMERIC(12,2),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS warranty_claims (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    claim_code TEXT UNIQUE NOT NULL,
    return_authorization_id UUID REFERENCES return_authorizations(id),
    status TEXT NOT NULL DEFAULT 'open',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
