# VS-035 Parts Research & Compatibility Intelligence

Capabilities:
- Parts Research Engine
- Compatibility / Fitment Intelligence
- VIN Feature Research
- High-Value Part Identification
- Procurement Decision Support

Acceptance Criteria:
1. Part research record can link to vehicle, inventory item, or opportunity.
2. Compatibility record can store donor vehicle, compatible vehicle range, and confidence score.
3. High-value part candidate can store estimated resale value and programming requirement.
4. VIN feature research scaffold exists.
5. Offline research records save with sync status.
