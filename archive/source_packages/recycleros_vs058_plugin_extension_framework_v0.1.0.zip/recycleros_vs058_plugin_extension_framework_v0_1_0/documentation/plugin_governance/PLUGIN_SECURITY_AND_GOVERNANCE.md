# Plugin Security and Governance

1. A plugin must pass manifest validation before installation.
2. Dependencies must be resolved before migrations or activation.
3. Requested permissions must be explicitly approved.
4. Plugins receive only approved capability/action scopes.
5. Secret values are never included in plugin manifests.
6. Plugin routes must be namespace-scoped.
7. Plugin database migrations must be logged.
8. Plugin upgrades must record from-version and to-version.
9. Enterprise organizations may require administrator approval before enablement.
10. Disabled plugins must not execute background jobs, event handlers, or API routes.
11. Uninstall must preserve audit history.
12. Rollback must validate database compatibility before execution.
