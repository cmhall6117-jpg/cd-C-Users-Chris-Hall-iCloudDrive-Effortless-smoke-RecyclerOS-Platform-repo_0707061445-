import 'package:flutter/material.dart';

class DecisionRecommendationsScreen extends StatelessWidget {
  const DecisionRecommendationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final recommendations = [
      ('Procurement', 'Part-out intent recommended', 'Confidence: 81%'),
      ('Inventory', 'Discount aging inventory by 10%', 'Confidence: 74%'),
      ('Compliance', 'Create disposal record before closeout', 'Confidence: 92%'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Decision Recommendations')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Explainable Recommendations', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Recommendations are advisory until approved by an authorized user.'),
          const SizedBox(height: 16),
          for (final rec in recommendations)
            Card(
              child: ListTile(
                leading: const Icon(Icons.psychology),
                title: Text('${rec.$1}: ${rec.$2}'),
                subtitle: Text(rec.$3),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
