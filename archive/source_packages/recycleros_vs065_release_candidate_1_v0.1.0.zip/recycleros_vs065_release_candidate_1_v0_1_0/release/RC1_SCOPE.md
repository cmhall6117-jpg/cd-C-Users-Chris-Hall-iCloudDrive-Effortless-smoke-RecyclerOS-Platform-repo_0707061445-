# RC1 Scope

## Included

- Foundation repository structure
- Mission Control
- Opportunity Discovery
- Vehicle Digital Twin
- Procurement
- Pick List and Focus Point
- Inventory Intake
- Listing, shipping, sales, returns, and risk scaffolds
- AI Decision Engine
- Workflow Automation
- Enterprise Identity
- Multi-Tenant Workspaces
- Plugin Framework
- Public API
- Integrations
- Analytics
- AI Automation Studio
- Offline Synchronization v2
- Enterprise Administration
- Security, CI/CD, observability, deployment, backup, and licensing

## Excluded From Automatic Approval

The following require implementation evidence:

- Production marketplace credentials
- Payment processing
- Live carrier pricing
- Live SSO provider configuration
- Production AI provider credentials
- Production deployment
- Legal/compliance certification
- Penetration testing
- Disaster-recovery validation
