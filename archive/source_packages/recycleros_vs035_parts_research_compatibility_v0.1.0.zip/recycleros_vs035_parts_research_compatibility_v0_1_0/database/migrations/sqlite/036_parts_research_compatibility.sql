CREATE TABLE IF NOT EXISTS part_research_records (
    id TEXT PRIMARY KEY,
    research_code TEXT UNIQUE NOT NULL,
    part_name TEXT NOT NULL,
    related_vehicle_id TEXT,
    related_inventory_item_id TEXT,
    estimated_resale_value REAL,
    programming_required INTEGER NOT NULL DEFAULT 0,
    confidence_score REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS compatibility_records (
    id TEXT PRIMARY KEY,
    part_name TEXT NOT NULL,
    donor_vehicle_description TEXT NOT NULL,
    compatible_vehicle_range TEXT NOT NULL,
    compatibility_notes TEXT,
    confidence_score REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
