CREATE TABLE IF NOT EXISTS packaging_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    length_inches NUMERIC(10,2) NOT NULL,
    width_inches NUMERIC(10,2) NOT NULL,
    height_inches NUMERIC(10,2) NOT NULL,
    weight_pounds NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS shipping_estimates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    estimate_code TEXT UNIQUE NOT NULL,
    carrier TEXT NOT NULL,
    service_level TEXT NOT NULL,
    estimated_cost NUMERIC(12,2) NOT NULL,
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
