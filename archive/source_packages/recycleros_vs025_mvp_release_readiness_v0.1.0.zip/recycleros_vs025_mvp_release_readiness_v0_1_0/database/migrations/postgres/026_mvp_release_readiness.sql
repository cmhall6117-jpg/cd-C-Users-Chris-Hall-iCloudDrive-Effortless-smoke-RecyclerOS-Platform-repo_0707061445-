CREATE TABLE IF NOT EXISTS mvp_release_readiness_reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    review_code TEXT UNIQUE NOT NULL,
    release_binder_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    design_completion_percent NUMERIC(5,2),
    scaffold_completion_percent NUMERIC(5,2),
    working_product_completion_percent NUMERIC(5,2),
    reviewed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
