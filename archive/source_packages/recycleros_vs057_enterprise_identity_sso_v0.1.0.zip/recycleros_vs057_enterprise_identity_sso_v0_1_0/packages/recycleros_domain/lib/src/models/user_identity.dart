class UserIdentity {
  final String userIdentityId;
  final String userId;
  final String identityProviderId;
  final String providerSubject;
  final String email;
  final String status;
  final DateTime linkedAt;

  const UserIdentity({
    required this.userIdentityId,
    required this.userId,
    required this.identityProviderId,
    required this.providerSubject,
    required this.email,
    required this.status,
    required this.linkedAt,
  });
}
