class IntegrationSyncJob {
  final String integrationSyncJobId;
  final String installedIntegrationId;
  final String direction;
  final String status;
  final int processedCount;
  final int errorCount;
  final DateTime startedAt;
  final DateTime? completedAt;

  const IntegrationSyncJob({
    required this.integrationSyncJobId,
    required this.installedIntegrationId,
    required this.direction,
    required this.status,
    required this.processedCount,
    required this.errorCount,
    required this.startedAt,
    this.completedAt,
  });
}
