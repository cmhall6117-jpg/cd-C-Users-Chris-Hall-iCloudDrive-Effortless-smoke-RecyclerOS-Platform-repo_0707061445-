class PromotionalContentDraft {
  final String contentDraftId;
  final String contentCode;
  final String? promotionCampaignId;
  final String channel;
  final String title;
  final String body;
  final String status;
  final DateTime createdAt;

  const PromotionalContentDraft({
    required this.contentDraftId,
    required this.contentCode,
    this.promotionCampaignId,
    required this.channel,
    required this.title,
    required this.body,
    required this.status,
    required this.createdAt,
  });
}
