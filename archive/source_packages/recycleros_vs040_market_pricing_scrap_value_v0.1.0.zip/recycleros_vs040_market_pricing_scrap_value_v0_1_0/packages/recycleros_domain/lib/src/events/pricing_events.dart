class PricingEventTypes {
  static const marketPriceSnapshotCreated = 'pricing.market_snapshot_created';
  static const scrapMetalValueRecorded = 'pricing.scrap_metal_value_recorded';
  static const pricingRecommendationCreated = 'pricing.recommendation_created';
  static const pricingRefreshRequested = 'pricing.refresh_requested';
}
