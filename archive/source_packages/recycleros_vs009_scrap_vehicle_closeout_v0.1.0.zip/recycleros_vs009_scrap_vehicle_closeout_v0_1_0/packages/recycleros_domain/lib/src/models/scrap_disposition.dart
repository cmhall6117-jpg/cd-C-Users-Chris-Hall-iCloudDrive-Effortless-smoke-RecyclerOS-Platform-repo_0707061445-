class ScrapDisposition {
  final String scrapDispositionId;
  final String scrapDispositionCode;
  final String vehicleId;
  final String status;
  final double estimatedScrapValue;
  final double actualScrapValue;
  final double haulingCost;
  final double netScrapValue;
  final DateTime createdAt;
  final DateTime? completedAt;

  const ScrapDisposition({
    required this.scrapDispositionId,
    required this.scrapDispositionCode,
    required this.vehicleId,
    required this.status,
    required this.estimatedScrapValue,
    required this.actualScrapValue,
    required this.haulingCost,
    required this.netScrapValue,
    required this.createdAt,
    this.completedAt,
  });
}
