# Migration Validation Checklist

## PostgreSQL
- [ ] Apply migrations 001 through 024 in sequence.
- [ ] Verify core tables exist.
- [ ] Verify indexes exist.
- [ ] Verify foreign keys compile.
- [ ] Verify UUID extension exists.

## SQLite
- [ ] Apply initial schema.
- [ ] Apply guarded ALTER TABLE changes.
- [ ] Verify local tables exist.
- [ ] Verify sync_status columns exist where needed.
