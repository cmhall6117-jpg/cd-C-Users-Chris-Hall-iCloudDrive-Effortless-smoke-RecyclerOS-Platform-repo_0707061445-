class DecisionEventTypes {
  static const ruleEvaluated = 'rule.evaluated';
  static const recommendationCreated = 'recommendation.created';
  static const recommendationApproved = 'recommendation.approved';
  static const recommendationRejected = 'recommendation.rejected';
  static const recommendationOutcomeRecorded = 'recommendation.outcome_recorded';
}
