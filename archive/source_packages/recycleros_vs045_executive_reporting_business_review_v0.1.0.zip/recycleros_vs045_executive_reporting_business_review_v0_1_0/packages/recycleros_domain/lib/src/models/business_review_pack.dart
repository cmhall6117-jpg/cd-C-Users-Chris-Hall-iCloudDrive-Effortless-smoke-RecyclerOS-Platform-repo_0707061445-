class BusinessReviewPack {
  final String businessReviewPackId;
  final String reviewCode;
  final String title;
  final String reportingPeriod;
  final String status;
  final DateTime createdAt;

  const BusinessReviewPack({
    required this.businessReviewPackId,
    required this.reviewCode,
    required this.title,
    required this.reportingPeriod,
    required this.status,
    required this.createdAt,
  });
}
