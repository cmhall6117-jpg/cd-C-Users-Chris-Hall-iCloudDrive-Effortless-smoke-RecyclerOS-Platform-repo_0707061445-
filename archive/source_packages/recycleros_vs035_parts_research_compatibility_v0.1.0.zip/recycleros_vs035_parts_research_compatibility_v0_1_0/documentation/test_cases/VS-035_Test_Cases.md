# VS-035 Parts Research & Compatibility Test Cases

TC-001 Create Part Research: parts_research.created event is recorded.
TC-002 Programming Required: research record stores programming requirement.
TC-003 Compatibility Record: compatible vehicle range and confidence score are stored.
TC-004 High Value Part: estimated resale value can be recorded.
TC-005 Offline Research: research records save locally with sync_status pending.
