# VS-034 Inventory Performance & Shelf-Life Test Cases

TC-001 Performance Snapshot: snapshot stores shelf life, quantity, sell-through, and return ratio.
TC-002 Stock Limit Policy: policy stores max on-hand quantity and target shelf life.
TC-003 Special Sale Recommendation: aging inventory triggers recommendation.
TC-004 Procurement Warning: over-limit stock warns against additional procurement.
TC-005 Offline Snapshot: performance records save locally with sync_status pending.
