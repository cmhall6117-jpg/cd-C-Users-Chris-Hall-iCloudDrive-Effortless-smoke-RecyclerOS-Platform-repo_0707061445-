import 'package:flutter/material.dart';

class ExecutiveReportingScreen extends StatelessWidget {
  const ExecutiveReportingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final sections = [
      ('KPI Summary', 'Mission Control snapshot and operational priorities'),
      ('Financial Summary', 'Revenue, costs, gross profit, and net profit'),
      ('Sales Forecast', 'Weighted pipeline and expected revenue'),
      ('Risk Summary', 'Open risk flags, approval holds, and shrink signals'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Executive Reporting')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Business Review Pack', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Generate executive summaries from KPI, finance, sales, risk, and operations data.'),
          const SizedBox(height: 16),
          for (final section in sections)
            Card(child: ListTile(leading: const Icon(Icons.summarize), title: Text(section.$1), subtitle: Text(section.$2))),
        ],
      ),
    );
  }
}
