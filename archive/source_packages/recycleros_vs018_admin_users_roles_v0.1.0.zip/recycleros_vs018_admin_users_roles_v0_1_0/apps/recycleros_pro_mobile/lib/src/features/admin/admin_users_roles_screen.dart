import 'package:flutter/material.dart';

class AdminUsersRolesScreen extends StatelessWidget {
  const AdminUsersRolesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final roles = [
      ('Owner / Admin', 'Full access'),
      ('Operations Manager', 'Procurement, harvest, inventory, reporting'),
      ('Technician', 'Pick List, Focus Point, inventory intake'),
      ('Sales', 'Inventory, customer, orders, fulfillment'),
      ('Finance', 'Finance dashboard and transaction review'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Administration')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Users & Role Permissions', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Card(
            child: ListTile(
              leading: Icon(Icons.security),
              title: Text('Access Control'),
              subtitle: Text('Permissions must be role-aware, approval-aware, and audit-ready.'),
            ),
          ),
          const SizedBox(height: 12),
          const Text('System Roles', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (final role in roles)
            Card(
              child: ListTile(
                leading: const Icon(Icons.badge),
                title: Text(role.$1),
                subtitle: Text(role.$2),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
