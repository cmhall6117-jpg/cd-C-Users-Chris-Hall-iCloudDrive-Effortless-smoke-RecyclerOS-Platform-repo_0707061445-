class PluginManifest {
  final String pluginId;
  final String name;
  final String version;
  final String vendor;
  final String apiVersion;
  final String description;
  final List<String> permissions;
  final List<String> dependencies;
  final List<String> routes;
  final List<String> eventSubscriptions;

  const PluginManifest({
    required this.pluginId,
    required this.name,
    required this.version,
    required this.vendor,
    required this.apiVersion,
    required this.description,
    required this.permissions,
    required this.dependencies,
    required this.routes,
    required this.eventSubscriptions,
  });
}
