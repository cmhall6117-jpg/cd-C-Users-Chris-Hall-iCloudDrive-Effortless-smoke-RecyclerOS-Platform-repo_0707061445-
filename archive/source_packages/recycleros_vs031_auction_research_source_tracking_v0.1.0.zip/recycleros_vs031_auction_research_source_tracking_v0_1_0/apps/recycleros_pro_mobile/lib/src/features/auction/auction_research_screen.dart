import 'package:flutter/material.dart';

class AuctionResearchScreen extends StatelessWidget {
  const AuctionResearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final sources = [
      ('Public Salvage Auction', 'nonDealerPublic', 'Watchlist: 4'),
      ('Dealer Auction Network', 'dealerOnly', 'Watchlist: 2'),
      ('Local Tow Auction', 'nonDealerPublic', 'Watchlist: 1'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Auction Research')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Auction Sources', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Track dealer/non-dealer sources, watchlists, fees, and procurement opportunities.'),
          const SizedBox(height: 16),
          for (final source in sources)
            Card(
              child: ListTile(
                leading: const Icon(Icons.gavel),
                title: Text(source.$1),
                subtitle: Text('${source.$2} • ${source.$3}'),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
