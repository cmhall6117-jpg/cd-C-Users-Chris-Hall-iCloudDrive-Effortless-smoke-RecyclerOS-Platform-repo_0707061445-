# VS-028 Document & Media Capture

Capabilities:
- Document Engine
- Media Capture
- Vehicle / Part Photo Support
- Compliance Attachment Support
- Audit Evidence Support

Events:
- Media Captured
- Document Uploaded
- Attachment Linked
- Attachment Removed

Objects:
- Media Asset
- Document Asset
- Attachment Link
- Vehicle
- Inventory Item
- Compliance Record
- Business Event

Acceptance Criteria:
1. User can scaffold photo/media capture from mobile.
2. Media can link to a related business object.
3. Document metadata can be stored.
4. Attachment records support offline sync.
5. Compliance and audit records can reference attachments.
