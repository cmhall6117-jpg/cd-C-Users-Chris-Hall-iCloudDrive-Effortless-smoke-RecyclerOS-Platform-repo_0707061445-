import 'package:flutter/material.dart';

class ScrapCloseoutScreen extends StatefulWidget {
  const ScrapCloseoutScreen({super.key});

  @override
  State<ScrapCloseoutScreen> createState() => _ScrapCloseoutScreenState();
}

class _ScrapCloseoutScreenState extends State<ScrapCloseoutScreen> {
  final scrapValueController = TextEditingController();
  final haulingCostController = TextEditingController();

  @override
  void dispose() {
    scrapValueController.dispose();
    haulingCostController.dispose();
    super.dispose();
  }

  void completeCloseout() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Vehicle closeout saved locally. Sync pending.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final materials = ['Steel', 'Aluminum', 'Copper', 'Battery', 'Catalytic Converter'];

    return Scaffold(
      appBar: AppBar(title: const Text('Scrap & Vehicle Closeout')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: completeCloseout,
        icon: const Icon(Icons.recycling),
        label: const Text('Closeout'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Vehicle Closeout', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Vehicle: 2019 Ford F-150'),
          const Text('Status: Scrap Candidate'),
          const SizedBox(height: 16),
          TextField(controller: scrapValueController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Actual Scrap Value', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: haulingCostController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Hauling Cost', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          const Text('Material Lines', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (final material in materials)
            Card(child: ListTile(leading: const Icon(Icons.scale), title: Text(material), subtitle: const Text('Weight and local value entry pending'))),
          const Card(child: ListTile(leading: Icon(Icons.verified), title: Text('Economic Completion'), subtitle: Text('Close vehicle when remaining recoverable value is below threshold.')))
        ],
      ),
    );
  }
}
