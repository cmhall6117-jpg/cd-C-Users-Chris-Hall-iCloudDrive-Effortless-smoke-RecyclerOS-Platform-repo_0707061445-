ALTER TABLE customers ADD COLUMN customer_lifetime_value REAL NOT NULL DEFAULT 0;
ALTER TABLE customers ADD COLUMN last_purchase_at TEXT;
ALTER TABLE customers ADD COLUMN status TEXT NOT NULL DEFAULT 'active';

CREATE TABLE IF NOT EXISTS customer_preferences (
    id TEXT PRIMARY KEY,
    customer_id TEXT NOT NULL,
    preference_type TEXT NOT NULL,
    preference_value TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS customer_inventory_matches (
    id TEXT PRIMARY KEY,
    customer_id TEXT NOT NULL,
    inventory_item_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    confidence_score REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
