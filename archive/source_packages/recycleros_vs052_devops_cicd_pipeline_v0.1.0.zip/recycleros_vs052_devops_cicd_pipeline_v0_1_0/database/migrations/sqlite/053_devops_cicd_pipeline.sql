CREATE TABLE IF NOT EXISTS pipeline_runs (
    id TEXT PRIMARY KEY,
    run_code TEXT UNIQUE NOT NULL,
    branch_name TEXT NOT NULL,
    commit_sha TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'started',
    summary TEXT,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS release_gate_checks (
    id TEXT PRIMARY KEY,
    gate_code TEXT UNIQUE NOT NULL,
    pipeline_run_id TEXT NOT NULL,
    gate_name TEXT NOT NULL,
    status TEXT NOT NULL,
    message TEXT,
    checked_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
