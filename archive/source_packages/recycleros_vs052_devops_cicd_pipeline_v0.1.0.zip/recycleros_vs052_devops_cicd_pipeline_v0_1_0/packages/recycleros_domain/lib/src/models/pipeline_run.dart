class PipelineRun {
  final String pipelineRunId;
  final String runCode;
  final String branchName;
  final String commitSha;
  final String status;
  final String summary;
  final DateTime startedAt;
  final DateTime? completedAt;

  const PipelineRun({
    required this.pipelineRunId,
    required this.runCode,
    required this.branchName,
    required this.commitSha,
    required this.status,
    required this.summary,
    required this.startedAt,
    this.completedAt,
  });
}
