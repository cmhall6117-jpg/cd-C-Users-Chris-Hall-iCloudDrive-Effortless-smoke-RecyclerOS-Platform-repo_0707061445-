# VS-060 Third-Party Integration Marketplace Test Cases

TC-001 Marketplace Listing: available connectors are returned.
TC-002 Install Integration: integration.installed event is recorded.
TC-003 Workspace Link: installation links organization and workspace.
TC-004 Credential Reference: only credential metadata/reference is stored.
TC-005 Start Sync: integration.sync_started event is recorded.
TC-006 Sync Error Tracking: processed and error counts can be stored.
TC-007 Offline Metadata: integration records save locally with sync_status pending.
