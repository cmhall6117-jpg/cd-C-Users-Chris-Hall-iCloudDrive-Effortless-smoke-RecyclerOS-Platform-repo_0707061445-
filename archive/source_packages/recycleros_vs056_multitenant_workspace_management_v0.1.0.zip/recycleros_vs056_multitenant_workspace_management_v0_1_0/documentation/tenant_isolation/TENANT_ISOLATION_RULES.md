# Tenant Isolation Rules

1. Every tenant-owned operational table must include organization_id and workspace_id.
2. API requests must resolve tenant context before querying tenant-owned data.
3. Queries must filter by organization_id and workspace_id.
4. Background jobs must carry tenant context.
5. Offline records must retain organization_id and workspace_id through synchronization.
6. Cache keys must include tenant identifiers.
7. Export, reporting, and search operations must remain tenant-scoped.
8. Cross-tenant access attempts must create tenant.isolation_violation_detected events.
9. Platform administrators may access multiple tenants only through explicit administrative privileges.
10. Tenant identifiers must never be inferred from user-supplied object IDs alone.
