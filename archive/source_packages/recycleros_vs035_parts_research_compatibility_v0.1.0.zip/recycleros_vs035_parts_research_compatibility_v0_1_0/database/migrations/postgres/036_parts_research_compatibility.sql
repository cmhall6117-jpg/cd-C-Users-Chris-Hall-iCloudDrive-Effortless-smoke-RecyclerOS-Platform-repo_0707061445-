CREATE TABLE IF NOT EXISTS part_research_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    research_code TEXT UNIQUE NOT NULL,
    part_name TEXT NOT NULL,
    related_vehicle_id UUID REFERENCES vehicles(id),
    related_inventory_item_id UUID REFERENCES inventory_items(id),
    estimated_resale_value NUMERIC(12,2),
    programming_required BOOLEAN NOT NULL DEFAULT false,
    confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compatibility_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    part_name TEXT NOT NULL,
    donor_vehicle_description TEXT NOT NULL,
    compatible_vehicle_range TEXT NOT NULL,
    compatibility_notes TEXT,
    confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
