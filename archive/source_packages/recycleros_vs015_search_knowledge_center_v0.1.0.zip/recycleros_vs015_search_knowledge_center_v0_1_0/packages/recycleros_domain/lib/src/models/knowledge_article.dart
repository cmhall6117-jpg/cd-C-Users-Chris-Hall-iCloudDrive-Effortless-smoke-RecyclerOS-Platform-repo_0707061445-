class KnowledgeArticle {
  final String knowledgeArticleId;
  final String articleCode;
  final String title;
  final String category;
  final String body;
  final String status;
  final DateTime createdAt;
  final DateTime updatedAt;

  const KnowledgeArticle({
    required this.knowledgeArticleId,
    required this.articleCode,
    required this.title,
    required this.category,
    required this.body,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });
}
