class SearchQueryRecord {
  final String searchQueryId;
  final String queryText;
  final String? userId;
  final DateTime searchedAt;
  final int resultCount;

  const SearchQueryRecord({
    required this.searchQueryId,
    required this.queryText,
    this.userId,
    required this.searchedAt,
    required this.resultCount,
  });
}
