CREATE TABLE IF NOT EXISTS scrap_dispositions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scrap_disposition_code TEXT UNIQUE NOT NULL,
    vehicle_id UUID REFERENCES vehicles(id),
    status TEXT NOT NULL DEFAULT 'draft',
    estimated_scrap_value NUMERIC(12,2) NOT NULL DEFAULT 0,
    actual_scrap_value NUMERIC(12,2) NOT NULL DEFAULT 0,
    hauling_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
    net_scrap_value NUMERIC(12,2) NOT NULL DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS scrap_material_lines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scrap_disposition_id UUID REFERENCES scrap_dispositions(id),
    material_type TEXT NOT NULL,
    weight NUMERIC(12,2) NOT NULL DEFAULT 0,
    price_per_unit NUMERIC(12,4) NOT NULL DEFAULT 0,
    total_value NUMERIC(12,2) NOT NULL DEFAULT 0
);
