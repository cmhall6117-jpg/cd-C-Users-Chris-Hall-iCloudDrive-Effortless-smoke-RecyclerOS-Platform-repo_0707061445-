CREATE TABLE IF NOT EXISTS promotion_campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    channel TEXT NOT NULL DEFAULT 'manual',
    status TEXT NOT NULL DEFAULT 'draft',
    target_discount_percent NUMERIC(5,2),
    projected_revenue_impact NUMERIC(12,2),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    launched_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS promotion_campaign_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    promotion_campaign_id UUID REFERENCES promotion_campaigns(id),
    inventory_item_id UUID REFERENCES inventory_items(id)
);

CREATE TABLE IF NOT EXISTS promotion_recommendations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recommendation_code TEXT UNIQUE NOT NULL,
    inventory_item_id UUID REFERENCES inventory_items(id),
    reason TEXT NOT NULL,
    suggested_action TEXT NOT NULL,
    confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
