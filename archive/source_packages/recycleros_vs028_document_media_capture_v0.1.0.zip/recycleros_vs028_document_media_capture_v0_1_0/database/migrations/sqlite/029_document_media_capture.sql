CREATE TABLE IF NOT EXISTS media_assets (
    id TEXT PRIMARY KEY,
    media_code TEXT UNIQUE NOT NULL,
    media_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    local_path TEXT,
    remote_url TEXT,
    related_object_type TEXT,
    related_object_id TEXT,
    captured_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE INDEX IF NOT EXISTS idx_media_assets_related_object ON media_assets(related_object_type, related_object_id);
