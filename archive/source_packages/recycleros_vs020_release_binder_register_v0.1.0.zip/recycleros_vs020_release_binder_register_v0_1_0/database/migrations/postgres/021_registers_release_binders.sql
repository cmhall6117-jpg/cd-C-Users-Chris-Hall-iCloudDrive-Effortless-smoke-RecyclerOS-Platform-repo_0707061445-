CREATE TABLE IF NOT EXISTS implementation_package_register (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    package_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    version TEXT NOT NULL,
    status TEXT NOT NULL,
    recommended_save_location TEXT NOT NULL,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS release_binders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    release_binder_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    sprint_name TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
