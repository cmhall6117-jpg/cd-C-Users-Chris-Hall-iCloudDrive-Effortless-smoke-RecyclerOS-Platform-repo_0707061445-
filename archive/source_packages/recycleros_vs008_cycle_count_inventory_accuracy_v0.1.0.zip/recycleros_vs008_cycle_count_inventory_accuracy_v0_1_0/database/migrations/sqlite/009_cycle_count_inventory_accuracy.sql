CREATE TABLE IF NOT EXISTS cycle_count_sessions (
    id TEXT PRIMARY KEY,
    cycle_count_code TEXT UNIQUE NOT NULL,
    storage_location_id TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    started_at TEXT NOT NULL,
    completed_at TEXT,
    performed_by TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS cycle_count_lines (
    id TEXT PRIMARY KEY,
    cycle_count_session_id TEXT NOT NULL,
    inventory_item_id TEXT NOT NULL,
    expected_quantity INTEGER NOT NULL DEFAULT 0,
    counted_quantity INTEGER NOT NULL DEFAULT 0,
    variance INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE INDEX IF NOT EXISTS idx_cycle_count_sessions_status ON cycle_count_sessions(status);
CREATE INDEX IF NOT EXISTS idx_cycle_count_lines_inventory_item ON cycle_count_lines(inventory_item_id);
