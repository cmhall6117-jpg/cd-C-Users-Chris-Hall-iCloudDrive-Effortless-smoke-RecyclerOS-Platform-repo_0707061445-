CREATE TABLE IF NOT EXISTS orchestrator_actions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'informational',
    priority_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_orchestrator_actions_priority ON orchestrator_actions(priority, priority_score);
