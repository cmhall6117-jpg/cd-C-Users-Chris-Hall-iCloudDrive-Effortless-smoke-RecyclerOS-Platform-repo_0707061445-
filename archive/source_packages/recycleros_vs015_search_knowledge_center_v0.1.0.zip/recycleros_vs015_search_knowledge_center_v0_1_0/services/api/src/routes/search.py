from datetime import datetime, timezone
from fastapi import APIRouter

router = APIRouter()

@router.get('')
def global_search(q: str):
    return {
        'query': q,
        'searched_at': datetime.now(timezone.utc).isoformat(),
        'result_count': 4,
        'items': [
            {'type': 'vehicle', 'id': 'VEH-DEMO-000001', 'title': '2019 Ford F-150'},
            {'type': 'inventory', 'id': 'INV-DEMO-000001', 'title': 'ECM / PCM'},
            {'type': 'customer', 'id': 'CUS-DEMO-000001', 'title': 'Demo Repair Shop'},
            {'type': 'knowledge', 'id': 'KNW-DEMO-000001', 'title': 'Focus Point Harvest Procedure'}
        ],
        'event_created': 'search.performed'
    }
