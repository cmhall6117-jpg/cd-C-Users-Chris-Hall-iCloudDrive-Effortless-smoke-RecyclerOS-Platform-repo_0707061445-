from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class ReturnAuthorizationCreate(BaseModel):
    sales_order_id: str
    inventory_item_id: str
    reason_code: str
    refund_amount: float | None = None

@router.post('/authorizations')
def create_return_authorization(payload: ReturnAuthorizationCreate):
    return {
        'return_authorization_id': 'RET-DEMO-000001',
        'return_code': 'RET-000001',
        'sales_order_id': payload.sales_order_id,
        'inventory_item_id': payload.inventory_item_id,
        'reason_code': payload.reason_code,
        'status': 'authorized',
        'refund_amount': payload.refund_amount,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'return.authorized'
    }
