class DocumentEventTypes {
  static const mediaCaptured = 'media.captured';
  static const documentUploaded = 'document.uploaded';
  static const attachmentLinked = 'attachment.linked';
  static const attachmentRemoved = 'attachment.removed';
}
