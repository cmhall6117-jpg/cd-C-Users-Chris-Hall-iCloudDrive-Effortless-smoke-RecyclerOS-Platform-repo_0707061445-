class MediaAsset {
  final String mediaAssetId;
  final String mediaCode;
  final String mediaType;
  final String fileName;
  final String? localPath;
  final String? remoteUrl;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime capturedAt;

  const MediaAsset({
    required this.mediaAssetId,
    required this.mediaCode,
    required this.mediaType,
    required this.fileName,
    this.localPath,
    this.remoteUrl,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.capturedAt,
  });
}
