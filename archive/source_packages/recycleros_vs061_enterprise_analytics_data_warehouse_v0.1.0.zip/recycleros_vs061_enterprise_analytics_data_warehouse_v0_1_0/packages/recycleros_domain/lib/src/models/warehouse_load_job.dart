class WarehouseLoadJob {
  final String warehouseLoadJobId;
  final String loadCode;
  final String organizationId;
  final String workspaceId;
  final String sourceName;
  final String status;
  final int extractedRows;
  final int loadedRows;
  final int errorRows;
  final DateTime startedAt;
  final DateTime? completedAt;

  const WarehouseLoadJob({
    required this.warehouseLoadJobId,
    required this.loadCode,
    required this.organizationId,
    required this.workspaceId,
    required this.sourceName,
    required this.status,
    required this.extractedRows,
    required this.loadedRows,
    required this.errorRows,
    required this.startedAt,
    this.completedAt,
  });
}
