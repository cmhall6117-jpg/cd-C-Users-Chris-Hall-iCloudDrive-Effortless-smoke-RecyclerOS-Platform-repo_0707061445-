CREATE TABLE IF NOT EXISTS social_channel_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_code TEXT UNIQUE NOT NULL,
    channel TEXT NOT NULL,
    display_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS social_posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_code TEXT UNIQUE NOT NULL,
    channel TEXT NOT NULL,
    body TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    scheduled_at TIMESTAMPTZ,
    posted_at TIMESTAMPTZ
);
