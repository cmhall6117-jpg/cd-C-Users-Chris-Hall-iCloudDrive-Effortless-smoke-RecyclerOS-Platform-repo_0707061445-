CREATE TABLE IF NOT EXISTS packaging_profiles (
    id TEXT PRIMARY KEY,
    profile_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    length_inches REAL NOT NULL,
    width_inches REAL NOT NULL,
    height_inches REAL NOT NULL,
    weight_pounds REAL NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS shipping_estimates (
    id TEXT PRIMARY KEY,
    estimate_code TEXT UNIQUE NOT NULL,
    carrier TEXT NOT NULL,
    service_level TEXT NOT NULL,
    estimated_cost REAL NOT NULL,
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
