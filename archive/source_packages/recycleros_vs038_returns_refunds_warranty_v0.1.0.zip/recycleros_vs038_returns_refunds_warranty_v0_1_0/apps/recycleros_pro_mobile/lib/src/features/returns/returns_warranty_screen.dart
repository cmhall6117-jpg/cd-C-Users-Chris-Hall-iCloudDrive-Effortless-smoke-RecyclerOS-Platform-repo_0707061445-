import 'package:flutter/material.dart';

class ReturnsWarrantyScreen extends StatelessWidget {
  const ReturnsWarrantyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final returns = [
      ('RET-000001', 'ECM / PCM', 'Defective / no communication'),
      ('RET-000002', 'LED Headlight', 'Wrong fitment'),
      ('RET-000003', 'Transmission', 'Warranty review pending'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Returns & Warranty')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Return Authorizations', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Track returns, refunds, warranty claims, reason codes, and inventory impact.'),
          const SizedBox(height: 16),
          for (final item in returns)
            Card(child: ListTile(leading: const Icon(Icons.assignment_return), title: Text('${item.$1} • ${item.$2}'), subtitle: Text(item.$3))),
        ],
      ),
    );
  }
}
