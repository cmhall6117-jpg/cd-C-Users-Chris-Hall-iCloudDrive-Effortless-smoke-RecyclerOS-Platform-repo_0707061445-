class NotificationEventTypes {
  static const notificationCreated = 'notification.created';
  static const taskCreated = 'task.created';
  static const taskCompleted = 'task.completed';
  static const alertAcknowledged = 'alert.acknowledged';
}
