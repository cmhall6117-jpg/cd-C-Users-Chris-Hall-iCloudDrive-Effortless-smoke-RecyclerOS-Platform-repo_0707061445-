# RC1 Go / No-Go Checklist

## Repository
- [ ] Integrated monorepo exists.
- [ ] Original source ZIPs are archived.
- [ ] Duplicate models and routes are resolved.
- [ ] README and local setup instructions are accurate.

## Flutter
- [ ] `flutter pub get` passes.
- [ ] `flutter analyze` passes.
- [ ] `flutter test` passes.
- [ ] Application launches.
- [ ] Mission Control loads.
- [ ] Core navigation works.

## Backend
- [ ] Python dependencies install.
- [ ] Import check passes.
- [ ] FastAPI starts.
- [ ] Health endpoint responds.
- [ ] Core routers are registered.
- [ ] Tenant middleware is active.

## Database
- [ ] PostgreSQL starts.
- [ ] Migrations apply in order.
- [ ] Foreign-key references are valid.
- [ ] SQLite schema initializes.
- [ ] Offline sync tables initialize.
- [ ] Seed data loads without errors.

## Security
- [ ] Secrets are not committed.
- [ ] Password hashing is implemented.
- [ ] Token signing is configured securely.
- [ ] Tenant isolation tests pass.
- [ ] Role and permission checks pass.
- [ ] Security logging is enabled.

## Core Working Path
- [ ] Create opportunity.
- [ ] Create vehicle record.
- [ ] Create procurement record.
- [ ] Create pick list.
- [ ] Record harvested part.
- [ ] Intake inventory.
- [ ] Create listing draft.
- [ ] Record sale or lead.
- [ ] Generate business event.

## Quality
- [ ] Smoke tests pass.
- [ ] Critical defects = 0.
- [ ] High defects = 0 or formally waived.
- [ ] Performance baseline recorded.
- [ ] Backup/restore dry run completed.
- [ ] Product Owner acceptance recorded.

## Decision
- [ ] GO
- [ ] CONDITIONAL GO
- [ ] NO-GO
