import 'package:flutter/material.dart';

class WorkspaceSelectorScreen extends StatelessWidget {
  const WorkspaceSelectorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final workspaces = [
      ('Effortless Smoke, LLC', 'RecyclerOS Operations', 'active'),
      ('Demo Salvage Yard', 'Main Yard', 'active'),
      ('Demo Salvage Yard', 'Warehouse', 'active'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Select Workspace')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Organizations & Workspaces',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const Text(
            'Switch workspaces without signing out. Tenant boundaries remain enforced.',
          ),
          const SizedBox(height: 16),
          for (final workspace in workspaces)
            Card(
              child: ListTile(
                leading: const Icon(Icons.apartment),
                title: Text('${workspace.$1} • ${workspace.$2}'),
                subtitle: Text('Status: ${workspace.$3}'),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
