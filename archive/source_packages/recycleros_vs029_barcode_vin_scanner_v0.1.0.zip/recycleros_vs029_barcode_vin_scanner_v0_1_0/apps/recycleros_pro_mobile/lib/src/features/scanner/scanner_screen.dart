import 'package:flutter/material.dart';

class ScannerScreen extends StatelessWidget {
  const ScannerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scanTypes = ['VIN', 'Inventory Barcode', 'Storage Location', 'QR Code'];

    return Scaffold(
      appBar: AppBar(title: const Text('Scanner')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: null,
        icon: const Icon(Icons.qr_code_scanner),
        label: const Text('Open Camera'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Barcode / VIN Scanner', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Phone camera scanner integration scaffold.'),
          const SizedBox(height: 16),
          for (final type in scanTypes)
            Card(
              child: ListTile(
                leading: const Icon(Icons.qr_code),
                title: Text(type),
                subtitle: const Text('Scan workflow placeholder'),
              ),
            ),
        ],
      ),
    );
  }
}
