CREATE TABLE IF NOT EXISTS gps_locations (
    id TEXT PRIMARY KEY,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    accuracy_meters REAL,
    related_object_type TEXT,
    related_object_id TEXT,
    captured_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS yard_map_pins (
    id TEXT PRIMARY KEY,
    pin_code TEXT UNIQUE NOT NULL,
    pin_type TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    yard_name TEXT,
    yard_row TEXT,
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
