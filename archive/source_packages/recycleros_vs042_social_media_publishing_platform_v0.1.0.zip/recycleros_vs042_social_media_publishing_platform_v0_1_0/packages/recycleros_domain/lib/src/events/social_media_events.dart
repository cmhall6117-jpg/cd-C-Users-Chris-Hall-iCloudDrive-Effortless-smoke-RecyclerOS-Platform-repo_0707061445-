class SocialMediaEventTypes {
  static const socialPostDrafted = 'social.post_drafted';
  static const socialPostApproved = 'social.post_approved';
  static const socialPostScheduled = 'social.post_scheduled';
  static const socialPostPublished = 'social.post_published';
  static const socialPostFailed = 'social.post_failed';
}
