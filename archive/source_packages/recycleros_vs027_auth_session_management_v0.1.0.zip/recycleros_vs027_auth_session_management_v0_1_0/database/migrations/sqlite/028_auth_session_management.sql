CREATE TABLE IF NOT EXISTS auth_sessions (
    id TEXT PRIMARY KEY,
    session_code TEXT UNIQUE NOT NULL,
    user_id TEXT NOT NULL,
    device_id TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    expires_at TEXT,
    ended_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS login_attempts (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    result TEXT NOT NULL,
    failure_reason TEXT,
    device_id TEXT,
    attempted_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
