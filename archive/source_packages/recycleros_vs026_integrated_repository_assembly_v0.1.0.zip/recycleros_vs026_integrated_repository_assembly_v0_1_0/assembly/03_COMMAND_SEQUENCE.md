# Command Sequence

Backend:
python -m venv .venv
pip install -r requirements.txt
uvicorn src.main:app --reload

Database:
docker compose up -d
psql -U recycleros -d recycleros_dev -f database/migrations/postgres/001_initial_schema.sql

Flutter:
flutter pub get
flutter analyze
flutter test
flutter run
