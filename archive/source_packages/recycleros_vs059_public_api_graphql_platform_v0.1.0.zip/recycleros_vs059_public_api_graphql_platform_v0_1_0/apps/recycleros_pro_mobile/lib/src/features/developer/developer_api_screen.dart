import 'package:flutter/material.dart';

class DeveloperApiScreen extends StatelessWidget {
  const DeveloperApiScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('APP-000001', 'Sandbox Integration', 'active'),
      ('CLI-000001', 'Inventory Read Client', 'active'),
      ('WHK-000001', 'inventory.created webhook', 'active'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Developer API')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Public API & Webhooks', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          for (final item in items)
            Card(child: ListTile(leading: const Icon(Icons.api), title: Text('${item.$1} • ${item.$2}'), subtitle: Text('Status: ${item.$3}'))),
        ],
      ),
    );
  }
}
