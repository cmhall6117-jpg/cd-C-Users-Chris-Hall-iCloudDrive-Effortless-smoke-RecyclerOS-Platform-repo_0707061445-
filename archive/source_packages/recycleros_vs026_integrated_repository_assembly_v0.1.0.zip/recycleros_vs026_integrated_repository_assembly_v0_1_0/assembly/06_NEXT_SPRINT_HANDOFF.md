# Next Sprint Handoff

Working Path 001:
Mission Control → Opportunity Discovery → Create Opportunity → API Response → Business Event

Required:
- Register Flutter route.
- Wire form to API.
- Register FastAPI opportunity router.
- Store opportunity in PostgreSQL.
- Store offline record in SQLite.
- Add sync queue entry.
- Add smoke test.
