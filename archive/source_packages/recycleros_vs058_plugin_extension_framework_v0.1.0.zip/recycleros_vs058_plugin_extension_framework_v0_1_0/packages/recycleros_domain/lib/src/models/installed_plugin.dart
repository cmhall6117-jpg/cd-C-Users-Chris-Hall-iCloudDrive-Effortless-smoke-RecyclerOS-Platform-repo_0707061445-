class InstalledPlugin {
  final String installedPluginId;
  final String pluginId;
  final String organizationId;
  final String workspaceId;
  final String installedVersion;
  final String status;
  final DateTime installedAt;
  final DateTime? enabledAt;
  final DateTime? disabledAt;

  const InstalledPlugin({
    required this.installedPluginId,
    required this.pluginId,
    required this.organizationId,
    required this.workspaceId,
    required this.installedVersion,
    required this.status,
    required this.installedAt,
    this.enabledAt,
    this.disabledAt,
  });
}
