import base64
import hashlib
import os

def create_code_verifier() -> str:
    return base64.urlsafe_b64encode(os.urandom(32)).rstrip(b'=').decode('ascii')

def create_code_challenge(code_verifier: str) -> str:
    digest = hashlib.sha256(code_verifier.encode('ascii')).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')
