from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from src.middleware.tenant_context import TenantContext, require_tenant_context

router = APIRouter()

class OrganizationCreate(BaseModel):
    name: str

class WorkspaceCreate(BaseModel):
    organization_id: str
    name: str

class MembershipCreate(BaseModel):
    user_id: str
    organization_id: str
    workspace_id: str | None = None
    role_code: str

@router.post('/organizations')
def create_organization(payload: OrganizationCreate):
    return {
        'organization_id': 'ORG-DEMO-000001',
        'organization_code': 'ORG-000001',
        'name': payload.name,
        'status': 'active',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'tenant.organization_created'
    }

@router.post('/workspaces')
def create_workspace(payload: WorkspaceCreate):
    return {
        'workspace_id': 'WSP-DEMO-000001',
        'workspace_code': 'WSP-000001',
        'organization_id': payload.organization_id,
        'name': payload.name,
        'status': 'active',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'tenant.workspace_created'
    }

@router.post('/memberships')
def create_membership(payload: MembershipCreate):
    return {
        'membership_id': 'MEM-DEMO-000001',
        'user_id': payload.user_id,
        'organization_id': payload.organization_id,
        'workspace_id': payload.workspace_id,
        'role_code': payload.role_code,
        'status': 'active',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'tenant.membership_added'
    }

@router.get('/context')
def read_tenant_context(context: TenantContext = Depends(require_tenant_context)):
    return {
        'organization_id': context.organization_id,
        'workspace_id': context.workspace_id,
        'branch_id': context.branch_id,
        'status': 'valid'
    }
