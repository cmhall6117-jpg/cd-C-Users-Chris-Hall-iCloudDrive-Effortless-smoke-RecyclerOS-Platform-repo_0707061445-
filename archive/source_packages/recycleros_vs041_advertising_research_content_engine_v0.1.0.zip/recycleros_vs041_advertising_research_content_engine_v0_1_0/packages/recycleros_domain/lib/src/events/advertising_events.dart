class AdvertisingEventTypes {
  static const advertisingResearchCreated = 'advertising.research_created';
  static const promotionalContentDrafted = 'advertising.content_drafted';
  static const promotionalContentApproved = 'advertising.content_approved';
  static const campaignPerformanceRecorded = 'advertising.performance_recorded';
}
