import 'package:flutter/material.dart';

class NotificationTaskCenterScreen extends StatelessWidget {
  const NotificationTaskCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Compliance', 'Disposal record needed before vehicle closeout', 'High'),
      ('Sync', '3 offline records waiting to sync', 'Medium'),
      ('Decision', 'Approve part-out procurement recommendation', 'High'),
      ('Inventory', 'Cycle count discrepancy requires review', 'Medium'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Notification & Task Center')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Pending Actions', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          for (final item in items)
            Card(
              child: ListTile(
                leading: const Icon(Icons.notifications_active),
                title: Text('${item.$1}: ${item.$2}'),
                subtitle: Text('Priority: ${item.$3}'),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ),
    );
  }
}
