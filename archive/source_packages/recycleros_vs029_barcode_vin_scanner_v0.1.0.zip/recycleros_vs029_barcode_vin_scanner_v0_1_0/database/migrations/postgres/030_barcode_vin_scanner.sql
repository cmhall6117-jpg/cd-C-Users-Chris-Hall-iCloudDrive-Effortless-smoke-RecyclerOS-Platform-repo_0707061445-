CREATE TABLE IF NOT EXISTS scan_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scan_code TEXT UNIQUE NOT NULL,
    scan_type TEXT NOT NULL,
    scanned_value TEXT NOT NULL,
    related_object_type TEXT,
    related_object_id TEXT,
    scanned_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scan_records_value ON scan_records(scanned_value);
CREATE INDEX IF NOT EXISTS idx_scan_records_related ON scan_records(related_object_type, related_object_id);
