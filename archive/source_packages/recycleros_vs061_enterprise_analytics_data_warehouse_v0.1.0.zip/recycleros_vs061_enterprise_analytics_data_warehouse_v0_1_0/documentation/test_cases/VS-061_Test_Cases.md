# VS-061 Enterprise Analytics & Data Warehouse Test Cases

TC-001 Analytics Summary: tenant-scoped summary returns KPI metrics.
TC-002 Historical Snapshot: snapshot preserves period and generation timestamp.
TC-003 Warehouse Load: analytics.warehouse_load_started event is recorded.
TC-004 Tenant Isolation: analytics queries reject cross-tenant access.
TC-005 Fact Sales: sales fact stores tenant, date, revenue, refund, and source identifiers.
TC-006 Fact Inventory: inventory movement fact stores movement type, quantity, and value.
TC-007 Load Errors: warehouse load job records error count and summary.
TC-008 Offline Analytics: cached analytics retain organization and workspace IDs.
