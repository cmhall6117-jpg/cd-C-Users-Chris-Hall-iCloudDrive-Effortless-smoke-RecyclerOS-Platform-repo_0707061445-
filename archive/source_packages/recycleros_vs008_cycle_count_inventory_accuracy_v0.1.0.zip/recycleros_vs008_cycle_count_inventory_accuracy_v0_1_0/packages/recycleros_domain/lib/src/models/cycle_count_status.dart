enum CycleCountStatus {
  planned,
  active,
  completed,
  cancelled,
}
