class InventoryPerformanceEventTypes {
  static const snapshotGenerated = 'inventory_performance.snapshot_generated';
  static const stockLimitUpdated = 'inventory_performance.stock_limit_updated';
  static const shelfLifeAlertTriggered = 'inventory_performance.shelf_life_alert_triggered';
  static const specialSaleRecommended = 'inventory_performance.special_sale_recommended';
  static const procurementLimitWarning = 'inventory_performance.procurement_limit_warning';
}
