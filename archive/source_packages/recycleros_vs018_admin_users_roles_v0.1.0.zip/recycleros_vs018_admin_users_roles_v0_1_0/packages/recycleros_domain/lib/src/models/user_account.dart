class UserAccount {
  final String userId;
  final String userCode;
  final String displayName;
  final String email;
  final String status;
  final DateTime createdAt;

  const UserAccount({
    required this.userId,
    required this.userCode,
    required this.displayName,
    required this.email,
    required this.status,
    required this.createdAt,
  });
}
