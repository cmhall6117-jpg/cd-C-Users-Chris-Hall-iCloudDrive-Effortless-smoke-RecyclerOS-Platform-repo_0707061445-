# VS-006 Sales & Fulfillment

Capabilities:
- Commerce Intelligence
- Financial Intelligence
- Inventory Lifecycle Tracking

Workflow:
- WFL-008 Sales & Fulfillment

Events:
- EVT-012 Listing Published
- EVT-013 Item Sold
- EVT-014 Payment Received
- Shipment Created
- Order Fulfilled

Objects:
- Inventory Item
- Customer
- Sales Order
- Invoice
- Payment
- Shipment

Acceptance Criteria:
1. User can create a sales order from an inventory item.
2. Sales order links to customer and inventory item.
3. Invoice and payment scaffolds exist.
4. Shipment record can be created.
5. Inventory status can move from available/listed to sold.
6. Revenue event is recorded.
