class ForecastEventTypes {
  static const salesForecastGenerated = 'forecast.sales_generated';
  static const forecastLineCreated = 'forecast.line_created';
  static const forecastStatusChanged = 'forecast.status_changed';
  static const revenueProjectionUpdated = 'forecast.revenue_projection_updated';
}
