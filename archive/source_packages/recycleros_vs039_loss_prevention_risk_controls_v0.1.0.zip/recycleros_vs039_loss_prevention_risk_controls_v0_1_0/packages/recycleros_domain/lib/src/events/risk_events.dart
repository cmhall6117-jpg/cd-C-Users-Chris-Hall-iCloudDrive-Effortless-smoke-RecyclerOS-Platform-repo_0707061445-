class RiskEventTypes {
  static const riskFlagCreated = 'risk.flag_created';
  static const approvalHoldPlaced = 'risk.approval_hold_placed';
  static const approvalHoldReleased = 'risk.approval_hold_released';
  static const shrinkSignalDetected = 'risk.shrink_signal_detected';
  static const suspiciousReturnFlagged = 'risk.suspicious_return_flagged';
}
