# RC1 Acceptance Criteria

## Product Acceptance

The release candidate is acceptable when a user can:

1. Authenticate.
2. Select an organization and workspace.
3. Open Mission Control.
4. Create an opportunity.
5. Create or link a vehicle.
6. Record procurement intent.
7. Create a pick list.
8. Record harvested inventory.
9. Create a listing draft.
10. Review operational and AI recommendations.

## Technical Acceptance

- All required services start.
- No unresolved critical import, build, or migration failures.
- Tenant context is enforced.
- Offline queue records tenant identifiers.
- Core APIs return valid responses.
- Automated tests provide reproducible results.

## Governance Acceptance

- Release documentation is timestamped.
- Defects and waivers are recorded.
- Security and secrets rules are followed.
- Product Owner acceptance is documented.
