class Shipment {
  final String shipmentId;
  final String shipmentCode;
  final String salesOrderId;
  final String carrier;
  final String? trackingNumber;
  final String status;

  const Shipment({
    required this.shipmentId,
    required this.shipmentCode,
    required this.salesOrderId,
    required this.carrier,
    this.trackingNumber,
    required this.status,
  });
}
