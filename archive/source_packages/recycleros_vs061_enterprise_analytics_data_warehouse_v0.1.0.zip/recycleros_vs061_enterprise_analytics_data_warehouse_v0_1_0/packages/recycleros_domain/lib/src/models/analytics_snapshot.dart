class AnalyticsSnapshot {
  final String analyticsSnapshotId;
  final String snapshotCode;
  final String organizationId;
  final String workspaceId;
  final String metricCode;
  final double metricValue;
  final String metricUnit;
  final DateTime periodStart;
  final DateTime periodEnd;
  final DateTime generatedAt;

  const AnalyticsSnapshot({
    required this.analyticsSnapshotId,
    required this.snapshotCode,
    required this.organizationId,
    required this.workspaceId,
    required this.metricCode,
    required this.metricValue,
    required this.metricUnit,
    required this.periodStart,
    required this.periodEnd,
    required this.generatedAt,
  });
}
