class GpsLocation {
  final String gpsLocationId;
  final double latitude;
  final double longitude;
  final double? accuracyMeters;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime capturedAt;

  const GpsLocation({
    required this.gpsLocationId,
    required this.latitude,
    required this.longitude,
    this.accuracyMeters,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.capturedAt,
  });
}
