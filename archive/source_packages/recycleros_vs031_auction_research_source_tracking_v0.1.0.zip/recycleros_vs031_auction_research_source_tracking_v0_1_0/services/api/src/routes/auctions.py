from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class AuctionSourceCreate(BaseModel):
    name: str
    access_type: str = 'unknown'
    website_url: str | None = None
    location: str | None = None
    buyer_fee_percent: float | None = None

@router.post('/sources')
def create_auction_source(payload: AuctionSourceCreate):
    return {
        'auction_source_id': 'AUC-SRC-DEMO-000001',
        'source_code': 'AUC-SRC-000001',
        'name': payload.name,
        'access_type': payload.access_type,
        'website_url': payload.website_url,
        'location': payload.location,
        'buyer_fee_percent': payload.buyer_fee_percent,
        'reliability_status': 'unknown',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'auction.source_created'
    }

@router.get('/watchlist')
def auction_watchlist():
    return {
        'items': [
            {'watchlist_item_id': 'AWL-DEMO-000001', 'listing_title': '2019 Ford F-150', 'current_bid': 3200, 'recommended_max_bid': 3900}
        ]
    }
