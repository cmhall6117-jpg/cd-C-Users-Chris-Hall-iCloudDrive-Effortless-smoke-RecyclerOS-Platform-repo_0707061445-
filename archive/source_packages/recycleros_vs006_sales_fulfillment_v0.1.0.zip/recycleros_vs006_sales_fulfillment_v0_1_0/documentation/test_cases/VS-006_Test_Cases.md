# VS-006 Sales & Fulfillment Test Cases

TC-001 Create Sales Order:
Given available inventory exists, when user creates order, then sales order and line items are created.

TC-002 Record Payment:
Given an open sales order exists, when payment is recorded, then payment received event is created.

TC-003 Inventory Status:
Given inventory item is sold, then inventory status updates to sold.

TC-004 Shipment:
Given order is paid, when shipment is created, then shipment record is stored.

TC-005 Offline Sales:
Given device is offline, when order is created, then order is saved locally and queued for sync.
