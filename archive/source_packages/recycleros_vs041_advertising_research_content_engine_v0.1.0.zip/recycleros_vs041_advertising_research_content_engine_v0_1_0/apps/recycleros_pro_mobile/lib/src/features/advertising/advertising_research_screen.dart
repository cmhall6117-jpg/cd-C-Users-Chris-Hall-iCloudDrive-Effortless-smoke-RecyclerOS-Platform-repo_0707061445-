import 'package:flutter/material.dart';

class AdvertisingResearchScreen extends StatelessWidget {
  const AdvertisingResearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ideas = [
      ('Facebook Marketplace', 'Truck ECM clearance post'),
      ('Instagram', 'Before/after parts recovery reel'),
      ('eBay', 'High-demand module listing optimization'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Advertising Research')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Promotion Content Engine', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Research channels, audiences, content ideas, and campaign performance.'),
          const SizedBox(height: 16),
          for (final idea in ideas)
            Card(child: ListTile(leading: const Icon(Icons.campaign), title: Text(idea.$1), subtitle: Text(idea.$2))),
        ],
      ),
    );
  }
}
