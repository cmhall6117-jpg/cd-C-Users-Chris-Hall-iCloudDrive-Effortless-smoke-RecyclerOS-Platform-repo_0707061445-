class TaskItem {
  final String taskId;
  final String taskCode;
  final String title;
  final String status;
  final String priority;
  final String? assignedTo;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime createdAt;
  final DateTime? dueAt;

  const TaskItem({
    required this.taskId,
    required this.taskCode,
    required this.title,
    required this.status,
    required this.priority,
    this.assignedTo,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.createdAt,
    this.dueAt,
  });
}
