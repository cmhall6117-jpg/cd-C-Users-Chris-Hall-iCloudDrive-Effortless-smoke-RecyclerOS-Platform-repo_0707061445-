class ScrapMetalValue {
  final String scrapMetalValueId;
  final String materialType;
  final String localMarket;
  final String unit;
  final double pricePerUnit;
  final DateTime capturedAt;

  const ScrapMetalValue({
    required this.scrapMetalValueId,
    required this.materialType,
    required this.localMarket,
    required this.unit,
    required this.pricePerUnit,
    required this.capturedAt,
  });
}
