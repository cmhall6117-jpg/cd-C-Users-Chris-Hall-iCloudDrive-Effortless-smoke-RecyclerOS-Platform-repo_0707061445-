CREATE TABLE IF NOT EXISTS orchestrator_actions (
    id TEXT PRIMARY KEY,
    action_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'informational',
    priority_score REAL NOT NULL DEFAULT 0,
    confidence_score REAL NOT NULL DEFAULT 0,
    related_object_type TEXT,
    related_object_id TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
