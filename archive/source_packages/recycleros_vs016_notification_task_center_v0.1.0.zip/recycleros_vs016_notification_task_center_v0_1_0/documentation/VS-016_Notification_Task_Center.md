# VS-016 Notification & Task Center

Capabilities:
- Notification Engine
- Task Management
- Compliance Alerts
- Recommendation Approval Queue
- Sync Health Alerts

Acceptance Criteria:
1. System can create a notification.
2. System can create a user task.
3. Task can be linked to business object and workflow.
4. Alerts can be acknowledged.
5. Offline notifications/tasks are cached locally.
6. Notification Center displays pending items.
