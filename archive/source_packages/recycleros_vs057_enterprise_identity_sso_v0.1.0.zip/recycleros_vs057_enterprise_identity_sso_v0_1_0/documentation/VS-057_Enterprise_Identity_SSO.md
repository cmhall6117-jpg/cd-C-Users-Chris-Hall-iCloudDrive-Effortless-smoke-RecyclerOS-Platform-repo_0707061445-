# VS-057 Enterprise Identity & Single Sign-On

Capabilities:
- Enterprise Authentication
- Single Sign-On
- OAuth 2.0 / OpenID Connect Readiness
- SAML 2.0 Readiness
- Multi-Factor Authentication
- Passwordless Login Readiness
- Trusted Device Management
- Session and Token Management
- Organization Identity Providers
- Authentication Policies

Supported Provider Types:
- Microsoft Entra ID
- Google Workspace
- Okta
- Auth0
- Keycloak
- Ping Identity
- ADFS
- Local RecyclerOS Authentication

Acceptance Criteria:
1. Organization can configure one or more identity providers.
2. User identity can link external provider subject to RecyclerOS user.
3. Authentication policy can require MFA, trusted device, and session limits.
4. Session records support active, expired, revoked, and logged_out states.
5. Refresh-token metadata can be stored without exposing token values.
6. Trusted devices can be registered and revoked.
7. Offline session validation uses cached policy and last valid session only.
8. Authentication events are fully auditable.
