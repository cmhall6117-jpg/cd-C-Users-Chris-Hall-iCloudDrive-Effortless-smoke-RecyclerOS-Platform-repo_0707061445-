from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class ImportJobCreate(BaseModel):
    import_type: str
    source_file_name: str
    total_rows: int = 0

@router.post('/jobs')
def create_import_job(payload: ImportJobCreate):
    return {
        'import_job_id': 'IMP-DEMO-000001',
        'import_code': 'IMP-000001',
        'import_type': payload.import_type,
        'source_file_name': payload.source_file_name,
        'status': 'draft',
        'total_rows': payload.total_rows,
        'valid_rows': 0,
        'error_rows': 0,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'import.job_created'
    }
