class SystemErrorLog {
  final String systemErrorLogId;
  final String severity;
  final String source;
  final String message;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime occurredAt;

  const SystemErrorLog({
    required this.systemErrorLogId,
    required this.severity,
    required this.source,
    required this.message,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.occurredAt,
  });
}
