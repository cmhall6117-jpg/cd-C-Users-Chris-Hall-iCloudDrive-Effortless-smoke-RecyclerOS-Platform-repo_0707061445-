# VS-032 Supplier & Vendor Management Test Cases

TC-001 Create Vendor: vendor.created event is recorded.
TC-002 Vendor Type: vendor stores salvage yard, auction, disposal, shipping, repair, marketplace, or other type.
TC-003 Vendor Performance: performance snapshot stores scores and notes.
TC-004 Vendor List: API returns vendor list.
TC-005 Offline Vendor: vendor saves locally with sync_status pending.
