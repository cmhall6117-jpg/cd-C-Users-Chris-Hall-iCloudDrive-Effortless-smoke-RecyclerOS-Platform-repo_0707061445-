class LeadEventTypes {
  static const leadCreated = 'lead.created';
  static const leadStatusChanged = 'lead.status_changed';
  static const outreachActivityRecorded = 'lead.outreach_activity_recorded';
  static const leadConverted = 'lead.converted';
  static const leadLost = 'lead.lost';
}
