class EnterpriseLoginSession {
  final String loginSessionId;
  final String sessionCode;
  final String userId;
  final String organizationId;
  final String workspaceId;
  final String deviceId;
  final String status;
  final DateTime createdAt;
  final DateTime expiresAt;
  final DateTime? revokedAt;

  const EnterpriseLoginSession({
    required this.loginSessionId,
    required this.sessionCode,
    required this.userId,
    required this.organizationId,
    required this.workspaceId,
    required this.deviceId,
    required this.status,
    required this.createdAt,
    required this.expiresAt,
    this.revokedAt,
  });
}
