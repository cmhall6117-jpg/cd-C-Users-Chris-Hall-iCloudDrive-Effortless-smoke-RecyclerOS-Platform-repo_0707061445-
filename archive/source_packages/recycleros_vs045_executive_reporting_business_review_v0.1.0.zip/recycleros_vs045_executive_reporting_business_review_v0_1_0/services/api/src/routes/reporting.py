from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class BusinessReviewCreate(BaseModel):
    title: str
    reporting_period: str

@router.post('/business-reviews')
def create_business_review(payload: BusinessReviewCreate):
    return {
        'business_review_pack_id': 'BRP-DEMO-000001',
        'review_code': 'BRP-000001',
        'title': payload.title,
        'reporting_period': payload.reporting_period,
        'status': 'draft',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'reporting.business_review_created'
    }

@router.get('/business-reviews/latest')
def latest_business_review():
    return {
        'review_code': 'BRP-000001',
        'title': 'Weekly RecyclerOS Business Review',
        'status': 'draft',
        'sections': ['KPI Summary', 'Financial Summary', 'Sales Forecast', 'Risk Summary']
    }
