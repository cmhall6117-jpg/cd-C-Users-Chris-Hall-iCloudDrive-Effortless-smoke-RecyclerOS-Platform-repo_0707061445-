class AdminActionRecord {
  final String adminActionRecordId;
  final String actionCode;
  final String actorUserId;
  final String scopeType;
  final String? organizationId;
  final String? workspaceId;
  final String actionType;
  final String targetObjectType;
  final String targetObjectId;
  final String status;
  final DateTime createdAt;

  const AdminActionRecord({
    required this.adminActionRecordId,
    required this.actionCode,
    required this.actorUserId,
    required this.scopeType,
    this.organizationId,
    this.workspaceId,
    required this.actionType,
    required this.targetObjectType,
    required this.targetObjectId,
    required this.status,
    required this.createdAt,
  });
}
