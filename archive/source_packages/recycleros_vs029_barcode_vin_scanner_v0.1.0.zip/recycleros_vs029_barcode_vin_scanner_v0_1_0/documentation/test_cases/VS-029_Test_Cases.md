# VS-029 Barcode & VIN Scanner Test Cases

TC-001 Scanner Screen Loads: scanner options display.
TC-002 VIN Scan: VIN scan creates scanner.vin_captured event.
TC-003 Barcode Scan: barcode scan creates scanner.barcode_scanned event.
TC-004 Object Link: scan record links to related object.
TC-005 Offline Scan: scan record saves locally with sync_status pending.
