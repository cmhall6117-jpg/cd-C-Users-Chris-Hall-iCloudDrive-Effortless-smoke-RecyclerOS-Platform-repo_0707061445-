from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class InventoryCreate(BaseModel):
    part_name: str
    source_vehicle_id: str | None = None
    harvest_session_id: str | None = None
    storage_location_id: str | None = None
    condition: str = "usedUntested"
    status: str = "available"
    quantity: int = 1
    estimated_value: float | None = None

@router.post("")
def create_inventory_item(payload: InventoryCreate):
    now = datetime.now(timezone.utc)
    return {
        "inventory_item_id": "INV-DEMO-000001",
        "inventory_code": "INV-000001",
        "part_name": payload.part_name,
        "condition": payload.condition,
        "status": payload.status,
        "quantity": payload.quantity,
        "created_at": now.isoformat(),
        "event_created": "inventory.created"
    }

@router.get("")
def list_inventory_items():
    return {
        "items": [
            {
                "inventory_item_id": "INV-DEMO-000001",
                "inventory_code": "INV-000001",
                "part_name": "ECM / PCM",
                "condition": "usedUntested",
                "status": "available",
                "quantity": 1
            }
        ]
    }
