class PluginDependency {
  final String pluginDependencyId;
  final String pluginId;
  final String requiredPluginId;
  final String versionConstraint;
  final String status;

  const PluginDependency({
    required this.pluginDependencyId,
    required this.pluginId,
    required this.requiredPluginId,
    required this.versionConstraint,
    required this.status,
  });
}
