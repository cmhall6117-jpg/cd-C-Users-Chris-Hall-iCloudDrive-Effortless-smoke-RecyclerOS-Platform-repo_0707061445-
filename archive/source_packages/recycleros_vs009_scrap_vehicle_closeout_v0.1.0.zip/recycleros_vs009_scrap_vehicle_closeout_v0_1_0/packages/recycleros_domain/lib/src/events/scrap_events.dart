class ScrapEventTypes {
  static const vehicleEconomicallyComplete = 'vehicle.economically_complete';
  static const scrapValueRecorded = 'scrap.value_recorded';
  static const disposalRecordCreated = 'disposal.record_created';
  static const vehicleScrapped = 'vehicle.scrapped';
}
