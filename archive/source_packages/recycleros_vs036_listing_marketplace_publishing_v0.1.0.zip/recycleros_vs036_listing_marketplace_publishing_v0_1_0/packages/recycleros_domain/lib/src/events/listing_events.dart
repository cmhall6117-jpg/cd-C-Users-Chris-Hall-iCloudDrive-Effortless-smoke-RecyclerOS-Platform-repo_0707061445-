class ListingEventTypes {
  static const listingCreated = 'listing.created';
  static const listingReady = 'listing.ready';
  static const listingPublished = 'listing.published';
  static const listingPublishFailed = 'listing.publish_failed';
  static const listingEnded = 'listing.ended';
}
