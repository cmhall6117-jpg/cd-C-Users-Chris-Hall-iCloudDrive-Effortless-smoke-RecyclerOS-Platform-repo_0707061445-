enum ListingStatus {
  draft,
  ready,
  published,
  sold,
  ended,
  error,
}
