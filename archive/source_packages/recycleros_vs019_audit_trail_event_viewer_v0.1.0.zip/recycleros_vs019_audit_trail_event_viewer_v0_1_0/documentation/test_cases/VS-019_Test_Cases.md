# VS-019 Audit Trail & Event Viewer Test Cases

TC-001 List Events: event list displays event code, type, object, user, and timestamp.
TC-002 Filter by Object: object timeline returns related events.
TC-003 Read Only: audit records cannot be edited from UI.
TC-004 Audit Viewed Event: audit.viewed event is recorded.
TC-005 Offline Audit: locally stored events display offline.
