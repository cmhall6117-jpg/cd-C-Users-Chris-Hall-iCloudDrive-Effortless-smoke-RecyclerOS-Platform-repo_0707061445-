CREATE TABLE IF NOT EXISTS inventory_performance_snapshots (
    id TEXT PRIMARY KEY,
    inventory_item_id TEXT NOT NULL,
    shelf_life_days INTEGER NOT NULL DEFAULT 0,
    return_count INTEGER NOT NULL DEFAULT 0,
    quantity_on_hand INTEGER NOT NULL DEFAULT 0,
    quantity_sold INTEGER NOT NULL DEFAULT 0,
    sell_through_rate REAL NOT NULL DEFAULT 0,
    return_ratio REAL NOT NULL DEFAULT 0,
    generated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS stock_limit_policies (
    id TEXT PRIMARY KEY,
    policy_code TEXT UNIQUE NOT NULL,
    part_category TEXT NOT NULL,
    max_on_hand_quantity INTEGER NOT NULL DEFAULT 0,
    target_shelf_life_days INTEGER NOT NULL DEFAULT 0,
    max_return_ratio REAL NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
