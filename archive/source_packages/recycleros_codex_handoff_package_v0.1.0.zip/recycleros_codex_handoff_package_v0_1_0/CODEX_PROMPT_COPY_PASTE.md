# Copy/Paste Prompt for Codex

You are working on RecyclerOS Platform for Effortless Smoke, LLC.

Your task is CODEX-TASK-001: create the first integrated RecyclerOS repository from the generated scaffold packages.

Start only with:
- DF-001 Development Foundation
- VS-001 Opportunity Discovery
- VS-002 Vehicle Digital Twin
- VS-003 Procurement Workspace
- VS-004 Pick List & Focus Point
- VS-005 Inventory Intake
- VS-021 Integration Readiness & Smoke Test Harness
- VS-022 Local Integration Bundle

Do not merge all 26 packages yet.

Goal:
Build the first MVP shell path:
Mission Control → Opportunity Discovery → Create Opportunity → API Response → Business Event

Work:
- Merge package contents into one monorepo.
- Preserve documentation and SQL migrations.
- Register FastAPI routers.
- Register Flutter routes.
- Resolve duplicate Dart models/enums.
- Run flutter pub get.
- Run flutter analyze.
- Run backend import/startup check.
- Validate first six PostgreSQL migrations.
- Create documentation/defects/DEFECT_REGISTER.md.
- Create documentation/assumptions/ASSUMPTIONS.md.
- Do not delete generated docs.
- Do not rewrite the architecture.
- Record every unresolved issue.

Return:
- Summary of what changed.
- Files modified.
- Build/test results.
- Defect list.
- Next recommended task.
