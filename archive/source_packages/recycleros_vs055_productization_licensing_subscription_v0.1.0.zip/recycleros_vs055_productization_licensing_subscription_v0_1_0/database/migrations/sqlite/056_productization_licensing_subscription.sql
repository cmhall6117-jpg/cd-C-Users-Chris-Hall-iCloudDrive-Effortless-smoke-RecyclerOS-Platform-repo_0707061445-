CREATE TABLE IF NOT EXISTS subscription_plans (
    id TEXT PRIMARY KEY,
    plan_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    price REAL NOT NULL DEFAULT 0,
    billing_interval TEXT NOT NULL DEFAULT 'monthly',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS license_records (
    id TEXT PRIMARY KEY,
    license_code TEXT UNIQUE NOT NULL,
    account_id TEXT NOT NULL,
    subscription_plan_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'trial',
    started_at TEXT NOT NULL,
    expires_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS feature_entitlements (
    id TEXT PRIMARY KEY,
    subscription_plan_id TEXT NOT NULL,
    feature_code TEXT NOT NULL,
    is_enabled INTEGER NOT NULL DEFAULT 1,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
