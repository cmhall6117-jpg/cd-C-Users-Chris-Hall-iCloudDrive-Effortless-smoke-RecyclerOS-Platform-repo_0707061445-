CREATE TABLE IF NOT EXISTS advertising_research_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    research_code TEXT UNIQUE NOT NULL,
    channel TEXT NOT NULL,
    audience TEXT NOT NULL,
    product_category TEXT NOT NULL,
    notes TEXT,
    confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS promotional_content_drafts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_code TEXT UNIQUE NOT NULL,
    promotion_campaign_id UUID REFERENCES promotion_campaigns(id),
    channel TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
