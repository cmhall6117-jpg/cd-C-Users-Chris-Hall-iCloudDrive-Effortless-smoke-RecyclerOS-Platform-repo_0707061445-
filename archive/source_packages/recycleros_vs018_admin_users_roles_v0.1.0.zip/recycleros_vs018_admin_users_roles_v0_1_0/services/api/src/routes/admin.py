from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class UserCreate(BaseModel):
    display_name: str
    email: str
    role_code: str | None = None

@router.post('/users')
def create_user(payload: UserCreate):
    return {
        'user_id': 'USR-DEMO-000001',
        'user_code': 'USR-000001',
        'display_name': payload.display_name,
        'email': payload.email,
        'status': 'active',
        'role_code': payload.role_code,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'user.created'
    }

@router.get('/roles')
def list_roles():
    return {
        'items': [
            {'role_code': 'ROLE-ADMIN', 'name': 'Owner / Admin'},
            {'role_code': 'ROLE-OPS', 'name': 'Operations Manager'},
            {'role_code': 'ROLE-TECH', 'name': 'Technician'},
            {'role_code': 'ROLE-SALES', 'name': 'Sales'},
            {'role_code': 'ROLE-FINANCE', 'name': 'Finance'}
        ]
    }
