CREATE TABLE IF NOT EXISTS market_price_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_code TEXT UNIQUE NOT NULL,
    inventory_item_id UUID REFERENCES inventory_items(id),
    part_name TEXT NOT NULL,
    low_price NUMERIC(12,2) NOT NULL DEFAULT 0,
    average_price NUMERIC(12,2) NOT NULL DEFAULT 0,
    high_price NUMERIC(12,2) NOT NULL DEFAULT 0,
    confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    source_summary TEXT,
    captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS scrap_metal_values (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    material_type TEXT NOT NULL,
    local_market TEXT NOT NULL,
    unit TEXT NOT NULL DEFAULT 'lb',
    price_per_unit NUMERIC(12,4) NOT NULL,
    captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
