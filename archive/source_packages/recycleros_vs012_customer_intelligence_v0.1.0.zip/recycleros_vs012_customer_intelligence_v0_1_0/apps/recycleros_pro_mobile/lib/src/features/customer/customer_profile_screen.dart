import 'package:flutter/material.dart';

class CustomerProfileScreen extends StatelessWidget {
  const CustomerProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final preferences = ['GM Transmissions', 'Ford Truck Modules', 'LED Headlights'];
    final matches = [
      ('INV-000001', 'ECM / PCM', 'Matches Ford truck module preference'),
      ('INV-000002', 'LED Headlight LH', 'Matches LED headlight preference'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Customer Intelligence')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Customer Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Card(child: ListTile(leading: Icon(Icons.person), title: Text('Demo Repair Shop'), subtitle: Text('Customer Lifetime Value: pending calculation'))),
          const SizedBox(height: 12),
          const Text('Preferences', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (final pref in preferences) Card(child: ListTile(leading: const Icon(Icons.favorite), title: Text(pref))),
          const SizedBox(height: 12),
          const Text('Inventory Matches', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (final match in matches) Card(child: ListTile(leading: const Icon(Icons.link), title: Text(match.$2), subtitle: Text('${match.$1} • ${match.$3}'))),
        ],
      ),
    );
  }
}
