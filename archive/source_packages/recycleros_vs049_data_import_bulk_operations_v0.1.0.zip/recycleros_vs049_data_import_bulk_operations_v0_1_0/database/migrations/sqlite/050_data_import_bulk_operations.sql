CREATE TABLE IF NOT EXISTS import_jobs (
    id TEXT PRIMARY KEY,
    import_code TEXT UNIQUE NOT NULL,
    import_type TEXT NOT NULL,
    source_file_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    total_rows INTEGER NOT NULL DEFAULT 0,
    valid_rows INTEGER NOT NULL DEFAULT 0,
    error_rows INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    committed_at TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS import_validation_errors (
    id TEXT PRIMARY KEY,
    import_job_id TEXT NOT NULL,
    row_number INTEGER NOT NULL,
    field_name TEXT NOT NULL,
    error_message TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
