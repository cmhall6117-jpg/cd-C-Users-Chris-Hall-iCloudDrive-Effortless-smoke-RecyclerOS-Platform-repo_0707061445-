CREATE TABLE IF NOT EXISTS sales_forecast_snapshots (
    id TEXT PRIMARY KEY,
    snapshot_code TEXT UNIQUE NOT NULL,
    projected_revenue REAL NOT NULL DEFAULT 0,
    weighted_revenue REAL NOT NULL DEFAULT 0,
    open_lead_count INTEGER NOT NULL DEFAULT 0,
    open_listing_count INTEGER NOT NULL DEFAULT 0,
    generated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS sales_forecast_lines (
    id TEXT PRIMARY KEY,
    snapshot_id TEXT NOT NULL,
    related_object_type TEXT NOT NULL,
    related_object_id TEXT NOT NULL,
    projected_amount REAL NOT NULL DEFAULT 0,
    probability_percent REAL NOT NULL DEFAULT 0,
    weighted_amount REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    expected_close_date TEXT,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
