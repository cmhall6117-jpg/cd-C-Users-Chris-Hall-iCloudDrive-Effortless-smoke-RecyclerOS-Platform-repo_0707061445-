class InventoryPerformanceSnapshot {
  final String snapshotId;
  final String inventoryItemId;
  final int shelfLifeDays;
  final int returnCount;
  final int quantityOnHand;
  final int quantitySold;
  final double sellThroughRate;
  final double returnRatio;
  final DateTime generatedAt;

  const InventoryPerformanceSnapshot({
    required this.snapshotId,
    required this.inventoryItemId,
    required this.shelfLifeDays,
    required this.returnCount,
    required this.quantityOnHand,
    required this.quantitySold,
    required this.sellThroughRate,
    required this.returnRatio,
    required this.generatedAt,
  });
}
