class SyncV2EventTypes {
  static const batchStarted = 'sync_v2.batch_started';
  static const batchResumed = 'sync_v2.batch_resumed';
  static const conflictDetected = 'sync_v2.conflict_detected';
  static const conflictResolved = 'sync_v2.conflict_resolved';
  static const deadLetterCreated = 'sync_v2.dead_letter_created';
  static const recoveryCompleted = 'sync_v2.recovery_completed';
}
