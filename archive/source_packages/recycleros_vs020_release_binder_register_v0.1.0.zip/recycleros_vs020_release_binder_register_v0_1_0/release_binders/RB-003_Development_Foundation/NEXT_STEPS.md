# Next Steps

1. Merge packages into one working repository.
2. Run Flutter project initialization.
3. Wire package imports and routes.
4. Register FastAPI routers.
5. Apply PostgreSQL migrations in sequence.
6. Build SQLite migration manager.
7. Compile and fix errors.
8. Run first local smoke test.
9. Begin integration sprint.
