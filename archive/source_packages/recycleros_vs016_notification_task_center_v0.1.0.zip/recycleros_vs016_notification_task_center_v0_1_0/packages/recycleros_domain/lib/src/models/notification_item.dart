class NotificationItem {
  final String notificationId;
  final String notificationCode;
  final String title;
  final String message;
  final String severity;
  final String status;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime createdAt;

  const NotificationItem({
    required this.notificationId,
    required this.notificationCode,
    required this.title,
    required this.message,
    required this.severity,
    required this.status,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.createdAt,
  });
}
