CREATE TABLE IF NOT EXISTS backup_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    backup_code TEXT UNIQUE NOT NULL,
    backup_type TEXT NOT NULL DEFAULT 'manual',
    status TEXT NOT NULL DEFAULT 'created',
    record_count INTEGER NOT NULL DEFAULT 0,
    file_reference TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS restore_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restore_code TEXT UNIQUE NOT NULL,
    backup_job_id UUID REFERENCES backup_jobs(id),
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS data_retention_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_code TEXT UNIQUE NOT NULL,
    object_type TEXT NOT NULL,
    retention_days INTEGER NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true
);
