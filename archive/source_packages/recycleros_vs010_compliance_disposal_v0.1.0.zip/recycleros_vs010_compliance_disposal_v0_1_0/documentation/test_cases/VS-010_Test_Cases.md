# VS-010 Compliance & Disposal Test Cases

TC-001 Create Disposal Record: disposal.record_created event is created.
TC-002 Vehicle Link: disposal record links to vehicle when vehicle_id is supplied.
TC-003 Offline Save: compliance/disposal records save locally with sync_status pending.
TC-004 Compliance Disclaimer: decision-support disclaimer is visible.
TC-005 Material Type: selected regulated material category is stored.
