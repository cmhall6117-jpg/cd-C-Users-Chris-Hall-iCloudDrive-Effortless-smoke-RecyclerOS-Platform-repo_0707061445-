import 'package:flutter/material.dart';

class CustomerLeadPipelineScreen extends StatelessWidget {
  const CustomerLeadPipelineScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final leads = [
      ('LEAD-000001', 'Facebook inquiry: ECM / PCM', 'new'),
      ('LEAD-000002', 'Marketplace buyer: LED headlight', 'contacted'),
      ('LEAD-000003', 'Repair shop transmission quote', 'qualified'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Lead Pipeline')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Customer Outreach', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Track listing inquiries, promotion responses, follow-ups, and conversion status.'),
          const SizedBox(height: 16),
          for (final lead in leads)
            Card(child: ListTile(leading: const Icon(Icons.person_add), title: Text('${lead.$1} • ${lead.$2}'), subtitle: Text('Status: ${lead.$3}'))),
        ],
      ),
    );
  }
}
