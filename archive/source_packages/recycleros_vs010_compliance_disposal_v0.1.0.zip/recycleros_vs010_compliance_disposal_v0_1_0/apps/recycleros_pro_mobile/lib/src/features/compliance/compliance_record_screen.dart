import 'package:flutter/material.dart';

class ComplianceRecordScreen extends StatefulWidget {
  const ComplianceRecordScreen({super.key});

  @override
  State<ComplianceRecordScreen> createState() => _ComplianceRecordScreenState();
}

class _ComplianceRecordScreenState extends State<ComplianceRecordScreen> {
  String materialType = 'usedOil';
  final vendorController = TextEditingController();
  final quantityController = TextEditingController();

  @override
  void dispose() {
    vendorController.dispose();
    quantityController.dispose();
    super.dispose();
  }

  void saveRecord() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Compliance record saved locally. Sync pending.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final materials = ['usedOil', 'refrigerant', 'battery', 'tire', 'airbag', 'hazardousFluid', 'evBattery', 'catalyticConverter', 'other'];

    return Scaffold(
      appBar: AppBar(title: const Text('Compliance & Disposal')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: saveRecord,
        icon: const Icon(Icons.verified_user),
        label: const Text('Save Record'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Create Disposal Record', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Text('Decision-support only. Verify local legal requirements before disposal.'),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: materialType,
            decoration: const InputDecoration(labelText: 'Material Type', border: OutlineInputBorder()),
            items: materials.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
            onChanged: (value) => setState(() => materialType = value ?? materialType),
          ),
          const SizedBox(height: 12),
          TextField(controller: quantityController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: vendorController, decoration: const InputDecoration(labelText: 'Disposal Vendor', border: OutlineInputBorder())),
        ],
      ),
    );
  }
}
