# VS-009 Scrap & Vehicle Closeout

Capabilities: Vehicle Recovery Optimization, Scrap Value Intelligence, Compliance Intelligence, Financial Intelligence
Workflow: WFL-009 Vehicle Scrap Closeout
Events: EVT-015 Vehicle Scrapped, Vehicle Economically Complete, Scrap Value Recorded, Disposal Record Created
Objects: Vehicle, Scrap Disposition, Scrap Material Line, Compliance Record, Business Event

Acceptance Criteria:
1. User can mark a vehicle as scrap candidate.
2. User can record estimated and actual scrap value.
3. User can record scrap material lines.
4. System supports vehicle economic completion.
5. Scrap closeout creates business and financial events.
6. Offline scrap closeout is supported with sync status.
