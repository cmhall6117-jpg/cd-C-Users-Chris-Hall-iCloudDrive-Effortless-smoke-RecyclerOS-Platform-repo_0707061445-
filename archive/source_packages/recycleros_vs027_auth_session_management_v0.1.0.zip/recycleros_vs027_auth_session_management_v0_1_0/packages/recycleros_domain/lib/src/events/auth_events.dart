class AuthEventTypes {
  static const loginAttempted = 'auth.login_attempted';
  static const loginSucceeded = 'auth.login_succeeded';
  static const loginFailed = 'auth.login_failed';
  static const sessionCreated = 'auth.session_created';
  static const sessionExpired = 'auth.session_expired';
  static const logoutCompleted = 'auth.logout_completed';
}
