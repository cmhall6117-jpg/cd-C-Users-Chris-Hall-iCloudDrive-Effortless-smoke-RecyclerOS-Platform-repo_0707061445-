import 'package:flutter/material.dart';

class SyncHealthScreen extends StatelessWidget {
  const SyncHealthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final queueItems = [
      ('Opportunity', 'OPP-000001', 'pending'),
      ('Inventory Item', 'INV-000001', 'synced'),
      ('Disposal Record', 'DSP-000001', 'failed'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Sync Health')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Platform Sync Health', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Card(
            child: ListTile(
              leading: Icon(Icons.phone_android),
              title: Text('Device Status'),
              subtitle: Text('Connection: offline-ready • Pending Sync: 3 • App: v0.1.0'),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Sync Queue', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (final item in queueItems)
            Card(
              child: ListTile(
                leading: const Icon(Icons.sync),
                title: Text('${item.$1}: ${item.$2}'),
                subtitle: Text('Status: ${item.$3}'),
              ),
            ),
        ],
      ),
    );
  }
}
