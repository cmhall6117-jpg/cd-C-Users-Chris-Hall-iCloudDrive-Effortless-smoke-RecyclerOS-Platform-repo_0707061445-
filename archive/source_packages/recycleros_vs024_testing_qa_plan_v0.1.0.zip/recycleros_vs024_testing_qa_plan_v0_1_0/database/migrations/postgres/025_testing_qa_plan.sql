CREATE TABLE IF NOT EXISTS qa_test_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_run_code TEXT UNIQUE NOT NULL,
    test_type TEXT NOT NULL,
    status TEXT NOT NULL,
    summary TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS qa_test_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_run_id UUID REFERENCES qa_test_runs(id),
    test_case_code TEXT NOT NULL,
    status TEXT NOT NULL,
    message TEXT,
    executed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
