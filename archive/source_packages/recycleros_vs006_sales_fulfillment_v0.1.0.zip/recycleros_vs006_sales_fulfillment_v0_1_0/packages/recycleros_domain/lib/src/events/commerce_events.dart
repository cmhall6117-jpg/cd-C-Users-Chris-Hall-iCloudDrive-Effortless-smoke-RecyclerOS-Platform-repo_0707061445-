class CommerceEventTypes {
  static const listingPublished = 'listing.published';
  static const itemSold = 'item.sold';
  static const paymentReceived = 'payment.received';
  static const shipmentCreated = 'shipment.created';
  static const orderFulfilled = 'order.fulfilled';
}
