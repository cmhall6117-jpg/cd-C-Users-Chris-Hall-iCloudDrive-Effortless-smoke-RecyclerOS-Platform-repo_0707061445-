from dataclasses import dataclass

@dataclass(frozen=True)
class ValidationResult:
    is_valid: bool
    errors: list[str]

REQUIRED_FIELDS = {
    'plugin_id',
    'name',
    'version',
    'vendor',
    'api_version',
    'permissions',
}

def validate_manifest(manifest: dict) -> ValidationResult:
    errors: list[str] = []

    missing = sorted(REQUIRED_FIELDS.difference(manifest.keys()))
    if missing:
        errors.append(f"Missing required fields: {', '.join(missing)}")

    version = str(manifest.get('version', ''))
    if version.count('.') != 2:
        errors.append('Plugin version must use semantic versioning.')

    permissions = manifest.get('permissions')
    if not isinstance(permissions, list):
        errors.append('Permissions must be a list.')

    return ValidationResult(is_valid=not errors, errors=errors)
