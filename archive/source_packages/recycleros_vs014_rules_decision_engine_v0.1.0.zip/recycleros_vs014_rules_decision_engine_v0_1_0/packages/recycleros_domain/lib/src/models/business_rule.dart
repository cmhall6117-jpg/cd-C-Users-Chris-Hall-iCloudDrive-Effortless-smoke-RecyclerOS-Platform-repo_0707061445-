class BusinessRule {
  final String businessRuleId;
  final String ruleCode;
  final String name;
  final String category;
  final String conditionExpression;
  final String actionExpression;
  final bool isActive;
  final DateTime createdAt;

  const BusinessRule({
    required this.businessRuleId,
    required this.ruleCode,
    required this.name,
    required this.category,
    required this.conditionExpression,
    required this.actionExpression,
    required this.isActive,
    required this.createdAt,
  });
}
