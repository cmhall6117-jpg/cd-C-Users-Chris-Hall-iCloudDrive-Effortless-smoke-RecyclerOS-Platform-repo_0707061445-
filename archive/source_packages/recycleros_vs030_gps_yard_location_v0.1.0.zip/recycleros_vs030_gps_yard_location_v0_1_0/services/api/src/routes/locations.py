from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class GpsLocationCreate(BaseModel):
    latitude: float
    longitude: float
    accuracy_meters: float | None = None
    related_object_type: str | None = None
    related_object_id: str | None = None

@router.post('/gps')
def create_gps_location(payload: GpsLocationCreate):
    return {
        'gps_location_id': 'GPS-DEMO-000001',
        'latitude': payload.latitude,
        'longitude': payload.longitude,
        'accuracy_meters': payload.accuracy_meters,
        'related_object_type': payload.related_object_type,
        'related_object_id': payload.related_object_id,
        'captured_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'gps.location_captured'
    }
