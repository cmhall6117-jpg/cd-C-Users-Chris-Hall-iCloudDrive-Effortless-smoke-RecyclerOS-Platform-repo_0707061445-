# VS-008 Cycle Count & Inventory Accuracy Test Cases

TC-001 Start Cycle Count:
Given inventory exists, when user starts a count, then a cycle count session is created.

TC-002 Record Count Line:
Given expected quantity exists, when user enters counted quantity, then variance is calculated.

TC-003 Discrepancy Event:
Given variance is not zero, then inventory.discrepancy_found event is recorded.

TC-004 Accuracy Index:
Given count lines are completed, then inventory accuracy percentage is calculated.

TC-005 Offline Count:
Given device is offline, when count is completed, then session and lines are saved locally with sync_status pending.
