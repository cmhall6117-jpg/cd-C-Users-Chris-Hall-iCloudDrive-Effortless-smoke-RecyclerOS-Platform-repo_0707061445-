class ScannerEventTypes {
  static const barcodeScanned = 'scanner.barcode_scanned';
  static const vinCaptured = 'scanner.vin_captured';
  static const storageLocationScanned = 'scanner.storage_location_scanned';
  static const inventoryItemScanned = 'scanner.inventory_item_scanned';
}
