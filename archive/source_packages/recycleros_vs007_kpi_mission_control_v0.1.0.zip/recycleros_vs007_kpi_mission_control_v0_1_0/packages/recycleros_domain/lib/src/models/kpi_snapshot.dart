class KpiSnapshot {
  final String snapshotId;
  final DateTime generatedAt;
  final int openOpportunities;
  final int activePickListItems;
  final int inventoryAvailableCount;
  final int pendingSyncCount;
  final double salesToday;
  final double projectedOpportunityValue;
  final double inventoryAccuracyPercent;

  const KpiSnapshot({
    required this.snapshotId,
    required this.generatedAt,
    required this.openOpportunities,
    required this.activePickListItems,
    required this.inventoryAvailableCount,
    required this.pendingSyncCount,
    required this.salesToday,
    required this.projectedOpportunityValue,
    required this.inventoryAccuracyPercent,
  });
}
