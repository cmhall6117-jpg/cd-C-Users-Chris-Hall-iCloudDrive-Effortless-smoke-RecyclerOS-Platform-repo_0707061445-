CREATE TABLE IF NOT EXISTS auction_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    access_type TEXT NOT NULL DEFAULT 'unknown',
    website_url TEXT,
    location TEXT,
    buyer_fee_percent NUMERIC(5,2),
    reliability_status TEXT NOT NULL DEFAULT 'unknown',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS auction_watchlist_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auction_source_id UUID REFERENCES auction_sources(id),
    opportunity_id UUID REFERENCES opportunities(id),
    vehicle_id UUID REFERENCES vehicles(id),
    listing_title TEXT NOT NULL,
    listing_url TEXT,
    current_bid NUMERIC(12,2),
    recommended_max_bid NUMERIC(12,2),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
