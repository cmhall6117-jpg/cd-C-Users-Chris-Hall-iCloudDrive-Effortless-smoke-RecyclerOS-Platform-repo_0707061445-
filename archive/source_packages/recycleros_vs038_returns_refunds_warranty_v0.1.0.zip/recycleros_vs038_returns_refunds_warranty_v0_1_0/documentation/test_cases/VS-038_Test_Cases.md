# VS-038 Returns, Refunds & Warranty Test Cases

TC-001 Return Authorization: return.authorized event is recorded.
TC-002 Sales Link: return links to sales order and inventory item.
TC-003 Refund Amount: refund amount can be recorded.
TC-004 Warranty Claim: warranty claim can link to return authorization.
TC-005 Offline Return: return saves locally with sync_status pending.
