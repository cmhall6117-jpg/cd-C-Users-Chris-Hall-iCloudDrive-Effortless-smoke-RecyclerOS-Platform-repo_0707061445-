class AutomationStudioEventTypes {
  static const automationCreated = 'automation_studio.automation_created';
  static const automationPublished = 'automation_studio.automation_published';
  static const automationRunStarted = 'automation_studio.run_started';
  static const automationRunPaused = 'automation_studio.run_paused';
  static const automationRunCompleted = 'automation_studio.run_completed';
  static const automationRunFailed = 'automation_studio.run_failed';
  static const approvalRequested = 'automation_studio.approval_requested';
  static const agentCreated = 'automation_studio.agent_created';
}
