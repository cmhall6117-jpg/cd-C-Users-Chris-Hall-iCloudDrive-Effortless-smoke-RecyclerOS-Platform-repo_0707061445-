# VS-007 KPI & Mission Control Dashboard

Capabilities:
- Mission Control Dashboard
- Executive Intelligence
- Platform Intelligence
- KPI Framework

Acceptance Criteria:
1. Mission Control displays today's priority tiles.
2. KPI dashboard summarizes procurement, inventory, sales, harvest, and sync health.
3. KPI snapshot model exists.
4. API endpoint returns dashboard summary.
5. Offline mode displays last known KPI snapshot.
