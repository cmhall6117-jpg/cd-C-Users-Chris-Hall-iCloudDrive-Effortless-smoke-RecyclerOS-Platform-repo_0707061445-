from datetime import datetime, timezone
from fastapi import APIRouter

router = APIRouter()

@router.get('/sales')
def sales_forecast():
    return {
        'snapshot_id': 'FCST-DEMO-000001',
        'snapshot_code': 'FCST-000001',
        'projected_revenue': 12450.00,
        'weighted_revenue': 8470.00,
        'open_lead_count': 7,
        'open_listing_count': 18,
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'forecast.sales_generated'
    }
