class ComplianceRecord {
  final String complianceRecordId;
  final String complianceCode;
  final String recordType;
  final String? vehicleId;
  final String status;
  final String jurisdiction;
  final DateTime createdAt;
  final String? notes;

  const ComplianceRecord({
    required this.complianceRecordId,
    required this.complianceCode,
    required this.recordType,
    this.vehicleId,
    required this.status,
    required this.jurisdiction,
    required this.createdAt,
    this.notes,
  });
}
