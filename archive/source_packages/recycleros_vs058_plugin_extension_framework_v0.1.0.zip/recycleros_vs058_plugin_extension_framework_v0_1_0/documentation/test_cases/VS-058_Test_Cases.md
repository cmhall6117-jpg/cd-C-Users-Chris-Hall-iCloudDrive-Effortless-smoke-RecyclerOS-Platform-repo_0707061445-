# VS-058 Plugin & Extension Framework Test Cases

TC-001 Validate Manifest: missing required fields block installation.
TC-002 Semantic Version: invalid plugin version is rejected.
TC-003 Resolve Dependencies: missing dependencies block installation.
TC-004 Permission Approval: unapproved permissions block installation.
TC-005 Install Plugin: plugin.installed event is recorded.
TC-006 Enable Plugin: plugin.enabled event is recorded.
TC-007 Disable Plugin: disabled plugin cannot execute registered extensions.
TC-008 Register UI Extension: dashboard card registration is stored.
TC-009 Register API Extension: plugin API route registration is stored.
TC-010 Run Migration: plugin migration status and errors are recorded.
TC-011 Upgrade History: from-version and to-version are preserved.
TC-012 Rollback Plugin: plugin.rollback_completed event is recorded.
TC-013 Tenant Scope: plugin installation belongs to one organization/workspace.
TC-014 Offline Metadata: plugin metadata saves locally with sync_status pending.
