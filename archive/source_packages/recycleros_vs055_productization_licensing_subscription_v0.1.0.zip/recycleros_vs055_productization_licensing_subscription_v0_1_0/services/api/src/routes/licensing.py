from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class SubscriptionPlanCreate(BaseModel):
    name: str
    price: float
    billing_interval: str = 'monthly'

@router.post('/plans')
def create_subscription_plan(payload: SubscriptionPlanCreate):
    return {
        'subscription_plan_id': 'PLAN-DEMO-000001',
        'plan_code': 'PLAN-000001',
        'name': payload.name,
        'price': payload.price,
        'billing_interval': payload.billing_interval,
        'status': 'active',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'licensing.subscription_plan_created'
    }
