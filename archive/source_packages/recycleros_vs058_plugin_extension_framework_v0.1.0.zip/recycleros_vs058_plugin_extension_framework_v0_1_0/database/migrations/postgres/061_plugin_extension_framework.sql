CREATE TABLE IF NOT EXISTS plugin_registry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plugin_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    vendor TEXT NOT NULL,
    current_version TEXT NOT NULL,
    api_version TEXT NOT NULL,
    description TEXT,
    license TEXT,
    status TEXT NOT NULL DEFAULT 'available',
    manifest_json JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS installed_plugins (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plugin_registry_id UUID NOT NULL REFERENCES plugin_registry(id),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    workspace_id UUID NOT NULL REFERENCES workspaces(id),
    installed_version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'installed',
    installed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    enabled_at TIMESTAMPTZ,
    disabled_at TIMESTAMPTZ,
    UNIQUE(plugin_registry_id, organization_id, workspace_id)
);

CREATE TABLE IF NOT EXISTS plugin_permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    installed_plugin_id UUID NOT NULL REFERENCES installed_plugins(id),
    permission_code TEXT NOT NULL,
    approval_status TEXT NOT NULL DEFAULT 'pending',
    approved_by UUID REFERENCES user_accounts(id),
    approved_at TIMESTAMPTZ,
    UNIQUE(installed_plugin_id, permission_code)
);

CREATE TABLE IF NOT EXISTS plugin_dependencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plugin_registry_id UUID NOT NULL REFERENCES plugin_registry(id),
    required_plugin_id TEXT NOT NULL,
    version_constraint TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unresolved'
);

CREATE TABLE IF NOT EXISTS plugin_extension_registrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    installed_plugin_id UUID NOT NULL REFERENCES installed_plugins(id),
    extension_type TEXT NOT NULL,
    extension_key TEXT NOT NULL,
    configuration_json JSONB,
    status TEXT NOT NULL DEFAULT 'registered',
    UNIQUE(installed_plugin_id, extension_type, extension_key)
);

CREATE TABLE IF NOT EXISTS plugin_migration_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    installed_plugin_id UUID NOT NULL REFERENCES installed_plugins(id),
    migration_name TEXT NOT NULL,
    migration_version TEXT NOT NULL,
    direction TEXT NOT NULL DEFAULT 'up',
    status TEXT NOT NULL DEFAULT 'pending',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS plugin_version_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    installed_plugin_id UUID NOT NULL REFERENCES installed_plugins(id),
    from_version TEXT,
    to_version TEXT NOT NULL,
    action TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_installed_plugins_tenant
ON installed_plugins(organization_id, workspace_id);

CREATE INDEX IF NOT EXISTS idx_plugin_extensions_type
ON plugin_extension_registrations(extension_type, status);
