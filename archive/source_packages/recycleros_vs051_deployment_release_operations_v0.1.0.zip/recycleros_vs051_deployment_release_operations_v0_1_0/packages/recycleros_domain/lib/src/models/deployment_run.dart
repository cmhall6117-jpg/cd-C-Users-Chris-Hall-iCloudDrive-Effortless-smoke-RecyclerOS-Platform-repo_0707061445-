class DeploymentRun {
  final String deploymentRunId;
  final String deploymentCode;
  final String releaseVersion;
  final String environmentCode;
  final String status;
  final DateTime startedAt;
  final DateTime? completedAt;

  const DeploymentRun({
    required this.deploymentRunId,
    required this.deploymentCode,
    required this.releaseVersion,
    required this.environmentCode,
    required this.status,
    required this.startedAt,
    this.completedAt,
  });
}
