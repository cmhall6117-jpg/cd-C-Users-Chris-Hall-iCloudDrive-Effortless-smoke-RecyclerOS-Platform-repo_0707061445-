# Next Progress Step

After Codex completes CODEX-TASK-001, the next package should be:

CODEX-TASK-002 — Make Opportunity Discovery Functional

Scope:
1. Wire Flutter Opportunity Discovery form to API.
2. Save opportunity in PostgreSQL.
3. Create business event.
4. Add offline SQLite save path.
5. Add sync queue entry.
6. Add smoke test.
7. Update defect register.
