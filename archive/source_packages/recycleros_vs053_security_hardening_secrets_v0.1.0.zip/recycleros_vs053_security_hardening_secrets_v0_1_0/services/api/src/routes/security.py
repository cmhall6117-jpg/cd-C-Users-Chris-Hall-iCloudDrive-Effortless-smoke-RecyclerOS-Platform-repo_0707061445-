from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class SecretReferenceCreate(BaseModel):
    name: str
    environment_code: str
    provider: str = 'environment'
    status: str = 'active'

@router.post('/secret-references')
def create_secret_reference(payload: SecretReferenceCreate):
    return {
        'secret_reference_id': 'SEC-DEMO-000001',
        'secret_code': 'SEC-000001',
        'name': payload.name,
        'environment_code': payload.environment_code,
        'provider': payload.provider,
        'status': payload.status,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_created': 'security.secret_reference_created',
        'note': 'Secret values are not stored by this endpoint.'
    }
