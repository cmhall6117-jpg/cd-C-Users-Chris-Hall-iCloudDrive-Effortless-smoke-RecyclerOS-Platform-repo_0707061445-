You are integrating RecyclerOS Pro Release Candidate 1 for Effortless Smoke, LLC.

Use the VS-065 RC1 package as release governance.

Your job:
- Assemble the generated RecyclerOS packages into one monorepo.
- Preserve source ZIPs under archive/source_packages.
- Resolve duplicate Dart models, enums, imports, Flutter routes, FastAPI routes, and SQL migration ordering.
- Run backend import/startup checks.
- Run PostgreSQL migrations from a clean database.
- Initialize SQLite from a clean database.
- Run flutter pub get, flutter analyze, flutter test, and launch the app.
- Implement and test the working path:
  Mission Control → Opportunity Discovery → Vehicle → Procurement → Pick List → Inventory.
- Enforce organization/workspace tenant context.
- Create a defect register, assumptions log, build report, smoke-test report, and RC1 release evidence.
- Do not mark a release gate passed without command output or test evidence.
- Do not delete generated documents without archiving them.
- Never commit secret values.

Return:
1. Summary of work completed.
2. Branch and commit.
3. Files changed.
4. Build and migration results.
5. Test results.
6. Open defects by severity.
7. RC1 gate status.
8. Recommended next action.
