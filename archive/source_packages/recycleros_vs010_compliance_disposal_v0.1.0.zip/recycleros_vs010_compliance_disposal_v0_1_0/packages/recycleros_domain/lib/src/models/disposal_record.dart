class DisposalRecord {
  final String disposalRecordId;
  final String disposalCode;
  final String materialType;
  final String? vehicleId;
  final double? quantity;
  final String? unit;
  final String disposalVendor;
  final DateTime disposedAt;
  final String status;

  const DisposalRecord({
    required this.disposalRecordId,
    required this.disposalCode,
    required this.materialType,
    this.vehicleId,
    this.quantity,
    this.unit,
    required this.disposalVendor,
    required this.disposedAt,
    required this.status,
  });
}
