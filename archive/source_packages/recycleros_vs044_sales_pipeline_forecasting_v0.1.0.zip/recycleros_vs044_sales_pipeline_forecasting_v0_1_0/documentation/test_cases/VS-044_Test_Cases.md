# VS-044 Sales Pipeline Forecasting Test Cases

TC-001 Forecast Snapshot: forecast.sales_generated event is recorded.
TC-002 Weighted Revenue: projected amount times probability creates weighted amount.
TC-003 Related Object Link: forecast line links to lead, listing, customer, or inventory.
TC-004 Status Tracking: forecast line supports open, committed, won, lost, and archived.
TC-005 Offline Forecast: forecast records save locally with sync_status pending.
