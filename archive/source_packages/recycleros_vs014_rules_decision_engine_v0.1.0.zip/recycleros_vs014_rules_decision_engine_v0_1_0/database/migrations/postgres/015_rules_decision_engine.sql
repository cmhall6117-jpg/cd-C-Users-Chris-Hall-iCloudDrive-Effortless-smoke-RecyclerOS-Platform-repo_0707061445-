CREATE TABLE IF NOT EXISTS business_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rule_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    condition_expression TEXT NOT NULL,
    action_expression TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rule_evaluations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_rule_id UUID REFERENCES business_rules(id),
    related_object_type TEXT NOT NULL,
    related_object_id TEXT NOT NULL,
    result BOOLEAN NOT NULL,
    context JSONB NOT NULL DEFAULT '{}'::jsonb,
    evaluated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS decision_recommendations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recommendation_code TEXT UNIQUE NOT NULL,
    recommendation_type TEXT NOT NULL,
    related_object_type TEXT NOT NULL,
    related_object_id TEXT NOT NULL,
    recommendation TEXT NOT NULL,
    reasoning TEXT NOT NULL,
    confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS recommendation_outcomes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recommendation_id UUID REFERENCES decision_recommendations(id),
    outcome_type TEXT NOT NULL,
    outcome_summary TEXT,
    financial_impact NUMERIC(12,2),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
