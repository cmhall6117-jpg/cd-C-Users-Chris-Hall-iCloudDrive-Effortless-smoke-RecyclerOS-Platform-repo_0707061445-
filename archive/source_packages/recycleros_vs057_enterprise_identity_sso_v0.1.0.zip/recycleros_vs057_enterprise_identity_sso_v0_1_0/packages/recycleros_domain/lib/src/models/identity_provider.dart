class IdentityProvider {
  final String identityProviderId;
  final String providerCode;
  final String organizationId;
  final String providerType;
  final String displayName;
  final String issuerUrl;
  final String clientIdReference;
  final String status;
  final DateTime createdAt;

  const IdentityProvider({
    required this.identityProviderId,
    required this.providerCode,
    required this.organizationId,
    required this.providerType,
    required this.displayName,
    required this.issuerUrl,
    required this.clientIdReference,
    required this.status,
    required this.createdAt,
  });
}
