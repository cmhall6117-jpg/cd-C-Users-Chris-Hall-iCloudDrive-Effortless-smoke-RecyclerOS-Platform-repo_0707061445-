class OrchestratorAction {
  final String orchestratorActionId;
  final String actionCode;
  final String title;
  final String category;
  final String priority;
  final double priorityScore;
  final double confidenceScore;
  final String? relatedObjectType;
  final String? relatedObjectId;
  final DateTime createdAt;

  const OrchestratorAction({
    required this.orchestratorActionId,
    required this.actionCode,
    required this.title,
    required this.category,
    required this.priority,
    required this.priorityScore,
    required this.confidenceScore,
    this.relatedObjectType,
    this.relatedObjectId,
    required this.createdAt,
  });
}
