class AuctionWatchlistItem {
  final String watchlistItemId;
  final String auctionSourceId;
  final String? opportunityId;
  final String? vehicleId;
  final String listingTitle;
  final String? listingUrl;
  final double? currentBid;
  final double? recommendedMaxBid;
  final DateTime createdAt;

  const AuctionWatchlistItem({
    required this.watchlistItemId,
    required this.auctionSourceId,
    this.opportunityId,
    this.vehicleId,
    required this.listingTitle,
    this.listingUrl,
    this.currentBid,
    this.recommendedMaxBid,
    required this.createdAt,
  });
}
