CREATE TABLE IF NOT EXISTS vendors (
    id TEXT PRIMARY KEY,
    vendor_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    vendor_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    phone TEXT,
    email TEXT,
    website_url TEXT,
    created_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS vendor_performance_snapshots (
    id TEXT PRIMARY KEY,
    vendor_id TEXT NOT NULL,
    reliability_score REAL NOT NULL DEFAULT 0,
    cost_score REAL NOT NULL DEFAULT 0,
    service_score REAL NOT NULL DEFAULT 0,
    notes TEXT,
    generated_at TEXT NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending'
);
