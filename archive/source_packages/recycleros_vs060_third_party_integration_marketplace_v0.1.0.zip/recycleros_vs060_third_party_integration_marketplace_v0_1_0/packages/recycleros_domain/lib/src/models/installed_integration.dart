class InstalledIntegration {
  final String installedIntegrationId;
  final String integrationListingId;
  final String organizationId;
  final String workspaceId;
  final String status;
  final String? credentialReferenceId;
  final DateTime installedAt;

  const InstalledIntegration({
    required this.installedIntegrationId,
    required this.integrationListingId,
    required this.organizationId,
    required this.workspaceId,
    required this.status,
    this.credentialReferenceId,
    required this.installedAt,
  });
}
